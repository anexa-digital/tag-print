var namespace_uni_p_r_t_1_1_sdk_1_1_mgmt =
[
    [ "AMgmtListenerChannels", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_a_mgmt_listener_channels.html", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_a_mgmt_listener_channels" ],
    [ "IMgmtComm", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_comm.html", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_comm" ],
    [ "IMgmtMessenger", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_messenger.html", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_messenger" ],
    [ "IMgmtMsgListenerChannels", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_msg_listener_channels.html", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_msg_listener_channels" ],
    [ "Listener", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_listener.html", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_listener" ],
    [ "ListenerChannelsJson", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_listener_channels_json.html", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_listener_channels_json" ],
    [ "ListenerChannelsMgmtMsg", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_listener_channels_mgmt_msg.html", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_listener_channels_mgmt_msg" ],
    [ "Messenger", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger.html", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger" ],
    [ "MgmtMsg", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_mgmt_msg.html", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_mgmt_msg" ]
];