var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_square_cell =
[
    [ "CellSize", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_square_cell.html#af1356eabf4f77374a21a2a583e5c67a2", null ]
];