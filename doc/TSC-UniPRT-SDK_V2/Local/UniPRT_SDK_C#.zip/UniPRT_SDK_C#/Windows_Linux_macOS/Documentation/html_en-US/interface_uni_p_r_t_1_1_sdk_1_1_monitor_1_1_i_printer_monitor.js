var interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_printer_monitor =
[
    [ "GetEngineStatus", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_printer_monitor.html#a701790114a1472fcc566ddf9b0b28c5e", null ],
    [ "GetFaultStatus", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_printer_monitor.html#a3de0d80a48426120ea98bb3e235468f2", null ],
    [ "GetPrinterInfo", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_printer_monitor.html#a9092e1dbddbbb7200607c3aad5149814", null ],
    [ "AlertStatusCallback", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_printer_monitor.html#ae86f01865d58d75a6f92f9d751efe7c4", null ],
    [ "AlertStatusListening", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_printer_monitor.html#a7a694d5cf50d11d22c7de568e0e12380", null ],
    [ "DisplayStatusCallback", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_printer_monitor.html#a49623c19d25f045fa5d6c43e5731f6a1", null ],
    [ "DisplayStatusListening", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_printer_monitor.html#a222226f47f537c93b2e75266b3ad3dc7", null ],
    [ "EngineStatusCallback", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_printer_monitor.html#a136e9e84715cf77242e1b60fb48f4566", null ],
    [ "EngineStatusListening", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_printer_monitor.html#a10e84779f30a1569ad705d6f26f30c71", null ]
];