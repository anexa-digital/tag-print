var interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm =
[
    [ "Close", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#a0dd0a074b62ccd4ceffbbebb1a91ecd9", null ],
    [ "Open", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#a216ae6ff382338c49dc79bd67a1fc18f", null ],
    [ "Read", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#a2726f8e9bdd01ce6f9cb028267a41272", null ],
    [ "Read", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#a8a08aabe383c3277b243aa558268f792", null ],
    [ "WaitForData", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#ae809ff7ef10cb9bcdf3e8e44f75f474a", null ],
    [ "Write", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#aff51470df8d83e4a058bb70b11d487b8", null ],
    [ "Write", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#a5e8e0714b402c2dc48756e61b8105bf4", null ],
    [ "WriteAndWaitForResponse", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#ab7133c6d6ab80aeb6b3f3317e877e0ce", null ],
    [ "WriteAndWaitForResponse", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#a9b71a952461bf8ecb42eed6e1a6d159a", null ],
    [ "BytesAvailable", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#a607228f2aa7463618201fda21d5e0a7c", null ],
    [ "Connected", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#af53800fd764d45563570bf6b61e9de89", null ],
    [ "Descriptor", "interface_uni_p_r_t_1_1_sdk_1_1_comm_1_1_i_comm.html#ac57308a44fe9b44ea976face3d355dc0", null ]
];