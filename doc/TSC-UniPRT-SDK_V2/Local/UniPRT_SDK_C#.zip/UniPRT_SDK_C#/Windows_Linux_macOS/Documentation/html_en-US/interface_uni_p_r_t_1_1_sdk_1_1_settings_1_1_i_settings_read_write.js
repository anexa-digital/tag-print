var interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_settings_read_write =
[
    [ "GetAllProperties", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_settings_read_write.html#a411313e7194d2a5db09fcf728fdff7a7", null ],
    [ "GetAllValues", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_settings_read_write.html#ac9c523158818014368970e84258adfe3", null ],
    [ "GetProperties", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_settings_read_write.html#a5dcaacdaff36d4b3818c38c42444567f", null ],
    [ "GetProperties", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_settings_read_write.html#a6dd5aad64efaf1571e15a3bf311279af", null ],
    [ "GetValue", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_settings_read_write.html#a19215aa2d9e9fddad1fc95a8260601fd", null ],
    [ "GetValues", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_settings_read_write.html#a457324479206f62748000f76fb7d6e5b", null ],
    [ "SetValue", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_settings_read_write.html#a626503fe4a3a8824a31240856a85eb93", null ],
    [ "SetValues", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_settings_read_write.html#a241b222ff0674a85117d6480eb92d0c6", null ]
];