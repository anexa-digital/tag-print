var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_bank_select =
[
    [ "Memory", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_bank_select.html#abc9d867c5e0bdb6fd12175f6a08f8dc5", null ]
];