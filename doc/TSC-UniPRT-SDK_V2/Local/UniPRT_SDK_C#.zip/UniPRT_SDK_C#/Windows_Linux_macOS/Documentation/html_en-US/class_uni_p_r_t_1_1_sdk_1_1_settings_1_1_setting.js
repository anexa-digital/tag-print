var class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_setting =
[
    [ "ToString", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_setting.html#a0bbad1e1f06477592d6605a6b96ba4b8", null ],
    [ "Increment", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_setting.html#a01048aff225f08eb0717984f909c8736", null ],
    [ "Maximum", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_setting.html#a3a7a41f5c37f1627be1ea295dfb7d4f2", null ],
    [ "Minimum", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_setting.html#a335200e440e05de863a9f56418486126", null ],
    [ "Options", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_setting.html#a7047c2fbd07d5d9940368679d3677ec1", null ],
    [ "Permission", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_setting.html#a277968708ce31b9bea070a308c58efad", null ],
    [ "Type", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_setting.html#a6fe0758ede1bf6c6c638fd7e720e74b7", null ],
    [ "Value", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_setting.html#a29823729b628f5948169811b78d173e5", null ]
];