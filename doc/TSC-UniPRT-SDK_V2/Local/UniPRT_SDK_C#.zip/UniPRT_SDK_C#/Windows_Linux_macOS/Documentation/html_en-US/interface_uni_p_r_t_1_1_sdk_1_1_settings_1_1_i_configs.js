var interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_configs =
[
    [ "GetAllConfig", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_configs.html#a92e202ca91e145784686cb14b176d981", null ],
    [ "GetConfig", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_configs.html#a86ee6ab918b6b988f16501c6287b7b77", null ],
    [ "SetConfig", "interface_uni_p_r_t_1_1_sdk_1_1_settings_1_1_i_configs.html#a31e1213d43a02b83b7fc36d7b8cf9d18", null ]
];