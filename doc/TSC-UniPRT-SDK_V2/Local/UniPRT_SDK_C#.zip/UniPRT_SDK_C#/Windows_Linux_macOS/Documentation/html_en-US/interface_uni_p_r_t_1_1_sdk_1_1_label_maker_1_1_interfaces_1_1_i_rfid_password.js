var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_password =
[
    [ "Password", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_password.html#a92f944fc841dc70a63aaec3b411833f4", null ],
    [ "PasswordType", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_password.html#a4724069a0045c5c883c653aa4045cfc9", null ]
];