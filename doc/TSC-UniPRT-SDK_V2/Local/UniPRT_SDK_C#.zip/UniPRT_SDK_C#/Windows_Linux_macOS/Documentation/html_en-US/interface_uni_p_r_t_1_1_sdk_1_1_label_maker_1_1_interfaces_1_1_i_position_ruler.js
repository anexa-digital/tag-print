var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_position_ruler =
[
    [ "Ruler", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_position_ruler.html#a92ed3b0775cc76b5c8a3f62225bfad6f", null ]
];