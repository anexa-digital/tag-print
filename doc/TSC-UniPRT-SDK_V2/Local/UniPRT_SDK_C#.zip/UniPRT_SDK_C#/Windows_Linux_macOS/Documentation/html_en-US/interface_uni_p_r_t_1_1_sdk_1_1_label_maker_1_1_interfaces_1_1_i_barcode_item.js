var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode_item =
[
    [ "Data", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode_item.html#ac07eae1d78efcc2afde59116141eb072", null ],
    [ "Height", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode_item.html#a58e1266da6a698f117252036040231de", null ],
    [ "Start", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode_item.html#abbc29c48f840e11e868ebf569b824f88", null ]
];