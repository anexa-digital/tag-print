var namespace_uni_p_r_t_1_1_sdk_1_1_reports =
[
    [ "OdvReport", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_odv_report.html", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_odv_report" ],
    [ "PrinterInfo", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info.html", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info" ],
    [ "RfidReport", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report" ]
];