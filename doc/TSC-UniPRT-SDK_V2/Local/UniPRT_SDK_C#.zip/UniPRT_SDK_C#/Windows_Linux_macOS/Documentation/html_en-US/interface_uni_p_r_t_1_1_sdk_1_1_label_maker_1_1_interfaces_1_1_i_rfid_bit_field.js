var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_bit_field =
[
    [ "Data", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_bit_field.html#a294c07719251c34d8412aef7d2e17a27", null ],
    [ "OffsetFromStart", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_bit_field.html#aaed377d7f43b4daa2ca2f0ccd7d86bd9", null ]
];