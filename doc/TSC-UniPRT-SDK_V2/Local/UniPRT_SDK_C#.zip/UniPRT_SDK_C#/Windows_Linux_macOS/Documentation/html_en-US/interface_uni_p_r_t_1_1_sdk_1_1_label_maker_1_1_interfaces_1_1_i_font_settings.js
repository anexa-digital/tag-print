var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_font_settings =
[
    [ "FontName", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_font_settings.html#aabe1b1eab614860d518d8d3992c8e87e", null ],
    [ "FontSizeUnits", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_font_settings.html#a8c6ad7556c3e1b45fbfd51df4669f43f", null ],
    [ "FontStyle", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_font_settings.html#aef1b7b5002ebbfa1ac08954949ae350a", null ]
];