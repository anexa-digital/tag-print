var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode__1_d___properties =
[
    [ "BarcodeType", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode__1_d___properties.html#a8616e0aa91b1618d67165df94dcfe094", null ],
    [ "BarWidths", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode__1_d___properties.html#a0c6899092ba74c549cff8fe13ddffc55", null ],
    [ "PrintHumanReadable", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode__1_d___properties.html#af9626dd45fdb2df898cbbbf1a63345f2", null ],
    [ "Rotation", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode__1_d___properties.html#af6b1948f8ff48bba51432f04c5b5bfdc", null ],
    [ "Ruler", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode__1_d___properties.html#a04c09d40124e2c084c0e52cdaa8c0d24", null ]
];