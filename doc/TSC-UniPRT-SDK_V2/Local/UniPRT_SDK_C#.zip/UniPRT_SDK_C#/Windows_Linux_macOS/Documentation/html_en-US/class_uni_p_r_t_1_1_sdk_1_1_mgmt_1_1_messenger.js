var class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger =
[
    [ "Messenger", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger.html#a960ee87a53717c3b698074fed0574c0f", null ],
    [ "Dispose", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger.html#af9f9e48ad3a0fe6d388440197af81169", null ],
    [ "Dispose", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger.html#a6eaac2136e7810b61d04ce39b168ac02", null ],
    [ "ReadNextMsg", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger.html#ab66a86e53c0eff0a682c6bab81dba9b7", null ],
    [ "SendMsg", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger.html#a28f36cee4c8b98bc62bceb7fb49ea2ce", null ],
    [ "SendMsgAndWaitForResponse", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger.html#a600b881a64ab26b357e075fdb079d2b5", null ],
    [ "SendMsgRaw", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger.html#aea4ff5964a352d27f4562b24d896a035", null ],
    [ "ID", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger.html#a3a61b710e18dc33ef99d0cdccc661cf4", null ],
    [ "UnreadMsgCount", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_messenger.html#a2932dc331e23423e72cdb28adc1a9ec0", null ]
];