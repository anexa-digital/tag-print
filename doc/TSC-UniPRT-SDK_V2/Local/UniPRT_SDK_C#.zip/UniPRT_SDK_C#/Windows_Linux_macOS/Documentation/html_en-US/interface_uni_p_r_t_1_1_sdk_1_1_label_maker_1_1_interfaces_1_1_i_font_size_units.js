var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_font_size_units =
[
    [ "FontSizeUnits", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_font_size_units.html#a8c6ad7556c3e1b45fbfd51df4669f43f", null ]
];