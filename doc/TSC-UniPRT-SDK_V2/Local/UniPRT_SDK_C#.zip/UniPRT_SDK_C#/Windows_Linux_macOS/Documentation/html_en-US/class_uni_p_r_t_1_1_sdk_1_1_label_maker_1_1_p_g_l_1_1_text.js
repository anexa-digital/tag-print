var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text =
[
    [ "Text", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text.html#a59ebc2f90365c29bb49c12e3345ecd26", null ],
    [ "Text", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text.html#a650436ed2c103e69e3f4349652f1a042", null ],
    [ "ToString", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text.html#aa487ac30680e059daf25e0e0ae0e05b2", null ],
    [ "Alignment", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text.html#ae233bf35a2e0ac2d61d90b85fe9f24c5", null ],
    [ "FontName", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text.html#a2f2e9e0b87ef3520d0fd9b8009358df6", null ],
    [ "FontSizeUnits", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text.html#a1da980b9aef873ae83e244d5022d2c4e", null ],
    [ "FontStyle", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text.html#adcf557cf8f9443cd93a2c12ae6bd3793", null ],
    [ "Rotation", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text.html#a2757dcda903bc1c6d829a3e0eeb6107d", null ],
    [ "Ruler", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text.html#ad24e9af6e94a5ff93a98ce42f4fc3610", null ],
    [ "Text", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_text.html#adb44bb5ee65af1c348a950c680b618ce", null ]
];