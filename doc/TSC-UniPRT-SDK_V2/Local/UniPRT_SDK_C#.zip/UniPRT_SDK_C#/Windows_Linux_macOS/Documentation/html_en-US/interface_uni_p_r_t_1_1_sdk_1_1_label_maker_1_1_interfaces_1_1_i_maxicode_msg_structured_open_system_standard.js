var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured_open_system_standard =
[
    [ "CountryCode", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured_open_system_standard.html#a56762ef68d421470ce207d45af43fd2e", null ],
    [ "Data", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured_open_system_standard.html#a5ad90dd1c385f9aba0b089ed9821219c", null ],
    [ "Mode", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured_open_system_standard.html#a9d560167fec7ef8f2e6a4cee08110c14", null ],
    [ "PostalCode", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured_open_system_standard.html#a053aef90e36daad5cedd8e6c5aac3861", null ],
    [ "RemainingMsg", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured_open_system_standard.html#a848fd39ace20d76b6d57cb59186a26f1", null ],
    [ "ServiceClass", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured_open_system_standard.html#a86b2dad7ee639318e96d475c34d00661", null ],
    [ "Year", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured_open_system_standard.html#a7648c72f747f3ba68094ad161448ea7e", null ]
];