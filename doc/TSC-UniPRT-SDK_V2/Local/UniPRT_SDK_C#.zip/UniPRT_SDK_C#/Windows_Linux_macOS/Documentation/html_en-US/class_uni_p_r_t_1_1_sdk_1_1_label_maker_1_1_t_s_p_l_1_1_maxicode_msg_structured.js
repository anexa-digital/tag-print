var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured =
[
    [ "MaxicodeMsgStructured", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured.html#a4b4a454d3004927dd3d53c8b42192dfa", null ],
    [ "MaxicodeMsgStructured", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured.html#a1e8385ae7c870d608a5348af6b25227c", null ],
    [ "CountryCode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured.html#a1a99dfbc28c3877971d5394e0ce614d1", null ],
    [ "Data", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured.html#a7013904384b6d0c228bb073b22c6a78a", null ],
    [ "Mode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured.html#a71bccbcf31add977c380f882789a63c7", null ],
    [ "PostalCode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured.html#a43c7ee1e331a027cb1139017a47c6d92", null ],
    [ "RemainingMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured.html#a7587b0ec8fdfa9060fcaa26064c48c0e", null ],
    [ "ServiceClass", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured.html#acd11c51e0ba999fcb52909e88bd4c904", null ]
];