var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_font_style =
[
    [ "FontStyle", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_font_style.html#aef1b7b5002ebbfa1ac08954949ae350a", null ]
];