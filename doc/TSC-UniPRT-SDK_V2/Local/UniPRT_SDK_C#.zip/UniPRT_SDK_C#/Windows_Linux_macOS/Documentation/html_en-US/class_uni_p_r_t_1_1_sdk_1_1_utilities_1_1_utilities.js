var class_uni_p_r_t_1_1_sdk_1_1_utilities_1_1_utilities =
[
    [ "SendPrintFile", "class_uni_p_r_t_1_1_sdk_1_1_utilities_1_1_utilities.html#a40452e22e847de7873b072de6c9afd60", null ],
    [ "SendPrintString", "class_uni_p_r_t_1_1_sdk_1_1_utilities_1_1_utilities.html#a134143a7a87f7f45d1fe82ae05047b3d", null ]
];