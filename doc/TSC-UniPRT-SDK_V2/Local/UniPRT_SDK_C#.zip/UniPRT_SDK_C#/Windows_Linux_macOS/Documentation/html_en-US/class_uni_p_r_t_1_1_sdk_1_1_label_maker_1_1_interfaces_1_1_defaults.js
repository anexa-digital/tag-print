var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_defaults =
[
    [ "Alignment", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_defaults.html#a03912c548ed741d03621921ead725855", null ],
    [ "CellSize", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_defaults.html#a96cf194e8ed5cb62f422ba4f97e5cfc9", null ],
    [ "CellSizeRect", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_defaults.html#a85cd05abb8d9e603f452146f6e836f59", null ],
    [ "PrinterResolution", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_defaults.html#ab4618b8dba1e773a88bc92eb6780c431", null ],
    [ "Rotation", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_defaults.html#a95b28262fef2aca1f623c45921c53000", null ],
    [ "Ruler", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_defaults.html#aff0166e7eb4f35ce654f931763c5b52b", null ]
];