var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rectangle_cell =
[
    [ "CellSize", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rectangle_cell.html#ac0df2575446d65db1f0fc8321905443a", null ]
];