var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_item =
[
    [ "Data", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_item.html#a084bda25913d37f89b737c52757e33a7", null ],
    [ "FontSize", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_item.html#ab38c276fe1d474cd7ee48559fdc2a43c", null ],
    [ "Start", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_item.html#a9235627395185cdf999f220b4292ff6f", null ]
];