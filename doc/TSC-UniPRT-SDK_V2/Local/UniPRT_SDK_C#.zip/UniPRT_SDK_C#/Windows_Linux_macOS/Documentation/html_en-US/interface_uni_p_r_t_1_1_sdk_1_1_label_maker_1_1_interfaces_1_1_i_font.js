var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_font =
[
    [ "FontName", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_font.html#aabe1b1eab614860d518d8d3992c8e87e", null ]
];