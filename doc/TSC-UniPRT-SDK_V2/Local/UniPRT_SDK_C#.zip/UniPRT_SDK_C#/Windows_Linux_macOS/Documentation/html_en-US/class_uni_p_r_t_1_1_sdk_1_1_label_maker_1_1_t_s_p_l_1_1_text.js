var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text =
[
    [ "Text", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#ac4cf0fce896f47eaa9e3c77504a5f4fa", null ],
    [ "Text", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#aa54cece3291a07e81fbc4966facaff26", null ],
    [ "ToString", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#a66f955dd8f7e0f584dcfea8ab98efdbe", null ],
    [ "Alignment", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#ae233bf35a2e0ac2d61d90b85fe9f24c5", null ],
    [ "FontName", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#a2f2e9e0b87ef3520d0fd9b8009358df6", null ],
    [ "FontSizeUnits", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#a1da980b9aef873ae83e244d5022d2c4e", null ],
    [ "FontStyle", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#adcf557cf8f9443cd93a2c12ae6bd3793", null ],
    [ "ReferencePoint", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#af6ecfde248d7844559c853501608678b", null ],
    [ "Reverse", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#a03e65f237b9921ae195d21b04c905f17", null ],
    [ "Rotation", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#a2757dcda903bc1c6d829a3e0eeb6107d", null ],
    [ "Ruler", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#ad24e9af6e94a5ff93a98ce42f4fc3610", null ],
    [ "Text", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_text.html#adb44bb5ee65af1c348a950c680b618ce", null ]
];