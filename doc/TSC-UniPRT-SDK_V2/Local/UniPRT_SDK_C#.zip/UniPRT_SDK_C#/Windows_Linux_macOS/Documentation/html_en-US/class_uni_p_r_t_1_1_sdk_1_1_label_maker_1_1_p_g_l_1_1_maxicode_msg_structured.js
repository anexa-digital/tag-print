var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg_structured =
[
    [ "MaxicodeMsgStructured", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg_structured.html#a06db51484290325c4b242a41c5a5edf2", null ],
    [ "MaxicodeMsgStructured", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg_structured.html#a013ea94deb4ba95c7da0fa17e4e9469e", null ],
    [ "CountryCode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg_structured.html#a1a99dfbc28c3877971d5394e0ce614d1", null ],
    [ "Data", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg_structured.html#a5f027ac272a1176394bdf65bbd623fe8", null ],
    [ "Mode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg_structured.html#a71bccbcf31add977c380f882789a63c7", null ],
    [ "PostalCode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg_structured.html#a43c7ee1e331a027cb1139017a47c6d92", null ],
    [ "RemainingMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg_structured.html#a7587b0ec8fdfa9060fcaa26064c48c0e", null ],
    [ "ServiceClass", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg_structured.html#acd11c51e0ba999fcb52909e88bd4c904", null ]
];