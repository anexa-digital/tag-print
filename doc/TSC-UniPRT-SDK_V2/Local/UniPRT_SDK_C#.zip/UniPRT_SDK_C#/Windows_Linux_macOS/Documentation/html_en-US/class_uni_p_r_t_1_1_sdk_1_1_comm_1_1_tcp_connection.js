var class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection =
[
    [ "DescriptorPortType", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#af7b0c9a0a5f2dd61ed14d345e344ff69", [
      [ "DATA", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#af7b0c9a0a5f2dd61ed14d345e344ff69ae44f9e348e41cb272efa87387728571b", null ],
      [ "MGMT", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#af7b0c9a0a5f2dd61ed14d345e344ff69a66f90deb950bfbbb5bf08eda7317c3ef", null ],
      [ "STATUS", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#af7b0c9a0a5f2dd61ed14d345e344ff69a5f241c8c8f985b3c51e05d39cf030f4c", null ]
    ] ],
    [ "TcpConnection", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#ae997818c58f9d2b181f1ef8fea72cbf4", null ],
    [ "TcpConnection", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a61e2f8d0b48ea9f798397e3d21988623", null ],
    [ "Close", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a4d0abf99df97b0b761e4b1f5507d73c3", null ],
    [ "DescriptorValidate", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#aad97144773d749b94b0dfbb6dcb64029", null ],
    [ "Dispose", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a7875090dd3ee321db36d2a0ad7419a35", null ],
    [ "Dispose", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a2d46a406ee95ffa92bb8f9c6c777620a", null ],
    [ "Open", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a7d8f8e9e05e7185327bc3d199f556f77", null ],
    [ "Read", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a9540d6d0997e47056eed5a73f939ee62", null ],
    [ "Read", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#ac2d898737fd90d070b2e5c025f5ce39c", null ],
    [ "WaitForData", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a1fa8818dfb87edfbab7eb5f488f45435", null ],
    [ "Write", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a4026e9d6fba29d7a3daf5ce2f583835c", null ],
    [ "Write", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a562ecac48a0b0cfff7ec57045bc804ca", null ],
    [ "WriteAndWaitForResponse", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#ab935a61657b32455b09dd817a3682495", null ],
    [ "WriteAndWaitForResponse", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a29721ecab9ac8ed3509e585503375dfe", null ],
    [ "DEFAULT_DATA_PORT", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a80933b1ee65b7da686fbe6b7f76736f4", null ],
    [ "DEFAULT_MGMT_PORT", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a1a6eab373c22eef4d915ac3ec178588c", null ],
    [ "DEFAULT_STATUS_PORT", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#ac96f3c08c4857269813291f104b6d29c", null ],
    [ "Descriptor", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#ab8c27b9642a418e7f88a89157fae93d0", null ],
    [ "BytesAvailable", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#abea707123a79660b5eda651c5466630d", null ],
    [ "Connected", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a607999621c1414872ec35f22cee97759", null ],
    [ "IpAddress", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#ae30cb724089a516ef9ef85d03ba51ae7", null ],
    [ "Port", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_tcp_connection.html#a77f01cfc4c27b6b51cd1cabb05d72197", null ]
];