var class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_odv_report =
[
    [ "Data", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_odv_report.html#ac95e8550d395296cce0b2b6afa012c2a", null ],
    [ "Failed", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_odv_report.html#a72fee69f20193a1bedf26ab7d9bafe44", null ],
    [ "OverallGrade", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_odv_report.html#a24ed809fc74136c01890ba0a4e8b0ade", null ],
    [ "OverallGradeAsFloat", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_odv_report.html#a389c6a47f753f58d06c180d6e919e6df", null ],
    [ "OverallGradeLetter", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_odv_report.html#a421fffe8d853428183afcda6283fd9df", null ],
    [ "Symbology", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_odv_report.html#aea6406c52ececaab9464c6a8c9d70bc0", null ]
];