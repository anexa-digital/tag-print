var class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report =
[
    [ "RfidDataType", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html#a70d73db9fd932e543bdbf3de0261792a", [
      [ "EPC", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html#a70d73db9fd932e543bdbf3de0261792aa4ed30fb3271f7d6f48a2b9045a628e1c", null ],
      [ "USR", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html#a70d73db9fd932e543bdbf3de0261792aa2b6cc9c30eaad9c109091ea928529cbd", null ],
      [ "TID", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html#a70d73db9fd932e543bdbf3de0261792aa703fb2898407d085357b23bdb7f1b113", null ],
      [ "ACS", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html#a70d73db9fd932e543bdbf3de0261792aa3763590ba4935513c1f6b8466f644ed6", null ],
      [ "UNKNOWN", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html#a70d73db9fd932e543bdbf3de0261792aa696b031073e74bf2cb98e5ef201d4aa3", null ]
    ] ],
    [ "Data", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html#accb56be6e40a808dad35c55ad33a30fc", null ],
    [ "DataType", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html#a2aca6d5ee3cf261a94926ee6913c39ef", null ],
    [ "Failed", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html#acbf6603f954667fb69dc97a4ac539c8d", null ],
    [ "IsWriteOperation", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_rfid_report.html#ab3c815e8cc4a8bcd75cde60902c7eb15", null ]
];