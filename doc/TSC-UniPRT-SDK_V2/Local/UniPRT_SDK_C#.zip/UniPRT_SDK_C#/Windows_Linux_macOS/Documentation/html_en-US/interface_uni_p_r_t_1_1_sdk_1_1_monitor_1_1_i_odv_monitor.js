var interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_odv_monitor =
[
    [ "OdvReportCallback", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_odv_monitor.html#a2c873150321cddc76dfb29169d6493d6", null ],
    [ "OdvReportListening", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_odv_monitor.html#aa290c9f0ff746e26701f94f9c29efe7f", null ]
];