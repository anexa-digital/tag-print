var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_ruler =
[
    [ "Scale", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_ruler.html#af5c0d6fd3e106462bb8c9b38e1d6da9c", null ]
];