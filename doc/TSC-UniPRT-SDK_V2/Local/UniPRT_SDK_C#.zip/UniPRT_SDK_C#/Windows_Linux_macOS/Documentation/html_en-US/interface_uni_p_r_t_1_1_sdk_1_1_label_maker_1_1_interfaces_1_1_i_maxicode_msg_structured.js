var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured =
[
    [ "CountryCode", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured.html#ad51da1d67809527261519d62b19fbfe0", null ],
    [ "Data", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured.html#a5ad90dd1c385f9aba0b089ed9821219c", null ],
    [ "Mode", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured.html#a9d560167fec7ef8f2e6a4cee08110c14", null ],
    [ "PostalCode", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured.html#a0b9f0f7e840b9b0c629175758158e73a", null ],
    [ "RemainingMsg", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured.html#acfd09281bb004fd17c4c580bd9524a1a", null ],
    [ "ServiceClass", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg_structured.html#afe713622a7bbc84124a220aaa4a976a8", null ]
];