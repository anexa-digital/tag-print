var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_print_resolution =
[
    [ "DotsPerInch", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_print_resolution.html#aa97037d3db925609055360825530f0af", null ],
    [ "DotsPerMM", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_print_resolution.html#a5c642a2e47396841c279064d30dbce69", null ]
];