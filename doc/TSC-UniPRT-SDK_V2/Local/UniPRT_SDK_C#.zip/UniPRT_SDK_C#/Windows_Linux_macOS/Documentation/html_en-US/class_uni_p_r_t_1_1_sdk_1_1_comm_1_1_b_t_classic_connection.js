var class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection =
[
    [ "BTClassicConnection", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a6923232d2e97fd3b16568227bb2b8010", null ],
    [ "BTClassicConnection", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a24ab63e3967e0e3a9cf6f371436a2097", null ],
    [ "Close", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a168ea110d5266b592a7d4bd0065004b6", null ],
    [ "DescriptorValidate", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a8d8e5e5ed5db819efabfa6f4acea8dae", null ],
    [ "Open", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a86acfddb0860f499a6b7bb7de899b362", null ],
    [ "Read", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a297d5cac9caf6f950481e0a6c662bcb5", null ],
    [ "Read", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#ac2d898737fd90d070b2e5c025f5ce39c", null ],
    [ "WaitForData", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a1fa8818dfb87edfbab7eb5f488f45435", null ],
    [ "Write", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a4026e9d6fba29d7a3daf5ce2f583835c", null ],
    [ "Write", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a6a603f6f51deb9b24cb195d19c1b429a", null ],
    [ "WriteAndWaitForResponse", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#ab935a61657b32455b09dd817a3682495", null ],
    [ "WriteAndWaitForResponse", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a29721ecab9ac8ed3509e585503375dfe", null ],
    [ "Descriptor", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a078370baa30616e144f4e2dab14b08a9", null ],
    [ "BytesAvailable", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#a4d1c98c1715e8140dc66c180f90acc48", null ],
    [ "Connected", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_b_t_classic_connection.html#af328edd8ad4b1146448e0d39d70d0b5d", null ]
];