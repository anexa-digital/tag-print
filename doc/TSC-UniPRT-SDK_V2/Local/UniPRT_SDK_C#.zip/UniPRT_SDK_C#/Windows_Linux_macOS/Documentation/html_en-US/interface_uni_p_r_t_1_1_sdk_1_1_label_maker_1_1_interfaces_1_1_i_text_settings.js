var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_settings =
[
    [ "Alignment", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_settings.html#ae69769fa30a85db55f0019debe6d702c", null ],
    [ "FontName", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_settings.html#aabe1b1eab614860d518d8d3992c8e87e", null ],
    [ "FontSizeUnits", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_settings.html#a8c6ad7556c3e1b45fbfd51df4669f43f", null ],
    [ "FontStyle", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_settings.html#aef1b7b5002ebbfa1ac08954949ae350a", null ],
    [ "Rotation", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_settings.html#af6b1948f8ff48bba51432f04c5b5bfdc", null ],
    [ "Ruler", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_text_settings.html#abf07c5d6b072312e5305bd4ac7ccc485", null ]
];