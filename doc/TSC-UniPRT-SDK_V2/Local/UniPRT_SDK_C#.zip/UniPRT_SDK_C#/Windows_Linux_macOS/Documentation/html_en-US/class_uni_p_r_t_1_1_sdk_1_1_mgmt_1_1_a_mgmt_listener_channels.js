var class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_a_mgmt_listener_channels =
[
    [ "AMgmtListenerChannels", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_a_mgmt_listener_channels.html#a7ff8ee857f803de923479fef4920272d", null ],
    [ "ListenerChannelConnect", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_a_mgmt_listener_channels.html#acc3e9d9b46f83d5d64e6f719a541ec6b", null ],
    [ "ListenerChannelDisconnect", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_a_mgmt_listener_channels.html#a01c40a9973840754bae4098f42e2a76f", null ],
    [ "ListenerChannelDisconnectPermanently", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_a_mgmt_listener_channels.html#a8834244034f3f97bd01a8ceaa81e8069", null ],
    [ "ListenerChannelGetNew", "class_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_a_mgmt_listener_channels.html#aaf0d8c42f84e97cbf51a7dfba800c55e", null ]
];