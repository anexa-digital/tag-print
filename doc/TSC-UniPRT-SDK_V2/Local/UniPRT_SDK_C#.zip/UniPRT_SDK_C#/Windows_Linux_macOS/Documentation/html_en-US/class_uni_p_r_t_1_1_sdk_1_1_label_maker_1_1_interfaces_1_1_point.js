var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_point =
[
    [ "Point", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_point.html#a668da91330b679908de1935edb3f8971", null ],
    [ "x", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_point.html#a8258d5a38cd895c66cb2933f7961597b", null ],
    [ "x", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_point.html#a6f38515f66af171528b220482d260408", null ],
    [ "y", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_point.html#a764f5ea6d8183eaf817382ef18523495", null ],
    [ "y", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_point.html#ab3ce21a2aafa28e4cfb488ebd5b3c316", null ]
];