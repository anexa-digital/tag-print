var class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm =
[
    [ "Close", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#a448be47c07cb46b3743ac0bc1927c0d8", null ],
    [ "Open", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#a14388c9526271f321e0acd2aed725e8e", null ],
    [ "Read", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#a28c28b2127eded3412d7af13d1913a49", null ],
    [ "Read", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#ac2d898737fd90d070b2e5c025f5ce39c", null ],
    [ "WaitForData", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#a1fa8818dfb87edfbab7eb5f488f45435", null ],
    [ "Write", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#a4026e9d6fba29d7a3daf5ce2f583835c", null ],
    [ "Write", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#aac97704edba1623c632a8ecbd8c71a34", null ],
    [ "WriteAndWaitForResponse", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#ab935a61657b32455b09dd817a3682495", null ],
    [ "WriteAndWaitForResponse", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#a29721ecab9ac8ed3509e585503375dfe", null ],
    [ "BytesAvailable", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#a4326fcc7404608f66071f227ed0a543e", null ],
    [ "Connected", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#a40957143fb7f91ad6ea125529a5f35fa", null ],
    [ "Descriptor", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_a_comm.html#a67ee222063ee7d94704caea5f4b40791", null ]
];