var interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_comm =
[
    [ "Send", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_comm.html#a4b7fecf2cc2a15b85c09d9d9ecaa0689", null ],
    [ "SendAndWaitForResponse", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_comm.html#ad834939503831111c12eb2345e2bb7da", null ]
];