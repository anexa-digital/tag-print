var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_write =
[
    [ "Data", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_write.html#a45ccc6d62263a04b2ebf1ff3b08a7b34", null ],
    [ "Memory", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_write.html#a156df9e3c86ef62b7aefe11a21815462", null ],
    [ "Password", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rfid_write.html#a57cd8a63f53938e42db8714a9a54196d", null ]
];