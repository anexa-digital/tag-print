var interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_messenger =
[
    [ "ReadNextMsg", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_messenger.html#a98d1ec177c3253ce62455e487f4b7306", null ],
    [ "SendMsg", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_messenger.html#a37cdad9c451729069c6ba97aba1f9153", null ],
    [ "SendMsgAndWaitForResponse", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_messenger.html#a0847aad7d8a7e4eeb9450b8bd6ddef65", null ],
    [ "SendMsgRaw", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_messenger.html#ad243e573fdde276464969afd804df5fe", null ],
    [ "UnreadMsgCount", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_messenger.html#aa8b3c032411cf5fd891614400545ae2e", null ]
];