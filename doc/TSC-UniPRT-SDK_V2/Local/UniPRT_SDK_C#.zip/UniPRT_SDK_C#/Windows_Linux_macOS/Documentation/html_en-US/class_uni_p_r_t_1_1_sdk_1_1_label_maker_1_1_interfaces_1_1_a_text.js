var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text =
[
    [ "AText", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text.html#abd57eccee4fe7cf4cfe57e704edb1c96", null ],
    [ "AText", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text.html#a0cbc1798e6cf03d61ad2105bb716e076", null ],
    [ "ToString", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text.html#a737ebc131668802882a591edfc322db9", null ],
    [ "Alignment", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text.html#ae233bf35a2e0ac2d61d90b85fe9f24c5", null ],
    [ "FontName", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text.html#a2f2e9e0b87ef3520d0fd9b8009358df6", null ],
    [ "FontSizeUnits", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text.html#a1da980b9aef873ae83e244d5022d2c4e", null ],
    [ "FontStyle", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text.html#adcf557cf8f9443cd93a2c12ae6bd3793", null ],
    [ "Rotation", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text.html#a2757dcda903bc1c6d829a3e0eeb6107d", null ],
    [ "Ruler", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text.html#ad24e9af6e94a5ff93a98ce42f4fc3610", null ],
    [ "Text", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text.html#adb44bb5ee65af1c348a950c680b618ce", null ]
];