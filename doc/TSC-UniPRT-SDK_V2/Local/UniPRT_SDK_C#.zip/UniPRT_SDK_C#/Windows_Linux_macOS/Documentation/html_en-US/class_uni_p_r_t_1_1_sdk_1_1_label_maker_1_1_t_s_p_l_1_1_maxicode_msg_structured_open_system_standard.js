var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured_open_system_standard =
[
    [ "MaxicodeMsgStructuredOpenSystemStandard", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured_open_system_standard.html#a02b598f335d0553cd7d05731f9350605", null ],
    [ "MaxicodeMsgStructuredOpenSystemStandard", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured_open_system_standard.html#a7b1cde4dffe6a585a8e30327465478a7", null ],
    [ "CountryCode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured_open_system_standard.html#aef2fd6e46b0c3bea3cbfd6ff29156003", null ],
    [ "Data", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured_open_system_standard.html#a7646a611ea0a9ad898972db53581335d", null ],
    [ "Mode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured_open_system_standard.html#a91337dd2f6b2187a3754d631a75cfa19", null ],
    [ "PostalCode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured_open_system_standard.html#a5a68371e4a05b9dda9072260a6669cab", null ],
    [ "RemainingMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured_open_system_standard.html#af76ac4d7072061d18f2296fc50653e1a", null ],
    [ "ServiceClass", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured_open_system_standard.html#a8a0dceaed1e593f07d01e015b58f7dad", null ],
    [ "Year", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg_structured_open_system_standard.html#ae75ca0a162c58020df1a1b4a4e988ccd", null ]
];