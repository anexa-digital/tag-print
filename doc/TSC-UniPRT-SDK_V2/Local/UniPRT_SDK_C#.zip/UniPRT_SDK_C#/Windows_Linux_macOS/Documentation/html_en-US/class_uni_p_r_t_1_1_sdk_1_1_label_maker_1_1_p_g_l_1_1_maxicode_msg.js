var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg =
[
    [ "MaxicodeMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg.html#a1c8080162626de622e86a61f13da13fb", null ],
    [ "MaxicodeMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg.html#a68b326cb6c5c9a882d0ca9b0bd3cd891", null ],
    [ "Data", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg.html#ab70aabcc2465e54fb1bd8174fc0e0b09", null ],
    [ "Mode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg.html#a527feceecba35704795a730ec2f5845e", null ],
    [ "PrimaryMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg.html#ae400a3f9586c4b12dffb77a40ddba275", null ],
    [ "RemainingMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_p_g_l_1_1_maxicode_msg.html#a0eac9c2213ea2a9f8658a3f56e5e5977", null ]
];