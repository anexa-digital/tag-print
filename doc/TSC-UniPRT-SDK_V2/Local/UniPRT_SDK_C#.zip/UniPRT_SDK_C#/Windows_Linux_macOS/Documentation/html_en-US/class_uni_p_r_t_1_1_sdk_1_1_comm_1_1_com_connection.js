var class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection =
[
    [ "ComConnection", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#ac69208ac0053da55223112479d5ef4cf", null ],
    [ "Close", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#abccc644c5a1af39a79881f122f46dcd4", null ],
    [ "FromDescriptor", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#a47c40cb7d2fc048b30a1c7f646005329", null ],
    [ "Open", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#aad52eca91de8ec27d32ded1bc2fd2825", null ],
    [ "Read", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#abd4c3f07244586d03d7ff4f2dd85f619", null ],
    [ "Read", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#ac2d898737fd90d070b2e5c025f5ce39c", null ],
    [ "WaitForData", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#a1fa8818dfb87edfbab7eb5f488f45435", null ],
    [ "Write", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#a4026e9d6fba29d7a3daf5ce2f583835c", null ],
    [ "Write", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#a1c4b4aa552767d4154f289b8cf026f94", null ],
    [ "WriteAndWaitForResponse", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#ab935a61657b32455b09dd817a3682495", null ],
    [ "WriteAndWaitForResponse", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#a29721ecab9ac8ed3509e585503375dfe", null ],
    [ "Descriptor", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#ae55012f450356e72f14e6dfc93a8fdf9", null ],
    [ "PortName", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#abfd91526dcd8f6afb689baca7b81e5a6", null ],
    [ "BaudRate", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#a84cee3c7b27912ad8af2c707413ff47a", null ],
    [ "BytesAvailable", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#af58a8d0cb2e3e61f0793f2189c4ac24a", null ],
    [ "Connected", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#af08ffeead06e8b9c8b0104f26acb628a", null ],
    [ "DataBits", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#a9510d97e08bec5442caa179001ba8232", null ],
    [ "Handshake", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#a9ff19f5414b28e8d7e8e686ed657f432", null ],
    [ "Parity", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#a453bdd79ac7d5226d49c067aadcc0fb0", null ],
    [ "PortName", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#abfd91526dcd8f6afb689baca7b81e5a6", null ],
    [ "StopBits", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_com_connection.html#aaeb5f15497f9c39ef6a36a9d4f13ea21", null ]
];