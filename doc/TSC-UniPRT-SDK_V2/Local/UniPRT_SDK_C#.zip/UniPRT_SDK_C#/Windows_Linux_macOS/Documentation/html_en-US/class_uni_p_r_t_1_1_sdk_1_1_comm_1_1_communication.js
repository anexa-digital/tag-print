var class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_communication =
[
    [ "CreateComm", "class_uni_p_r_t_1_1_sdk_1_1_comm_1_1_communication.html#aa301ff1a68ee9b49354a43acba4437d4", null ]
];