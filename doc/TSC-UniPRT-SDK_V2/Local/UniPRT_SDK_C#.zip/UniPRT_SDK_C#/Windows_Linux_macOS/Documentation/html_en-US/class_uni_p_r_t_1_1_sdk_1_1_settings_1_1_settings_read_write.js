var class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write =
[
    [ "SettingsReadWrite", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#a3dc6bed2175e0c6570d04c52ac62162e", null ],
    [ "SettingsReadWrite", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#a390dd6025815039c46a79d9bb2905848", null ],
    [ "Dispose", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#a5cab56b4a43150478a1566a39543daa2", null ],
    [ "Dispose", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#abe4e18bd929ea2e40c64850a7abf08f9", null ],
    [ "GetAllProperties", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#abb2929b49c93639deedfb78c0a3963ca", null ],
    [ "GetAllValues", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#a0f82fcfaf8fe2fe84cff409788a42b1c", null ],
    [ "GetProperties", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#a5e37f0a538c325ceb0c2e03c55261d05", null ],
    [ "GetProperties", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#a8abe7e3b2ae4b120d00299cf3af8d02a", null ],
    [ "GetValue", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#ac33cfd061797335c0c417676abac0d39", null ],
    [ "GetValues", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#ac6cb6578ff791e2f0b0496a72591f267", null ],
    [ "SetValue", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#a20d4c105311d6dd9a33eb7704bc5ee98", null ],
    [ "SetValues", "class_uni_p_r_t_1_1_sdk_1_1_settings_1_1_settings_read_write.html#a3797a47f873ccbdd58d897a4bf80d94e", null ]
];