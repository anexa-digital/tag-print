var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_tspl_lib_1_1_t_s_p_l___utilities =
[
    [ "WindowsFont", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_tspl_lib_1_1_t_s_p_l___utilities.html#afc5da7c1599036f58de5b8b631fb4e5e", null ]
];