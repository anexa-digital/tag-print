var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_box =
[
    [ "ToString", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_box.html#a9524280ad552449282d23c47381b15bb", null ],
    [ "CornerRounding", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_box.html#afadc463745b762937f023a042745fe34", null ],
    [ "End", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_box.html#a95391784db773e6f38b1befa1a2a61b8", null ],
    [ "LineThickness", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_box.html#a2645e5cc684f8f1776d13a031706e7ae", null ],
    [ "Ruler", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_box.html#a7cce02e77712b86e20b067b53c5cbdc2", null ],
    [ "Start", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_box.html#a13451f9d6cafe87d707f548462ff186f", null ]
];