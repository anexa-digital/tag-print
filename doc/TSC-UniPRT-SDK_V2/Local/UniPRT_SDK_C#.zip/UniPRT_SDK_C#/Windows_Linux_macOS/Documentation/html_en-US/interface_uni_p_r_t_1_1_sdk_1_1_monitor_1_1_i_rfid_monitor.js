var interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_rfid_monitor =
[
    [ "RfidReportCallback", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_rfid_monitor.html#a4a5b6661adaebd3b292e6051fb1bf774", null ],
    [ "RfidReportListening", "interface_uni_p_r_t_1_1_sdk_1_1_monitor_1_1_i_rfid_monitor.html#ab634105b67497d2fd354caa43ae438ad", null ]
];