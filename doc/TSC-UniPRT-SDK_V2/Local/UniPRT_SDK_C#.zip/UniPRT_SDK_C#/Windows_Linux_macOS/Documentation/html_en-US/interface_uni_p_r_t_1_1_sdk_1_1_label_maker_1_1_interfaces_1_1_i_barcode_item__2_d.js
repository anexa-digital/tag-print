var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode_item__2_d =
[
    [ "Data", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode_item__2_d.html#a7d5d1784d1b3a01f1731485d24ecd779", null ],
    [ "Start", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_barcode_item__2_d.html#af1d7f5df17948e8673e548f961888492", null ]
];