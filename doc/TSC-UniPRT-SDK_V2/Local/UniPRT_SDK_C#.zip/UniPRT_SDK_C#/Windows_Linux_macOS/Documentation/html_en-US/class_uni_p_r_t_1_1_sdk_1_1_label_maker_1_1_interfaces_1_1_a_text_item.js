var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text_item =
[
    [ "ATextItem", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text_item.html#a86752515384b282e5ac5f259d8a48f97", null ],
    [ "Data", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text_item.html#ad57f6813cac07d28cd5e8d2bbc4b8232", null ],
    [ "FontSize", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text_item.html#ab30d3a76a586a9b9e7dfdc6501245938", null ],
    [ "Start", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_text_item.html#a21158530d0263ad24d62c0f35058c577", null ]
];