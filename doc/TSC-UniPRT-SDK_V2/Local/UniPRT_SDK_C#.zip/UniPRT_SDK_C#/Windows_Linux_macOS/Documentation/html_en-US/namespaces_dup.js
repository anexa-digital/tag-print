var namespaces_dup =
[
    [ "UniPRT", "namespace_uni_p_r_t.html", "namespace_uni_p_r_t" ]
];