var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg =
[
    [ "MaxicodeMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg.html#a669d8a4ade6e5d6c32af5d8147f689d5", null ],
    [ "MaxicodeMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg.html#a624466b61b7cfc7f39139ddd8c3084a2", null ],
    [ "Data", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg.html#a9df731d1b4a07ac519aa7d3b85da1e97", null ],
    [ "Mode", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg.html#a527feceecba35704795a730ec2f5845e", null ],
    [ "PrimaryMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg.html#ae400a3f9586c4b12dffb77a40ddba275", null ],
    [ "RemainingMsg", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_t_s_p_l_1_1_maxicode_msg.html#a0eac9c2213ea2a9f8658a3f56e5e5977", null ]
];