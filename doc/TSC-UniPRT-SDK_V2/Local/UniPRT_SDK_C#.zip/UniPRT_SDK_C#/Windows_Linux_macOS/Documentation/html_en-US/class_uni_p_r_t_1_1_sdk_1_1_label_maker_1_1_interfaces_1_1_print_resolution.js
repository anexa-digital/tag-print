var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_print_resolution =
[
    [ "PrintResolution", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_print_resolution.html#a7a9a31c9080ab9c7a7a0de6c1fc92aa0", null ],
    [ "DotsPerInch", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_print_resolution.html#a9f6d62ada8fd5daae6888a2591b3fcab", null ],
    [ "DotsPerMM", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_print_resolution.html#aed0287ea60b4f01698ebe3a0ee004ad8", null ]
];