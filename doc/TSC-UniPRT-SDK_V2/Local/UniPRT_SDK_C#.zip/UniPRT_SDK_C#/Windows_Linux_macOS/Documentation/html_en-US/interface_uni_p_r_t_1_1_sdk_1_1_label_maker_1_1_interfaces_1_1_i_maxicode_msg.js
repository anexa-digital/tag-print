var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg =
[
    [ "Data", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg.html#a5ad90dd1c385f9aba0b089ed9821219c", null ],
    [ "Mode", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg.html#a9d560167fec7ef8f2e6a4cee08110c14", null ],
    [ "PrimaryMsg", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg.html#a8a78b716c143e8013fa894385fb14da9", null ],
    [ "RemainingMsg", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_maxicode_msg.html#a6b4cd69d46931b0f2c608d951cd43c3b", null ]
];