var class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_barcode_item =
[
    [ "ABarcodeItem", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_barcode_item.html#ae0869af722a93ae9050514d542013d7a", null ],
    [ "Data", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_barcode_item.html#a19de4ca61c76533eb2c0f070b7e57573", null ],
    [ "Height", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_barcode_item.html#afc691974e3dad1c91a512b55170ac62a", null ],
    [ "Start", "class_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_a_barcode_item.html#a41bc8b26d898312823e789dce4e77ea6", null ]
];