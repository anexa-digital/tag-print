var interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_msg_listener_channels =
[
    [ "ListenerChannelConnect", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_msg_listener_channels.html#a8cfca5b134780e891902c0198ae988f2", null ],
    [ "ListenerChannelDisconnect", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_msg_listener_channels.html#a3467b25d701a6495bef57acdd66d3267", null ],
    [ "ListenerChannelDisconnectPermanently", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_msg_listener_channels.html#a7b229944f98c94d96e39cdc6c07ead68", null ],
    [ "ListenerChannelGetNew", "interface_uni_p_r_t_1_1_sdk_1_1_mgmt_1_1_i_mgmt_msg_listener_channels.html#ae3b9aaca20d2166d56bad449755b7fc9", null ]
];