var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rotation =
[
    [ "Rotation", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_rotation.html#af6b1948f8ff48bba51432f04c5b5bfdc", null ]
];