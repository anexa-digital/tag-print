var class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info =
[
    [ "FirmwarePartNumber", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info.html#acd40399fbadfda5256b0553753c5730f", null ],
    [ "FirmwareVersion", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info.html#a1b709bca9d86c153a84569535c985a97", null ],
    [ "HasClockOption", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info.html#acdb9effdedf1044f92bf5169071c86f4", null ],
    [ "HasOdvOption", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info.html#a9c8d100158e1ff917381ba96d17a730c", null ],
    [ "HasRfidOption", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info.html#a729a265d992fc84a09100ff1d8193369", null ],
    [ "Model", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info.html#a7b869e7a084294a382cf7ea7b4407a6d", null ],
    [ "PrintheadResolution", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info.html#a80b0de530deae4606714744092b54563", null ],
    [ "SerialNumber", "class_uni_p_r_t_1_1_sdk_1_1_reports_1_1_printer_info.html#a84944731e5fd16445829c8e93955ae75", null ]
];