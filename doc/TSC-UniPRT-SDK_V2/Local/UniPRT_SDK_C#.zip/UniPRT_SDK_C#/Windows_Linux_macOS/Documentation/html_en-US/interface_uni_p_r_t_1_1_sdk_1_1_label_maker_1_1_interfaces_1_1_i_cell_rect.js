var interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_cell_rect =
[
    [ "Ruler", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_cell_rect.html#aaeaf9cca00625871d9f100ac096adccb", null ],
    [ "Xdim", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_cell_rect.html#acaaa1ecec5ecf7c967b17be768173c16", null ],
    [ "Ydim", "interface_uni_p_r_t_1_1_sdk_1_1_label_maker_1_1_interfaces_1_1_i_cell_rect.html#a7cb338c69111bfd589c2c3a02b7128c3", null ]
];