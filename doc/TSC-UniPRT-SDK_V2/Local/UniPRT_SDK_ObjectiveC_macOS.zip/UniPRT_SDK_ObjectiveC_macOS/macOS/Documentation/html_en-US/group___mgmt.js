var group___mgmt =
[
    [ "JsonMessenger", "interface_json_messenger.html", [
      [ "dispose", "interface_json_messenger.html#addb1d3f5ef8ff4f85f37542fd101d54b", null ],
      [ "initWithCommToPtr:iCommTyp:maxInputMsgCapacity:usingDataPort:", "interface_json_messenger.html#a5826aeb1d5014c70fe2089725762baf9", null ],
      [ "readNextMsg", "interface_json_messenger.html#a2069b4decaa7591405e7c3142065cd0f", null ],
      [ "sendMsgAndWaitForResponseWithCommand:content:maxWaitTimeSecs:", "interface_json_messenger.html#ad644c93052216185168079c83a5356b3", null ],
      [ "sendMsgRawWithDataToSend:", "interface_json_messenger.html#a8213123925027dfc42128bf1d9bd8df8", null ],
      [ "sendMsgWithCommand:content:trackNo:", "interface_json_messenger.html#ab6b9f9f5babc4a791ea898345b8075c8", null ]
    ] ],
    [ "JsonMng", "interface_json_mng.html", [
      [ "initWithMgmtMsg:", "interface_json_mng.html#a8892c3f807f8fef8f7696330466bc617", null ],
      [ "command", "interface_json_mng.html#a89074ff25e2335eefe79c423567579af", null ],
      [ "from", "interface_json_mng.html#aaf836822e465713d203b890b465828bd", null ],
      [ "strResponse", "interface_json_mng.html#a38665b090a147b537efa93ee1859e25e", null ],
      [ "to", "interface_json_mng.html#aa2bcc91504caeb7d040d7d38029b3cee", null ],
      [ "trackNo", "interface_json_mng.html#afadc67e172c7fd90a19e33a4db5f21de", null ]
    ] ]
];