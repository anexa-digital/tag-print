var interface_maxicode_msg_structured_open_system_standard =
[
    [ "initWithMode:year:postalCode:countryCode:serviceClass:remainingMsg:", "interface_maxicode_msg_structured_open_system_standard.html#a32ed2b92c446b33d2b0c0c7a530802a0", null ],
    [ "data", "interface_maxicode_msg_structured_open_system_standard.html#a78cb5682b6063c561748a0a0fc8880c0", null ]
];