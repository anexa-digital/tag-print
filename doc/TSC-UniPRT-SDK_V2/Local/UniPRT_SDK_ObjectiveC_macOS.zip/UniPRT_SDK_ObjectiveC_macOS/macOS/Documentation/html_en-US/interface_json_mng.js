var interface_json_mng =
[
    [ "initWithMgmtMsg:", "interface_json_mng.html#a8892c3f807f8fef8f7696330466bc617", null ],
    [ "command", "interface_json_mng.html#a89074ff25e2335eefe79c423567579af", null ],
    [ "from", "interface_json_mng.html#aaf836822e465713d203b890b465828bd", null ],
    [ "strResponse", "interface_json_mng.html#a38665b090a147b537efa93ee1859e25e", null ],
    [ "to", "interface_json_mng.html#aa2bcc91504caeb7d040d7d38029b3cee", null ],
    [ "trackNo", "interface_json_mng.html#afadc67e172c7fd90a19e33a4db5f21de", null ]
];