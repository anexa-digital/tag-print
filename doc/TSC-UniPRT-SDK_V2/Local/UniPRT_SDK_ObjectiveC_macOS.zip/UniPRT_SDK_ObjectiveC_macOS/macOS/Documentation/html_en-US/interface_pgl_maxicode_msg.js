var interface_pgl_maxicode_msg =
[
    [ "initWithMode:primaryMsg:remainingMsg:", "interface_pgl_maxicode_msg.html#ae7d0205d192517a1ea862fae676e8d2e", null ],
    [ "data", "interface_pgl_maxicode_msg.html#a8e984dad31e445feedc35b2ad950ce5b", null ]
];