var protocol_i_comm_p =
[
    [ "close", "protocol_i_comm-p.html#a07c3d891e1c7f51dcdafc1f7b4177477", null ],
    [ "open", "protocol_i_comm-p.html#a037208def6800346d19d1b0b0826d8de", null ],
    [ "read", "protocol_i_comm-p.html#a1ee3269fdb1c40a8dc820e06d28c9eee", null ],
    [ "readToBinaryWriter:", "protocol_i_comm-p.html#a5904bcbc7e3879e94c792c90d1627902", null ],
    [ "waitForDataWithTimeout:", "protocol_i_comm-p.html#a4f8b286b99f35834af7aee9ed4dc4e28", null ],
    [ "write:", "protocol_i_comm-p.html#a33c8444b53bbfbfbcbeef77ef990400b", null ],
    [ "writeAndWaitForResponse:responseStartTimeOut:responseEndTimeOut:completionToken:", "protocol_i_comm-p.html#a04681cc51318700d15f81d8fa0d5ab5e", null ],
    [ "writeAndWaitForResponseToBinaryWriter:fromBinaryReader:responseStartTimeout:responseEndTimeout:completionToken:", "protocol_i_comm-p.html#ab3af405df2ccee80d329e79f4aa7e4ff", null ],
    [ "writeFromBinaryReader:", "protocol_i_comm-p.html#aab87ca40667ad414f0b41c2dcc98b129", null ],
    [ "bytesAvailable", "protocol_i_comm-p.html#a630894cc0f88be057bc8f9b4695a9ad9", null ],
    [ "descriptor", "protocol_i_comm-p.html#a76e4cf657ebd31de399ba14f0d2a2be4", null ],
    [ "isConnected", "protocol_i_comm-p.html#a3f2032757c69ccbbe652adf8f2af126e", null ]
];