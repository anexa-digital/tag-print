var interface_config =
[
    [ "description", "interface_config.html#a75ca3995b5590125d21b8e9beaea85e1", null ],
    [ "getData", "interface_config.html#a892802c78f2bf896ba353c07771182f9", null ],
    [ "getModel", "interface_config.html#a300f5543eebab881565ebbb80840c1e1", null ],
    [ "getName", "interface_config.html#ae17ac5633ca70af3fdaf8624d4ecd817", null ],
    [ "getNumber", "interface_config.html#a6a73de2a52deb1c5314d3a974f2c7189", null ],
    [ "getProgramFile", "interface_config.html#af7bb93bdeadfb27a8044dd67ccd96db9", null ],
    [ "init", "interface_config.html#aadb6e9ac83603b18eb9c9fced73ef0ef", null ],
    [ "initWithCfgContent:", "interface_config.html#a2764accd7ef264ef3c524bb3055cadea", null ],
    [ "setData:", "interface_config.html#a7f3558a7b5522b0e985348edbc5e2b78", null ],
    [ "setModel:", "interface_config.html#ad12be2e65f47de864ffe261cd22b30a8", null ],
    [ "setName:", "interface_config.html#ae2248439c607a17c1c1e18b9f3168257", null ],
    [ "setNumber:", "interface_config.html#a47c62dadd449c2284fa815d41a274463", null ],
    [ "setProgramFile:", "interface_config.html#a0880fb122d303415156c661609296b10", null ]
];