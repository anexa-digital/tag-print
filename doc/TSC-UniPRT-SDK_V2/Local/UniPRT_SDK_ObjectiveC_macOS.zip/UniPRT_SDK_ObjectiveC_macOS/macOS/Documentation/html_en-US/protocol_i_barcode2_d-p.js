var protocol_i_barcode2_d_p =
[
    [ "description", "protocol_i_barcode2_d-p.html#a72da8817eb2790b503cda7192a9f8a8d", null ]
];