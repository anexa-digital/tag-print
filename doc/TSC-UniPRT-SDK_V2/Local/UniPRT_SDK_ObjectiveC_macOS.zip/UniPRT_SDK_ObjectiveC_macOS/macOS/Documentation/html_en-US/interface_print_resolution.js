var interface_print_resolution =
[
    [ "initWithDotsPerUnit:unit:", "interface_print_resolution.html#af436c24d2907cea7016448e37ba26195", null ]
];