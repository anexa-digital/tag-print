var protocol_i_barcode1_d_p =
[
    [ "description", "protocol_i_barcode1_d-p.html#a561e559eb133397b52dd373451d889e5", null ],
    [ "barcodes", "protocol_i_barcode1_d-p.html#a6f884900e87e252e480650422cb9aff6", null ]
];