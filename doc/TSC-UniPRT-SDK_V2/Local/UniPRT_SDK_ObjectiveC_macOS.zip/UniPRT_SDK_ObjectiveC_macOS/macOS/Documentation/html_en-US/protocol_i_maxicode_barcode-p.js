var protocol_i_maxicode_barcode_p =
[
    [ "description", "protocol_i_maxicode_barcode-p.html#ab0bd156b6085e6e764acf3e38e0809a1", null ],
    [ "data", "protocol_i_maxicode_barcode-p.html#aec0ca00e8e3437f8e589318d0767e7aa", null ]
];