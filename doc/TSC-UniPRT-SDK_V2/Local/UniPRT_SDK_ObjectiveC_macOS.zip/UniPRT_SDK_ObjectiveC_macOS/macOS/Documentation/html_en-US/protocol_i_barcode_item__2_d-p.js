var protocol_i_barcode_item__2_d_p =
[
    [ "data", "protocol_i_barcode_item__2_d-p.html#a4a787583cad076629524f911e0abe182", null ],
    [ "start", "protocol_i_barcode_item__2_d-p.html#ab9746080398e589315aaed327a6deb5e", null ]
];