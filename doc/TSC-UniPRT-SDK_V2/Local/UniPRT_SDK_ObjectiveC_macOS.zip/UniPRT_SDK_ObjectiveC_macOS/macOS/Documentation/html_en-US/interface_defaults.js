var interface_defaults =
[
    [ "alignment", "interface_defaults.html#a177b2ad7d4559838a43bfea0e0700d15", null ],
    [ "cellSize", "interface_defaults.html#ab76e6f0950d656dd14eef7fb35f39bf4", null ],
    [ "cellSizeRect", "interface_defaults.html#a4a4f6c67745c303d0b600791ae08af2f", null ],
    [ "printerResolution", "interface_defaults.html#a89a9319cee29aca3a17b9686ae90250c", null ],
    [ "rotation", "interface_defaults.html#a8827c3d85bc9a365e2e393d9fd09ec9e", null ],
    [ "ruler", "interface_defaults.html#af8ae1a6ea42e50c3ee45da76912a457f", null ],
    [ "SetAlignment:", "interface_defaults.html#abca74d2b6427181b3d9b501bee62bbc4", null ],
    [ "SetCellSize:", "interface_defaults.html#a2f4a891507d84869775a1e91707a1e82", null ],
    [ "SetCellSizeRect:", "interface_defaults.html#a2f1e6f4cc36dae9ef73af75c64faa7dd", null ],
    [ "SetPrinterResolution:", "interface_defaults.html#aeffe8efd039b707f8fbaf521c66b693f", null ],
    [ "SetRotation:", "interface_defaults.html#a3d40fc35163eb2da6560a89d2fba93d4", null ],
    [ "SetRuler:", "interface_defaults.html#a99c8198e15fba056736e31543decd042", null ],
    [ "alignment", "interface_defaults.html#ab777bb36e91f6c5c22f9b0e1dc86e4b7", null ],
    [ "cellSize", "interface_defaults.html#ab6a3de234422fe998200a40d24d53cb0", null ],
    [ "cellSizeRect", "interface_defaults.html#aeb8d46990d6a91e3c279f0d254d120ee", null ],
    [ "printerResolution", "interface_defaults.html#abc959e343c3ac594926952b39858c259", null ],
    [ "rotation", "interface_defaults.html#a2e35f81cdf03be46a99e27d5e6def012", null ],
    [ "ruler", "interface_defaults.html#a28375895070da26e871d5eddc22f4aed", null ]
];