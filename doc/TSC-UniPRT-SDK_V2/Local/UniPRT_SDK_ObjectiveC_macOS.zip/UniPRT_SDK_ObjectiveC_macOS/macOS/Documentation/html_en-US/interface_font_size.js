var interface_font_size =
[
    [ "initWithX:y:", "interface_font_size.html#a7f439ada1c0899d25137fb42a4654005", null ]
];