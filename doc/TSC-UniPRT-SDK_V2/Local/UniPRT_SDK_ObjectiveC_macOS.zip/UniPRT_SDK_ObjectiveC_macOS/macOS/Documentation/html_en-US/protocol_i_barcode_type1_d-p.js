var protocol_i_barcode_type1_d_p =
[
    [ "barcodeType", "protocol_i_barcode_type1_d-p.html#a4e9f10f461d0441ee12718362c24060b", null ]
];