var interface_odv_monitor =
[
    [ "OdvReportCallback", "interface_odv_monitor.html#add4e1a191d3d54d7e6587cbba9c3b4d5", null ],
    [ "initWithCommDescriptor:", "interface_odv_monitor.html#a0e14b1e45aadc1ba83f391f466c53f38", null ],
    [ "initWithJsonComm:", "interface_odv_monitor.html#a7eee9ca0a1e8a611da0195f29c58ad3c", null ],
    [ "initWithTcpComm:", "interface_odv_monitor.html#a44dafd5dbf2836f1aed1ec3a1fff3427", null ],
    [ "SetOdvReportListening:", "interface_odv_monitor.html#a2937e077db4d1cfa07fa07408ee9c71f", null ],
    [ "odvReportCallback", "interface_odv_monitor.html#a190cabce1b08bcb0ea3ea794c43b0e61", null ],
    [ "odvReportListening", "interface_odv_monitor.html#a3d1781fac2c26ccd5070d0da4c94bbef", null ]
];