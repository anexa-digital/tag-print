var interface_pgl_text =
[
    [ "description", "interface_pgl_text.html#afce754e4b5fad0f2a2eb4b35990a2157", null ],
    [ "init", "interface_pgl_text.html#ac1fcc748169840b6d29695a917f94330", null ],
    [ "initWithText:", "interface_pgl_text.html#a5dccb6a9482a1fd66f9dec6f410b0192", null ]
];