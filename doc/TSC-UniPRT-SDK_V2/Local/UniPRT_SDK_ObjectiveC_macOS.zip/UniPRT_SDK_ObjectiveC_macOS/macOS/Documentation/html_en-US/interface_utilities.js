var interface_utilities =
[
    [ "TsplWindowsFontWithImageName:fontSize:rotation:fontStyle:fontFamilyName:content:", "interface_utilities.html#a536f69e35b9d305efcbc5527947bdd34", null ]
];