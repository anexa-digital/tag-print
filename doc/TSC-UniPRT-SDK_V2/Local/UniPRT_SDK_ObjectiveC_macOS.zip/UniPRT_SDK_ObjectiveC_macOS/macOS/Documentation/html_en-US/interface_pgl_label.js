var interface_pgl_label =
[
    [ "addObject:", "interface_pgl_label.html#ad6f080ac48fccb9f67e0c7f3ad0c9eef", null ],
    [ "addRawContent:", "interface_pgl_label.html#a34d1ae09bd48fb438f06f149e2e6935f", null ],
    [ "description", "interface_pgl_label.html#a2953f6fa21a98e245524961179fcb244", null ],
    [ "initWithName:", "interface_pgl_label.html#a084b72ded1ed42bccebc1dd02261bbd4", null ],
    [ "form", "interface_pgl_label.html#a9d0fb6f6c93516b37dfd2f86c6716194", null ],
    [ "name", "interface_pgl_label.html#ac93c470f6e87e75f384ea6080c16dc2f", null ],
    [ "scale", "interface_pgl_label.html#a6b9ef430fb32ad3100743cd872868c98", null ]
];