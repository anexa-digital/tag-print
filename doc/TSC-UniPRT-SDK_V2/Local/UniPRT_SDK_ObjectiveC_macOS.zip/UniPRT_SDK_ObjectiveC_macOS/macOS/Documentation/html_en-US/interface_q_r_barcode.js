var interface_q_r_barcode =
[
    [ "description", "interface_q_r_barcode.html#a56eee5fc33a78488d0833aa0fe09bf20", null ],
    [ "init", "interface_q_r_barcode.html#ae79d9c1411df553ef4b84b88adfb164b", null ],
    [ "initWithStart:data:", "interface_q_r_barcode.html#af9c1ad34ec79fac55ff1f8dc81979431", null ],
    [ "initWithStart:manuallyEncodedData:", "interface_q_r_barcode.html#af5274c1adcef84dc3804b9caf2e6f543", null ]
];