var interface_printer_monitor =
[
    [ "AlertStatusCallback", "interface_printer_monitor.html#a7a0656a13a2709e103fe24e0da7926a4", null ],
    [ "DisplayStatusCallback", "interface_printer_monitor.html#a9c1350443f6eb45649ac61cba964545f", null ],
    [ "EngineStatusCallback", "interface_printer_monitor.html#a28a158c1491480f38f25d80642ff8f9e", null ],
    [ "getEngineStatus", "interface_printer_monitor.html#a49593e3dbcfa06f14afdcffd98aca2cd", null ],
    [ "getFaultStatus", "interface_printer_monitor.html#a8fc0e17acec3a67ec0fd48bc3720996d", null ],
    [ "getPrinterInfo", "interface_printer_monitor.html#ad14199f37407ae0c8c92c96616e5881e", null ],
    [ "initWithCommDescriptor:", "interface_printer_monitor.html#a8a5e1a31232205e2663edd20ff0b0b02", null ],
    [ "initWithJsonComm:", "interface_printer_monitor.html#a080d86843306c3e6b76a535b795b55f4", null ],
    [ "initWithTcpComm:", "interface_printer_monitor.html#a162b5660badcc65c8c3e4c7f32f49962", null ],
    [ "SetAlertStatusListening:", "interface_printer_monitor.html#ae0f4f8b9816b44ba69b0fd1216d1c40f", null ],
    [ "SetDisplayStatusListening:", "interface_printer_monitor.html#ae7b88a5f33d95ef96310a2a1f93c991a", null ],
    [ "SetEngineStatusListening:", "interface_printer_monitor.html#a5460d780e95c766f6a00682abedf71e9", null ],
    [ "alertStatusCallback", "interface_printer_monitor.html#a8caadc56510dbf5a4c33d3c40e082c79", null ],
    [ "alertStatusListening", "interface_printer_monitor.html#a4b3ade732ee86891229d29076cca7115", null ],
    [ "displayStatusCallback", "interface_printer_monitor.html#afed4865406d32044098ab7cbbdb23720", null ],
    [ "displayStatusListening", "interface_printer_monitor.html#a11ff96a07db063e6c948d72f8be659d6", null ],
    [ "engineStatusCallback", "interface_printer_monitor.html#a81fc87ce175b64747f53890103c13c49", null ],
    [ "engineStatusListening", "interface_printer_monitor.html#acbca044f9e7ab7a77edaf5ad9d224816", null ]
];