var interface_rfid_report =
[
    [ "data", "interface_rfid_report.html#ae9da90fec940702389f5401dbff2c6f5", null ],
    [ "dataType", "interface_rfid_report.html#a525726f5dd9079bb29c71422872a78ea", null ],
    [ "failed", "interface_rfid_report.html#aabcc047bf493481a317e3a6e7c91f67d", null ],
    [ "isWriteOperation", "interface_rfid_report.html#aaad8974a6ce12d3d121d17699b41f5e8", null ],
    [ "rawReport", "interface_rfid_report.html#ac1a27148641e14c090c1a7e067cc5277", null ]
];