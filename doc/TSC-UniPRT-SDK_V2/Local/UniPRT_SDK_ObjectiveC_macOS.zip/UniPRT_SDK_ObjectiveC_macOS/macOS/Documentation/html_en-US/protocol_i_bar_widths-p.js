var protocol_i_bar_widths_p =
[
    [ "narrowBar", "protocol_i_bar_widths-p.html#af32103ec3faab9dafffdedff590d1968", null ],
    [ "ruler", "protocol_i_bar_widths-p.html#ac612d4366d159d12386567b9245cf476", null ],
    [ "wideBar", "protocol_i_bar_widths-p.html#a264672cfdcdc3788505d4a9f084e46c1", null ]
];