var interface_rfid___write =
[
    [ "description", "interface_rfid___write.html#a9bd433b1c14a9cc3f17e5cf3d1ff56e1", null ],
    [ "init", "interface_rfid___write.html#a464d6ff3ad0ffd07f8f240d1cb98cf6d", null ],
    [ "initWithMemBlock:data:", "interface_rfid___write.html#a4b453630f504be5c95c06180c965d782", null ]
];