var interface___picture =
[
    [ "description", "interface___picture.html#afabb3647364c9569183ae458db2fb8b3", null ],
    [ "initWithRow:column:imageName:", "interface___picture.html#ad0df0bc92a99dbe6ae9ddc2e3b696a13", null ],
    [ "column", "interface___picture.html#a57aa2e50b4077445fd65891dee62d146", null ],
    [ "imageName", "interface___picture.html#afefc8627d6afc2d5b98be88808027114", null ],
    [ "row", "interface___picture.html#a45bcf40dc61ff3e9149b025c11348c85", null ]
];