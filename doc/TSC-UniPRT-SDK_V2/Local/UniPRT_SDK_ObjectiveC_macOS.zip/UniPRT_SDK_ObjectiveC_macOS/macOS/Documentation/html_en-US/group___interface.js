var group___interface =
[
    [ "APair", "interface_a_pair.html", [
      [ "initWithX:y:", "interface_a_pair.html#a56c82642c6807f1879da636cfc0fb139", null ],
      [ "x", "interface_a_pair.html#a5f8e07575f898ee32114b1f5d1c9d8be", null ],
      [ "y", "interface_a_pair.html#a54c68a305f8793eddc2e996239500875", null ]
    ] ],
    [ "Points", "interface_points.html", [
      [ "initWithX:y:", "interface_points.html#aeb0b0071e74dad566f5e4ab39b61c052", null ]
    ] ],
    [ "PrintResolution", "interface_print_resolution.html", [
      [ "initWithDotsPerUnit:unit:", "interface_print_resolution.html#af436c24d2907cea7016448e37ba26195", null ]
    ] ],
    [ "Ruler", "interface_ruler.html", [
      [ "initWithScale:", "interface_ruler.html#afec401ba8f0d58febc99087a8e75313d", null ],
      [ "scale", "interface_ruler.html#a04945250856b4fbc6e6396e10a7dff07", null ]
    ] ],
    [ "Defaults", "interface_defaults.html", [
      [ "alignment", "interface_defaults.html#a177b2ad7d4559838a43bfea0e0700d15", null ],
      [ "cellSize", "interface_defaults.html#ab76e6f0950d656dd14eef7fb35f39bf4", null ],
      [ "cellSizeRect", "interface_defaults.html#a4a4f6c67745c303d0b600791ae08af2f", null ],
      [ "printerResolution", "interface_defaults.html#a89a9319cee29aca3a17b9686ae90250c", null ],
      [ "rotation", "interface_defaults.html#a8827c3d85bc9a365e2e393d9fd09ec9e", null ],
      [ "ruler", "interface_defaults.html#af8ae1a6ea42e50c3ee45da76912a457f", null ],
      [ "SetAlignment:", "interface_defaults.html#abca74d2b6427181b3d9b501bee62bbc4", null ],
      [ "SetCellSize:", "interface_defaults.html#a2f4a891507d84869775a1e91707a1e82", null ],
      [ "SetCellSizeRect:", "interface_defaults.html#a2f1e6f4cc36dae9ef73af75c64faa7dd", null ],
      [ "SetPrinterResolution:", "interface_defaults.html#aeffe8efd039b707f8fbaf521c66b693f", null ],
      [ "SetRotation:", "interface_defaults.html#a3d40fc35163eb2da6560a89d2fba93d4", null ],
      [ "SetRuler:", "interface_defaults.html#a99c8198e15fba056736e31543decd042", null ],
      [ "alignment", "interface_defaults.html#ab777bb36e91f6c5c22f9b0e1dc86e4b7", null ],
      [ "cellSize", "interface_defaults.html#ab6a3de234422fe998200a40d24d53cb0", null ],
      [ "cellSizeRect", "interface_defaults.html#aeb8d46990d6a91e3c279f0d254d120ee", null ],
      [ "printerResolution", "interface_defaults.html#abc959e343c3ac594926952b39858c259", null ],
      [ "rotation", "interface_defaults.html#a2e35f81cdf03be46a99e27d5e6def012", null ],
      [ "ruler", "interface_defaults.html#a28375895070da26e871d5eddc22f4aed", null ]
    ] ],
    [ "ABarcode1D", "interface_a_barcode1_d.html", [
      [ "init", "interface_a_barcode1_d.html#a54f5365c65a9e9edaf130babc109cacc", null ],
      [ "initWithBarcodeItem:", "interface_a_barcode1_d.html#af4e26120de3f04b5e78d674d36b48fa3", null ],
      [ "barcodes", "interface_a_barcode1_d.html#a950f6af8f6d5f1b860e4c6b6a936fbc1", null ],
      [ "barcodeType", "interface_a_barcode1_d.html#ae2d38ddc8ce115d091bdc19e6e9cf5d5", null ],
      [ "barWidths", "interface_a_barcode1_d.html#a53e6d28ed9f8ba2cc92f82b487ccd890", null ],
      [ "printHumanReadable", "interface_a_barcode1_d.html#a777f28be340fe31cd74d370317561615", null ],
      [ "rotation", "interface_a_barcode1_d.html#a651a5701ea30853b1f740cde72428675", null ],
      [ "ruler", "interface_a_barcode1_d.html#ae9bc11b38413d11f1fc3fa22902210b6", null ]
    ] ],
    [ "ABarcodeItem", "interface_a_barcode_item.html", [
      [ "initWithStart:data:", "interface_a_barcode_item.html#a2de5aa7e7f420feca9762daa4c06aceb", null ]
    ] ],
    [ "ABarWidths", "interface_a_bar_widths.html", [
      [ "initWithNarrowBar:wideBar:", "interface_a_bar_widths.html#ac6c0b5a872bfb002a62dbeb3ac02362e", null ],
      [ "NS_UNAVAILABLE", "interface_a_bar_widths.html#ad962c29cee662ad79a32157aaeedd44d", null ]
    ] ],
    [ "BarcodeItem", "interface_barcode_item.html", [
      [ "initWithStart:data:", "interface_barcode_item.html#ae397ae7a3da96f3cbe8865bb0612d8fa", null ],
      [ "initWithStart:height:data:", "interface_barcode_item.html#a04a918662b6b2d8ffa9ea41de73815ee", null ],
      [ "initWithXStart:yStart:data:", "interface_barcode_item.html#a7de4f74717aa56f072df6202714650e0", null ],
      [ "initWithXStart:yStart:height:data:", "interface_barcode_item.html#a2a1b711df43bf4ad69f832c4731a3967", null ]
    ] ],
    [ "BarcodeTypeEnum_1D", "class_barcode_type_enum__1_d.html", null ],
    [ "<IBarcode1D>", "protocol_i_barcode1_d-p.html", [
      [ "description", "protocol_i_barcode1_d-p.html#a561e559eb133397b52dd373451d889e5", null ],
      [ "barcodes", "protocol_i_barcode1_d-p.html#a6f884900e87e252e480650422cb9aff6", null ]
    ] ],
    [ "<IBarcode_1D_Properties>", "protocol_i_barcode__1_d___properties-p.html", [
      [ "barWidths", "protocol_i_barcode__1_d___properties-p.html#a9e37b17da2354c8812d8f58096e03d0e", null ],
      [ "printHumanReadable", "protocol_i_barcode__1_d___properties-p.html#ab562e9f75af103e4f1e5f27260544abd", null ],
      [ "ruler", "protocol_i_barcode__1_d___properties-p.html#a30ee38de75906fe9266401030847e5e4", null ]
    ] ],
    [ "<IBarcodeItem>", "protocol_i_barcode_item-p.html", [
      [ "data", "protocol_i_barcode_item-p.html#ad4177389ffdcd0b0aba17f554b980832", null ],
      [ "height", "protocol_i_barcode_item-p.html#ac56bbe7ae0e99d4a9baa774081cc7ac7", null ],
      [ "start", "protocol_i_barcode_item-p.html#a0f1858a8d37ecf1c453d474417009bbf", null ]
    ] ],
    [ "<IBarcodeType1D>", "protocol_i_barcode_type1_d-p.html", [
      [ "barcodeType", "protocol_i_barcode_type1_d-p.html#a4e9f10f461d0441ee12718362c24060b", null ]
    ] ],
    [ "<IBarWidths>", "protocol_i_bar_widths-p.html", [
      [ "narrowBar", "protocol_i_bar_widths-p.html#af32103ec3faab9dafffdedff590d1968", null ],
      [ "ruler", "protocol_i_bar_widths-p.html#ac612d4366d159d12386567b9245cf476", null ],
      [ "wideBar", "protocol_i_bar_widths-p.html#a264672cfdcdc3788505d4a9f084e46c1", null ]
    ] ],
    [ "ABarcode2D", "interface_a_barcode2_d.html", [
      [ "NS_REQUIRES_SUPER", "interface_a_barcode2_d.html#a61eba0ec5db2b1efea93e6586095d46d", null ],
      [ "data", "interface_a_barcode2_d.html#a8898e718041ec090e55933ca026809aa", null ],
      [ "rotation", "interface_a_barcode2_d.html#a0e641008f43f278929383d516a1411da", null ],
      [ "ruler", "interface_a_barcode2_d.html#a4e15d1fcb28e737fbdd1d3ea1e85a123", null ],
      [ "start", "interface_a_barcode2_d.html#a54443e824875f31ae5949e2192e3c310", null ]
    ] ],
    [ "ACellSquare", "interface_a_cell_square.html", [
      [ "initWithXDim:ruler:", "interface_a_cell_square.html#ac87f919a9e3a9cbd7e828a131b05980b", null ],
      [ "NS_DESIGNATED_INITIALIZER", "interface_a_cell_square.html#aaaea5cb68534dbe315aeb3534a49fb0d", null ],
      [ "ruler", "interface_a_cell_square.html#a18f491381172dfd0d32e4ed0af89ea49", null ],
      [ "xdim", "interface_a_cell_square.html#a9b677d528e5d8f9ed4db6861913901de", null ]
    ] ],
    [ "ADataMatrix", "interface_a_data_matrix.html", [
      [ "ctrlChar:", "interface_a_data_matrix.html#a9898574a28a2e3632d9d373dd3021019", null ],
      [ "init", "interface_a_data_matrix.html#a86f8d3be5f3fd6a1bdb18fc71d2e627e", null ],
      [ "initWithStart:data:", "interface_a_data_matrix.html#a19cbec0f9ed89e131ab14dfcf7470007", null ],
      [ "cellSize", "interface_a_data_matrix.html#a2ab937a57340a439040b311c7e719842", null ],
      [ "ctrlCharDelimiter", "interface_a_data_matrix.html#ac3dd8d57855bad3c3ab80971cdfaf6ff", null ],
      [ "data", "interface_a_data_matrix.html#a8ee389c3b9d3c1f8bfa1aceaf8761751", null ],
      [ "fnc1", "interface_a_data_matrix.html#a4f65ba611f41b6f9bb5b5c7e8ca3fb29", null ],
      [ "rectangle", "interface_a_data_matrix.html#af13d7c83af8be1e071942365d162993b", null ],
      [ "rowsCols", "interface_a_data_matrix.html#a98ba16157a33bfa69c8a02a96a318de5", null ],
      [ "start", "interface_a_data_matrix.html#aceb90eecb2d6d5c84bb7d24290473bc7", null ]
    ] ],
    [ "CellRect", "interface_cell_rect.html", [
      [ "init", "interface_cell_rect.html#abf04d34b00b2ca782419996bdbbd44e5", null ],
      [ "initWithXDim:yDim:ruler:", "interface_cell_rect.html#a9787cfec81e2373a5f27e6b6114856c5", null ],
      [ "ydim", "interface_cell_rect.html#a2870249fb77483c2ebbabab9523d227f", null ]
    ] ],
    [ "CellSquare", "interface_cell_square.html", [
      [ "init", "interface_cell_square.html#ab314da598af154b5b3a3e97cb90f24f0", null ],
      [ "initWithXDim:ruler:", "interface_cell_square.html#aea31e355ea16449dd5b42836358e8a24", null ]
    ] ],
    [ "<IBarcode2D>", "protocol_i_barcode2_d-p.html", [
      [ "description", "protocol_i_barcode2_d-p.html#a72da8817eb2790b503cda7192a9f8a8d", null ]
    ] ],
    [ "<IBarcodeItem_2D>", "protocol_i_barcode_item__2_d-p.html", [
      [ "data", "protocol_i_barcode_item__2_d-p.html#a4a787583cad076629524f911e0abe182", null ],
      [ "start", "protocol_i_barcode_item__2_d-p.html#ab9746080398e589315aaed327a6deb5e", null ]
    ] ],
    [ "<ICellRect>", "protocol_i_cell_rect-p.html", [
      [ "ydim", "protocol_i_cell_rect-p.html#a51a70aaecff2c975d5bcc4f5e0b51cb9", null ]
    ] ],
    [ "<ICellSquare>", "protocol_i_cell_square-p.html", [
      [ "ruler", "protocol_i_cell_square-p.html#a94fe6cb92fe74fa572db47bf93bc8b14", null ],
      [ "xdim", "protocol_i_cell_square-p.html#a5891256ffc5cd4c535de9dfdcc1841ed", null ]
    ] ],
    [ "<IPositionRuler>", "protocol_i_position_ruler-p.html", [
      [ "ruler", "protocol_i_position_ruler-p.html#a1a352c32ca50bbd5df41053650c4cc20", null ]
    ] ],
    [ "<IRectangleCell>", "protocol_i_rectangle_cell-p.html", [
      [ "cellSize", "protocol_i_rectangle_cell-p.html#a511cead75ad99aee21dc922f62a82802", null ]
    ] ],
    [ "<ISquareCell>", "protocol_i_square_cell-p.html", [
      [ "cellSize", "protocol_i_square_cell-p.html#acfe71a8235a9295adaca9a1c771a8509", null ]
    ] ],
    [ "<IStartPoint>", "protocol_i_start_point-p.html", [
      [ "start", "protocol_i_start_point-p.html#accb7af36f937efca2fe79fb91f8a6030", null ]
    ] ],
    [ "AAztecBarcode", "interface_a_aztec_barcode.html", [
      [ "getErrCorrectionPercent", "interface_a_aztec_barcode.html#a21bcb25b14e8e560af96c6ab26a82776", null ],
      [ "getLayersWithinRange", "interface_a_aztec_barcode.html#aaea9b07ebebe024e19e98f463f91f31a", null ],
      [ "hasLayers", "interface_a_aztec_barcode.html#aef03de7f1680157bf9a99fc1aa0e227b", null ],
      [ "init", "interface_a_aztec_barcode.html#a09c0081ffa085f0c41651d11be62fdc7", null ],
      [ "initWithStart:data:", "interface_a_aztec_barcode.html#aa793c9d2e8b08dacaffaa8fcfa413a16", null ],
      [ "cellSize", "interface_a_aztec_barcode.html#ad04765aee4421b9cd0739aed78e5e7e0", null ],
      [ "fixedErrCorrection", "interface_a_aztec_barcode.html#afa22e888d082a4ece4c9d8de7adad8b9", null ],
      [ "layers", "interface_a_aztec_barcode.html#a4f088da480db2c77a0d7c592e428b3c3", null ],
      [ "type", "interface_a_aztec_barcode.html#a2d7332c47c5233eb0cb5d7e3772e1716", null ]
    ] ],
    [ "AztecCodeTypeEnum", "class_aztec_code_type_enum.html", null ],
    [ "AMaxicodebarcode", "class_a_maxicodebarcode.html", null ],
    [ "AMaxicodeMsg", "interface_a_maxicode_msg.html", [
      [ "init", "interface_a_maxicode_msg.html#a4ff7d77c445fed36b5e56250289073b1", null ],
      [ "initWithMode:primaryMsg:remainingMsg:", "interface_a_maxicode_msg.html#a8c2c59a24fca071303a9a64fe341955a", null ],
      [ "data", "interface_a_maxicode_msg.html#a0fb11b15c5e8f7c3607dae975923f69e", null ],
      [ "mode", "interface_a_maxicode_msg.html#aef64cc203cd73ed67158c5dd6d2fca16", null ],
      [ "primaryMsg", "interface_a_maxicode_msg.html#ad51494900a87c50751065ce96a6f59a6", null ],
      [ "remainingMsg", "interface_a_maxicode_msg.html#af202025d2ec7f8bfb847440ea408e8b5", null ]
    ] ],
    [ "AMaxicodeMsgStructured", "interface_a_maxicode_msg_structured.html", [
      [ "data", "interface_a_maxicode_msg_structured.html#a88ee55f7cae762534ddebc6b29025fd8", null ],
      [ "init", "interface_a_maxicode_msg_structured.html#a6c30d40bfb6499befcf7e87516f740b6", null ],
      [ "initWithMode:postalCode:countryCode:serviceClass:remainingMsg:", "interface_a_maxicode_msg_structured.html#ae665587166e1497097d0c03e4854f215", null ],
      [ "countryCode", "interface_a_maxicode_msg_structured.html#a8a6ce5ccf03faf9b62f5dff9c57141c5", null ],
      [ "mode", "interface_a_maxicode_msg_structured.html#a3f987abc9c8a84ebc6ec46fdb18e0f70", null ],
      [ "postalCode", "interface_a_maxicode_msg_structured.html#ab8ada2889a441778f1fb973496a2b648", null ],
      [ "remainingMsg", "interface_a_maxicode_msg_structured.html#a9d159f230394d3a6ec170559ffdea10d", null ],
      [ "serviceClass", "interface_a_maxicode_msg_structured.html#a1ed558d1ebfc7eb9e44220e334651cbd", null ]
    ] ],
    [ "<IMaxicodeBarcode>", "protocol_i_maxicode_barcode-p.html", [
      [ "description", "protocol_i_maxicode_barcode-p.html#ab0bd156b6085e6e764acf3e38e0809a1", null ],
      [ "data", "protocol_i_maxicode_barcode-p.html#aec0ca00e8e3437f8e589318d0767e7aa", null ]
    ] ],
    [ "<IMaxicodeData>", "protocol_i_maxicode_data-p.html", [
      [ "data", "protocol_i_maxicode_data-p.html#aa16323dce7a081fa72bb0335abe047ab", null ],
      [ "mode", "protocol_i_maxicode_data-p.html#a3d064f31a3d55cb47493c5014506ed49", null ]
    ] ],
    [ "<IMaxicodeMsg>", "protocol_i_maxicode_msg-p.html", [
      [ "primaryMsg", "protocol_i_maxicode_msg-p.html#ab413002cbc6aeb97d14e9eba7f6b2ae8", null ],
      [ "remainingMsg", "protocol_i_maxicode_msg-p.html#a72bd572e0872fff6259bc55f9ccbd166", null ]
    ] ],
    [ "<IMaxicodeMsgStructured>", "protocol_i_maxicode_msg_structured-p.html", [
      [ "countryCode", "protocol_i_maxicode_msg_structured-p.html#a6cc0195ddc2e6849a8a4221e3d89973d", null ],
      [ "postalCode", "protocol_i_maxicode_msg_structured-p.html#a04e243610c5dbedb7061086f0780de95", null ],
      [ "remainingMsg", "protocol_i_maxicode_msg_structured-p.html#a7534bf187e05f5f92e0971fb093461e9", null ],
      [ "serviceClass", "protocol_i_maxicode_msg_structured-p.html#a69d2e4df416efb90c1c7fd3518a2f306", null ]
    ] ],
    [ "<IMaxicodeMsgStructuredOpenSystemStandard>", "protocol_i_maxicode_msg_structured_open_system_standard-p.html", [
      [ "countryCode", "protocol_i_maxicode_msg_structured_open_system_standard-p.html#a2b582dfa74b881f36e6def2a63948f92", null ],
      [ "postalCode", "protocol_i_maxicode_msg_structured_open_system_standard-p.html#acbad0d08b66c698cac3947286b917d6f", null ],
      [ "remainingMsg", "protocol_i_maxicode_msg_structured_open_system_standard-p.html#a3347568978f247af70d24b6c7fcd62c3", null ],
      [ "serviceClass", "protocol_i_maxicode_msg_structured_open_system_standard-p.html#a2ff4307b18f28c5d7c306aa17e54afd8", null ],
      [ "year", "protocol_i_maxicode_msg_structured_open_system_standard-p.html#a094313d37d8dc5e3c903fd4a82848833", null ]
    ] ],
    [ "MaxicodeModeEnum", "class_maxicode_mode_enum.html", null ],
    [ "APdf417", "interface_a_pdf417.html", [
      [ "initWithStart:data:", "interface_a_pdf417.html#a87acaf7a0ab3f462f1a6804723e0f4f2", null ],
      [ "limitRange:minimum:maximum:", "interface_a_pdf417.html#a4a261aadd155495cbd6c33ddd29c29d0", null ],
      [ "cellSize", "interface_a_pdf417.html#aa4d2916a9b1c935c57cb8801e370f974", null ],
      [ "columns", "interface_a_pdf417.html#a94a575986eabd042fccb00cb608d6d89", null ],
      [ "data", "interface_a_pdf417.html#a2c4a8184aa096be68a7df81e58c2e24c", null ],
      [ "errorCorrection", "interface_a_pdf417.html#a86b31833fd5b4f44d5601a8208a8caf7", null ],
      [ "rows", "interface_a_pdf417.html#a7ae135a3e1f46e7a016c623bdd790b85", null ],
      [ "start", "interface_a_pdf417.html#ad3a6d64dd2e3ac4a3b6526b9e66020ca", null ]
    ] ],
    [ "QRCodeErrorCorrectionEnum", "class_q_r_code_error_correction_enum.html", null ],
    [ "QRCodeManualEncodingEnum", "class_q_r_code_manual_encoding_enum.html", null ],
    [ "QRCodeMaskEnum", "class_q_r_code_mask_enum.html", null ],
    [ "QRCodeModelEnum", "class_q_r_code_model_enum.html", null ],
    [ "<IPair>", "protocol_i_pair-p.html", [
      [ "x", "protocol_i_pair-p.html#ac5a9a992f4f4bef47ca2fb9187591240", null ],
      [ "y", "protocol_i_pair-p.html#a8a5103110ed6f69f16ab52e16db66e1d", null ]
    ] ],
    [ "<IPoint>", "protocol_i_point-p.html", null ],
    [ "ScaleEnum", "class_scale_enum.html", null ],
    [ "<IRuler>", "protocol_i_ruler-p.html", [
      [ "scale", "protocol_i_ruler-p.html#a1e4002e9d4b260457e18d09e00260ec4", null ]
    ] ],
    [ "FontSize", "interface_font_size.html", [
      [ "initWithX:y:", "interface_font_size.html#a7f439ada1c0899d25137fb42a4654005", null ]
    ] ],
    [ "FontStyleEnum", "class_font_style_enum.html", null ],
    [ "<IFont>", "protocol_i_font-p.html", [
      [ "fontName", "protocol_i_font-p.html#abc60adf90f951be1fa570f2a708edfd8", null ]
    ] ],
    [ "<IFontSettings>", "protocol_i_font_settings-p.html", null ],
    [ "<IFontSize>", "protocol_i_font_size-p.html", null ],
    [ "<IFontSizeUnits>", "protocol_i_font_size_units-p.html", [
      [ "fontSizeUnits", "protocol_i_font_size_units-p.html#a73f6200cf9a4ffd78f7e49142a3d91d2", null ]
    ] ],
    [ "<ILabel>", "protocol_i_label-p.html", [
      [ "addObject:", "protocol_i_label-p.html#a9f289a03580e964a82e28329be5b6a8b", null ],
      [ "addRawContent:", "protocol_i_label-p.html#ade55384be2299a36e3070cf0e4a75a21", null ],
      [ "description", "protocol_i_label-p.html#a7d192db7decea78079d7a56a4cba243b", null ],
      [ "name", "protocol_i_label-p.html#a00bff5aec498c0d6a819c177f4bc9e56", null ]
    ] ],
    [ "APicture", "interface_a_picture.html", [
      [ "description", "interface_a_picture.html#a53edab9f15ea965821ab9a3c1980b344", null ],
      [ "initWithStart:imageName:", "interface_a_picture.html#aebee0dab47515069a639fc968628b714", null ],
      [ "ImageName", "interface_a_picture.html#acbbb90344f94859b72ee7a5db04fd48a", null ],
      [ "Ruler", "interface_a_picture.html#ab715731dc740792894921c01a9a2f418", null ],
      [ "Start", "interface_a_picture.html#adb10afb846d1bd747fae163835c31e06", null ]
    ] ],
    [ "<IPicture>", "protocol_i_picture-p.html", [
      [ "description", "protocol_i_picture-p.html#a50d570bc8d270ac3425687d728edff56", null ],
      [ "ImageName", "protocol_i_picture-p.html#a112f97a5e3b702fe60ac9084fffa6edb", null ],
      [ "Ruler", "protocol_i_picture-p.html#a3b553b470e3dbdc4a9e3fd0c3ee20f85", null ],
      [ "Start", "protocol_i_picture-p.html#a71ca8ca200bbe356954c6d1ce769189e", null ]
    ] ],
    [ "ARfidWrite", "interface_a_rfid_write.html", [
      [ "description", "interface_a_rfid_write.html#a71d178482371ab8cb1b34687851790ca", null ],
      [ "initWithMemBlock:data:", "interface_a_rfid_write.html#ac795deec4bb51b02dbe1109bd6917096", null ],
      [ "NS_DESIGNATED_INITIALIZER", "interface_a_rfid_write.html#ab600f9229ade9738ce2035aff86cb5f1", null ],
      [ "data", "interface_a_rfid_write.html#a0880ef588d1d029a46b396aa7c31404f", null ],
      [ "memory", "interface_a_rfid_write.html#a1fa670e7cb5630e19f9cc5c96eb5f124", null ],
      [ "offsetFromStart", "interface_a_rfid_write.html#af742679f0b7c3e9f12dc485d6c35df0d", null ],
      [ "password", "interface_a_rfid_write.html#a5056445234f68cca9428f91ffae4b3f8", null ],
      [ "passwordType", "interface_a_rfid_write.html#ab7ce4ab1f18b43a16bf7262d26f4c724", null ]
    ] ],
    [ "<IRfidBankSelect>", "protocol_i_rfid_bank_select-p.html", [
      [ "memory", "protocol_i_rfid_bank_select-p.html#a8b87ad2680f34ed7ea045b4be0d8973b", null ]
    ] ],
    [ "<IRfidBitField>", "protocol_i_rfid_bit_field-p.html", [
      [ "data", "protocol_i_rfid_bit_field-p.html#a01fccb4213cd10596a696aed7cee80c5", null ],
      [ "offsetFromStart", "protocol_i_rfid_bit_field-p.html#a681eea231066f333b46ab344cba35944", null ]
    ] ],
    [ "<IRfidPassword>", "protocol_i_rfid_password-p.html", [
      [ "password", "protocol_i_rfid_password-p.html#abd32782624f0cd6a71b66c7554a1f647", null ],
      [ "passwordType", "protocol_i_rfid_password-p.html#aa49a7b5dc32f5d239718eba851627124", null ]
    ] ],
    [ "<IRfidWrite>", "protocol_i_rfid_write-p.html", [
      [ "data", "protocol_i_rfid_write-p.html#a936d23647f62f0134c9075a0bad3bbc1", null ],
      [ "memory", "protocol_i_rfid_write-p.html#a10e805c5fd3dd2ccb47815799aad1601", null ],
      [ "password", "protocol_i_rfid_write-p.html#a25cad243cb4bb2e879a89b72ba86fef2", null ]
    ] ],
    [ "RfidConvert", "interface_rfid_convert.html", [
      [ "toBytesFromUInt:", "interface_rfid_convert.html#a8209876a44624d55808e06d4d041f091", null ],
      [ "toBytesFromUShort:", "interface_rfid_convert.html#a536130cff8f5562b20d18b3ec18d0083", null ],
      [ "toHexFromASCIIString:", "interface_rfid_convert.html#aaca4496d6698f5d6d549a0e4aec7952e", null ],
      [ "toHexFromBytes:", "interface_rfid_convert.html#a91bb0639ab59d7a434ea24f224a2ef1d", null ],
      [ "toHexFromUInt:", "interface_rfid_convert.html#a4583f7eba75dd1b2e0e375c996606fed", null ],
      [ "toHexFromUShort:", "interface_rfid_convert.html#a36572d3a2577d070562636edffd7314a", null ],
      [ "toUInt:", "interface_rfid_convert.html#aea647d14b357de30e434521dbe35c817", null ],
      [ "toUShort:", "interface_rfid_convert.html#a9769b5c035b2d2d8f3640ad05bb7508d", null ]
    ] ],
    [ "RfidMemBlockEnum", "class_rfid_mem_block_enum.html", null ],
    [ "RfidPasswordTypeEnum", "class_rfid_password_type_enum.html", null ],
    [ "AlignEnum", "class_align_enum.html", null ],
    [ "<IAlignment>", "protocol_i_alignment-p.html", [
      [ "alignment", "protocol_i_alignment-p.html#a80f54d0bc06c884c42b394783fd8df13", null ]
    ] ],
    [ "<IRotation>", "protocol_i_rotation-p.html", [
      [ "rotation", "protocol_i_rotation-p.html#a50d3b511c50c41b864a24991831a2b18", null ]
    ] ],
    [ "RotateEnum", "class_rotate_enum.html", null ],
    [ "ALine", "interface_a_line.html", [
      [ "description", "interface_a_line.html#afabbbea028f41b2ed7fbeabf8e2c74b1", null ],
      [ "initWithStart:end:lineThickness:", "interface_a_line.html#ac9f3f32d7c5075127ad81c9eca64c72d", null ],
      [ "end", "interface_a_line.html#a1d4c7c77580efa285ba17dba32904697", null ],
      [ "lineThickness", "interface_a_line.html#af0f8022c39c36e6139e8f5df8ad9820d", null ],
      [ "ruler", "interface_a_line.html#afe9ee71cf3972cdbccd944bf10b77ffa", null ],
      [ "start", "interface_a_line.html#ad827571287ce272b5e66e470ce495312", null ]
    ] ],
    [ "<IBox>", "protocol_i_box-p.html", [
      [ "cornerRounding", "protocol_i_box-p.html#ab0fa8ff9f837d8b42c8dc8fcb0e3fb9c", null ],
      [ "end", "protocol_i_box-p.html#a289584f129f3346554cea0aa9ca914ee", null ],
      [ "lineThickness", "protocol_i_box-p.html#a54833f0e24772dd6811e046f89bea6b8", null ],
      [ "ruler", "protocol_i_box-p.html#a03392db0acc18481eafb170ecb7384e2", null ],
      [ "start", "protocol_i_box-p.html#a5534780059beb217bc60004c5554b264", null ]
    ] ],
    [ "<ILine>", "protocol_i_line-p.html", [
      [ "end", "protocol_i_line-p.html#ae2f0ca5d192d5982d23749639ebcdee0", null ],
      [ "lineThickness", "protocol_i_line-p.html#affd8f8cfe44f414f712cf3c8cee3dc8c", null ],
      [ "ruler", "protocol_i_line-p.html#a1875134be69f91a00bf033c6b353d86f", null ],
      [ "start", "protocol_i_line-p.html#aa9de222ab4acca458cf96bb5f36944b3", null ]
    ] ],
    [ "AText", "interface_a_text.html", [
      [ "description", "interface_a_text.html#aa870a7b079c7941f5174b90268b88c1a", null ],
      [ "initWithTextItem:", "interface_a_text.html#a846a929db6baec4c3f003022a6be48a9", null ],
      [ "alignment", "interface_a_text.html#a04858fca395486f8ee9eccf6ae1a16d8", null ],
      [ "fontName", "interface_a_text.html#a387eae47db082f63e2d1cb74cd61d4aa", null ],
      [ "fontSizeUnits", "interface_a_text.html#a521cca62b1c98f394962264080ef3425", null ],
      [ "fontStyle", "interface_a_text.html#a1b4894045a8fcddc950538e4f9aec85b", null ],
      [ "rotation", "interface_a_text.html#ac5905c712a6a0544c4a6d1bb0049c313", null ],
      [ "ruler", "interface_a_text.html#a44bb15fde864a20abbdbf71e90bf284d", null ],
      [ "text", "interface_a_text.html#a3da0d7564a8bf063c5dfebbd73db9104", null ]
    ] ],
    [ "ATextItem", "interface_a_text_item.html", [
      [ "initWithStart:data:", "interface_a_text_item.html#ad39607c8c19b9069be9d1951c51becce", null ],
      [ "data", "interface_a_text_item.html#adaa0784451f8186663030e43b4cc4e01", null ],
      [ "fontSize", "interface_a_text_item.html#af66ecc4206667ba31916e960315518b7", null ],
      [ "start", "interface_a_text_item.html#a24bd70fe59352e28cd9b44ebde30bca2", null ]
    ] ],
    [ "<IText>", "protocol_i_text-p.html", [
      [ "description", "protocol_i_text-p.html#a781d4357ba444d2757c1892849f3acd2", null ],
      [ "text", "protocol_i_text-p.html#a1013029c262376ef899452799b26aab1", null ]
    ] ],
    [ "<ITextItem>", "protocol_i_text_item-p.html", [
      [ "data", "protocol_i_text_item-p.html#aa734b5fc6c5b506aa692a1b04b4a1ba1", null ],
      [ "fontSize", "protocol_i_text_item-p.html#a15e034fcd7eaf46805daadd01965bbcf", null ],
      [ "start", "protocol_i_text_item-p.html#a4030f83763007c44c63d4268b1a7fa77", null ]
    ] ],
    [ "<ITextSettings>", "protocol_i_text_settings-p.html", [
      [ "ruler", "protocol_i_text_settings-p.html#a8aa6add4b75f5f4181ac857cef35a337", null ]
    ] ],
    [ "TextItem", "interface_text_item.html", [
      [ "initWithStart:data:", "interface_text_item.html#ac66501a41367a7d119be848d71f94d52", null ],
      [ "initWithStart:fontSize:data:", "interface_text_item.html#ae5db8fc3d0a2807ca9785d32cc946043", null ],
      [ "initWithX:y:data:", "interface_text_item.html#af64b0180aff922b2d8a4136bc186442d", null ],
      [ "initWithX:y:sizeX:sizeY:data:", "interface_text_item.html#a1fd6efac44e4484e41b56bfee14aa7ea", null ]
    ] ]
];