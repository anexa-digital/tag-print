var interface_settings_read_write =
[
    [ "getAllPropertiesWithTimeout:", "interface_settings_read_write.html#afcdd88474ef75464242512f3bd2f7b26", null ],
    [ "getAllValuesWithTimeout:", "interface_settings_read_write.html#ae49c5b44d84d0e873ab5db60cc5939e0", null ],
    [ "getPropertiesForKey:timeout:", "interface_settings_read_write.html#a3bbe28c5706cc4a2e6d6798c78f724f0", null ],
    [ "getPropertiesForKeys:timeout:", "interface_settings_read_write.html#afe05120526708851e75ecbc6c95ffe5c", null ],
    [ "getValueForKey:timeout:", "interface_settings_read_write.html#a65f3cc06959a0f8cf51d55e04474ffa1", null ],
    [ "getValuesForKeys:timeout:", "interface_settings_read_write.html#ac76deb8d53c7b14ed75549d97f5fccef", null ],
    [ "initWithBleComm:usingDataPort:", "interface_settings_read_write.html#a1fdc9bab3745510063c7d32d3affa378", null ],
    [ "initWithBtComm:usingDataPort:", "interface_settings_read_write.html#a1d805745b74e8e15fe4a019f22d78aa3", null ],
    [ "initWithCommDescriptor:", "interface_settings_read_write.html#a42713fce7a83e6fe7263bb3b38156a08", null ],
    [ "initWithJsonComm:", "interface_settings_read_write.html#ad9db67d4401dc25322f91b9b1bd3a538", null ],
    [ "initWithTcpComm:usingDataPort:", "interface_settings_read_write.html#adcadaaef31b04a935f93cc2eb1601b4a", null ],
    [ "initWithUsbComm:usingDataPort:", "interface_settings_read_write.html#a6422145407253d780b53d42ee1995c32", null ],
    [ "setValue:forKey:timeout:", "interface_settings_read_write.html#adafda9dccef1bad9aa05f5ee06f42158", null ],
    [ "setValues:timeout:", "interface_settings_read_write.html#aa9c0489bcef1699abe07f271c2ad3326", null ]
];