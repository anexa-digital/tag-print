var protocol_i_label_p =
[
    [ "addObject:", "protocol_i_label-p.html#a9f289a03580e964a82e28329be5b6a8b", null ],
    [ "addRawContent:", "protocol_i_label-p.html#ade55384be2299a36e3070cf0e4a75a21", null ],
    [ "description", "protocol_i_label-p.html#a7d192db7decea78079d7a56a4cba243b", null ],
    [ "name", "protocol_i_label-p.html#a00bff5aec498c0d6a819c177f4bc9e56", null ]
];