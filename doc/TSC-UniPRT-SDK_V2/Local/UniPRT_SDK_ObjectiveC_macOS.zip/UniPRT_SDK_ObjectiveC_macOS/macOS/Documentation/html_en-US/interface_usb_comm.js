var interface_usb_comm =
[
    [ "asyncListenRead", "interface_usb_comm.html#ade38551d691235ef75fbc7530bc6279f", null ],
    [ "close", "interface_usb_comm.html#abca5308d0a485cbe347060a7a9dedfb9", null ],
    [ "initWithVendorId:productId:", "interface_usb_comm.html#ad2f448e5d68aff3b809ed31d2b4f5ed4", null ],
    [ "open", "interface_usb_comm.html#a82d0003de982eb229e5bb92f7164c623", null ],
    [ "read", "interface_usb_comm.html#a5a4503d203c5001bb83c15b6b04d704f", null ],
    [ "stopListenRead", "interface_usb_comm.html#a0bb902f109d95d42f0944d7470be4c9b", null ],
    [ "write:", "interface_usb_comm.html#a386c794b216993cf59d6f2e0b9be1b06", null ],
    [ "writeAndWaitForResponse:responseStartTimeOut:responseEndTimeOut:completionToken:", "interface_usb_comm.html#a86f0faeabd0d6a533f126783375b3eaa", null ],
    [ "writeAndWaitForResponseJson:responseStartTimeOut:responseEndTimeOut:completionToken:", "interface_usb_comm.html#aaa72730e4fca36346951f68fea15f035", null ],
    [ "deviceList", "interface_usb_comm.html#ad912bea3ec8623c128be5dc246bf57ca", null ],
    [ "discoveredInterfaces", "interface_usb_comm.html#a8b3bb7de7560113c66ea443185a79f5e", null ],
    [ "matchedInterfaces", "interface_usb_comm.html#a4de650f1edd3cbaac184b66da4a615a2", null ]
];