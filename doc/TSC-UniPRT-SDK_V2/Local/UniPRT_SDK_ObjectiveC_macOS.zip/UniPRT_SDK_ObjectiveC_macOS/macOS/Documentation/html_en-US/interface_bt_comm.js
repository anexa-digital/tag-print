var interface_bt_comm =
[
    [ "close", "interface_bt_comm.html#af8246b4524ea274c3e971ce1f8ea0036", null ],
    [ "initWithDeviceAddress:", "interface_bt_comm.html#a8089f75d97aae33bcefde7477f530f2a", null ],
    [ "open", "interface_bt_comm.html#a5c1660d634cd8411924690cb5963739b", null ],
    [ "read", "interface_bt_comm.html#ae0bb219087cae580e506a534fc416a72", null ],
    [ "write:", "interface_bt_comm.html#abec7ff0a3c691bf1e417a9335fb71691", null ],
    [ "writeAndWaitForResponse:responseStartTimeOut:responseEndTimeOut:completionToken:", "interface_bt_comm.html#a4cc58d5e8a0cc9ad763630fca3e02442", null ],
    [ "writeAndWaitForResponseJson:responseStartTimeOut:responseEndTimeOut:completionToken:", "interface_bt_comm.html#a35825d9e8e15930c5443bdf11ac77c0b", null ],
    [ "receivedData", "interface_bt_comm.html#a6b78a5fc8ade9b78ba6806275d93ecb8", null ]
];