var interface_cell_rect =
[
    [ "init", "interface_cell_rect.html#abf04d34b00b2ca782419996bdbbd44e5", null ],
    [ "initWithXDim:yDim:ruler:", "interface_cell_rect.html#a9787cfec81e2373a5f27e6b6114856c5", null ],
    [ "ydim", "interface_cell_rect.html#a2870249fb77483c2ebbabab9523d227f", null ]
];