var interface_data_matrix_barcode =
[
    [ "description", "interface_data_matrix_barcode.html#a35c2563b5519b42b05a75ad6fdc81046", null ],
    [ "init", "interface_data_matrix_barcode.html#a1e4bdf7ea02007ef4d80de05ea294d0e", null ],
    [ "initWithStart:data:", "interface_data_matrix_barcode.html#aecad65c8602a956325f07cf5d8634775", null ]
];