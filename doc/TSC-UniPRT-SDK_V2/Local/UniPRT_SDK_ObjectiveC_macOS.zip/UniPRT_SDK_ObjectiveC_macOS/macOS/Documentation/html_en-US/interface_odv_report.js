var interface_odv_report =
[
    [ "data", "interface_odv_report.html#adcabf779a27bc91ea8908f7415730515", null ],
    [ "failed", "interface_odv_report.html#a9b869a5ee9408e50b557a86f010263a4", null ],
    [ "overallGrade", "interface_odv_report.html#a944810ad14b8a94480070879be5a0491", null ],
    [ "overallGradeAsFloat", "interface_odv_report.html#a385f799101afac01fb12b1e0b714a8f9", null ],
    [ "overallGradeLetter", "interface_odv_report.html#a1a2a4f7db66aa895cba9f737dafe3172", null ],
    [ "symbology", "interface_odv_report.html#a754f844f13e63ac11fb8c3140bf858c7", null ]
];