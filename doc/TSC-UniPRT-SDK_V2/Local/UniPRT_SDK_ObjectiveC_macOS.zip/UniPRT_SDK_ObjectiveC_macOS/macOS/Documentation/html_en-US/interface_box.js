var interface_box =
[
    [ "description", "interface_box.html#acddc01de3837b9027afb956c423d35ca", null ],
    [ "initWithStart:end:lineThickness:", "interface_box.html#adb3a157c99e4c15bfd044123e78192e3", null ],
    [ "initWithXStart:yStart:xEnd:yEnd:lineThickness:", "interface_box.html#a634e9791729ab1cc44d8fa2578995619", null ],
    [ "cornerRounding", "interface_box.html#a9b588c6a6968eda78fb08371c479b294", null ],
    [ "end", "interface_box.html#a3b274d9ccc42db06d36f9e11e524de6a", null ],
    [ "lineThickness", "interface_box.html#ab5f1784cfced6b0ddb250f28f626d47a", null ],
    [ "ruler", "interface_box.html#ad21840df1a132c84d943021a7d9fea45", null ],
    [ "start", "interface_box.html#a6f3ea082e5acdab8d7f34850eb115a9e", null ]
];