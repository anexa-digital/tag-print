var interface_a_comm =
[
    [ "close", "interface_a_comm.html#ab94b558abea9a7bb0d0c7f011dc58a6c", null ],
    [ "open", "interface_a_comm.html#aad0c60bbc798993568d7b7b5f0deb93d", null ],
    [ "read", "interface_a_comm.html#ade5f776a9c465558c97f63213239be76", null ],
    [ "readToBinaryWriter:", "interface_a_comm.html#adeb8cb0fe3236d9bc99655322596d5d7", null ],
    [ "waitForDataWithTimeout:", "interface_a_comm.html#a912fd42fbf511397185f5b2916855748", null ],
    [ "write:", "interface_a_comm.html#af827b500cf76bae685206511ac94b359", null ],
    [ "writeAndWaitForResponse:responseStartTimeOut:responseEndTimeOut:completionToken:", "interface_a_comm.html#a7a119d13b242b7eec8884502aeff1845", null ],
    [ "writeAndWaitForResponseToBinaryWriter:fromBinaryReader:responseStartTimeout:responseEndTimeout:completionToken:", "interface_a_comm.html#a854b4fd4cb49ac47c28575129c0d3f95", null ],
    [ "writeFromBinaryReader:", "interface_a_comm.html#a22b3d21cd0d43d40d02f2a4851bf1b57", null ],
    [ "bytesAvailable", "interface_a_comm.html#a3bf0d20501aa3afbb5b0726c6fd01745", null ],
    [ "descriptor", "interface_a_comm.html#abad7097117c0f0f0f14e1af82898e089", null ],
    [ "isConnected", "interface_a_comm.html#ae89f8b8c34eaa3a036d47bc4a99a36b8", null ],
    [ "maxPacketSize", "interface_a_comm.html#a9d9f2ba5bc5ea82a564dbe3e84e8be10", null ]
];