var interface_pgl_maxicode_msg_structured =
[
    [ "initWithMode:postalCode:countryCode:serviceClass:remainingMsg:", "interface_pgl_maxicode_msg_structured.html#a4f15334e7f63aaaf25b5a0dcaa6d2ae8", null ],
    [ "data", "interface_pgl_maxicode_msg_structured.html#a54532771344ad449ea986d50ef994f57", null ]
];