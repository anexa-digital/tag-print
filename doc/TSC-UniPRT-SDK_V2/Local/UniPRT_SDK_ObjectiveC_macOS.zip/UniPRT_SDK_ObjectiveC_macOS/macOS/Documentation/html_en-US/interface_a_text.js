var interface_a_text =
[
    [ "description", "interface_a_text.html#aa870a7b079c7941f5174b90268b88c1a", null ],
    [ "initWithTextItem:", "interface_a_text.html#a846a929db6baec4c3f003022a6be48a9", null ],
    [ "alignment", "interface_a_text.html#a04858fca395486f8ee9eccf6ae1a16d8", null ],
    [ "fontName", "interface_a_text.html#a387eae47db082f63e2d1cb74cd61d4aa", null ],
    [ "fontSizeUnits", "interface_a_text.html#a521cca62b1c98f394962264080ef3425", null ],
    [ "fontStyle", "interface_a_text.html#a1b4894045a8fcddc950538e4f9aec85b", null ],
    [ "rotation", "interface_a_text.html#ac5905c712a6a0544c4a6d1bb0049c313", null ],
    [ "ruler", "interface_a_text.html#a44bb15fde864a20abbdbf71e90bf284d", null ],
    [ "text", "interface_a_text.html#a3da0d7564a8bf063c5dfebbd73db9104", null ]
];