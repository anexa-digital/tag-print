var interface_byte_swapper =
[
    [ "swap16:", "interface_byte_swapper.html#a5b2cc3ec580339fdd85e18724f0e969c", null ],
    [ "swap32:", "interface_byte_swapper.html#a8d51d72e08523c4cc09424ef60b51c16", null ],
    [ "swap64:", "interface_byte_swapper.html#aa94dd6e5516803f7bc8edc0ada8b3876", null ]
];