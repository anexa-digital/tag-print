var interface_a_data_matrix =
[
    [ "ctrlChar:", "interface_a_data_matrix.html#a9898574a28a2e3632d9d373dd3021019", null ],
    [ "init", "interface_a_data_matrix.html#a86f8d3be5f3fd6a1bdb18fc71d2e627e", null ],
    [ "initWithStart:data:", "interface_a_data_matrix.html#a19cbec0f9ed89e131ab14dfcf7470007", null ],
    [ "cellSize", "interface_a_data_matrix.html#a2ab937a57340a439040b311c7e719842", null ],
    [ "ctrlCharDelimiter", "interface_a_data_matrix.html#ac3dd8d57855bad3c3ab80971cdfaf6ff", null ],
    [ "data", "interface_a_data_matrix.html#a8ee389c3b9d3c1f8bfa1aceaf8761751", null ],
    [ "fnc1", "interface_a_data_matrix.html#a4f65ba611f41b6f9bb5b5c7e8ca3fb29", null ],
    [ "rectangle", "interface_a_data_matrix.html#af13d7c83af8be1e071942365d162993b", null ],
    [ "rowsCols", "interface_a_data_matrix.html#a98ba16157a33bfa69c8a02a96a318de5", null ],
    [ "start", "interface_a_data_matrix.html#aceb90eecb2d6d5c84bb7d24290473bc7", null ]
];