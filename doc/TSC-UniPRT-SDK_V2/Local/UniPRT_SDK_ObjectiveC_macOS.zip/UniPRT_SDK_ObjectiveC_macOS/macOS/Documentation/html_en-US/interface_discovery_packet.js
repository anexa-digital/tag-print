var interface_discovery_packet =
[
    [ "createDiscoveryRequestPacket", "interface_discovery_packet.html#a4a49f3219596e1c36c71c0c9f510f3fb", null ],
    [ "createPTXRequest", "interface_discovery_packet.html#a7b000c0d1f7c101f965cb110aaea33cf", null ],
    [ "createTSCRequest", "interface_discovery_packet.html#afe4d5699f20af663e4528ac620f0e1ff", null ],
    [ "decodeIPAddressFromResponse:ip:", "interface_discovery_packet.html#ab083d3f6199d0a9e02c828cd4325b2fd", null ],
    [ "initWithBrand:", "interface_discovery_packet.html#a3b8e179d2da877c64e40de9266300402", null ],
    [ "brand", "interface_discovery_packet.html#aa7cd7a1f85e0425ab6059b13519f0645", null ],
    [ "broadcastAddress", "interface_discovery_packet.html#adfc5fb559f16d76535b007693f97e416", null ],
    [ "broadcastPort", "interface_discovery_packet.html#afafd9b339f93c9e669cfce0efd92d48a", null ],
    [ "discoveryRequestPacket", "interface_discovery_packet.html#a9c17d2e74ba50b0ef301fa27ef19e5bb", null ],
    [ "gatewayAddress", "interface_discovery_packet.html#a8030e280856d46959b01c6ecf0f65d20", null ],
    [ "responseAddress", "interface_discovery_packet.html#a21634a0571ae7e338c097c983ab65de0", null ],
    [ "responsePort", "interface_discovery_packet.html#a935f9d26f2497148a12df0a063847a05", null ]
];