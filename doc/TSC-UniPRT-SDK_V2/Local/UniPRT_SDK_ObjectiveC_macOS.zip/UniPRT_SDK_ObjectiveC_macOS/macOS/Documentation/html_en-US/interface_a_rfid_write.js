var interface_a_rfid_write =
[
    [ "description", "interface_a_rfid_write.html#a71d178482371ab8cb1b34687851790ca", null ],
    [ "initWithMemBlock:data:", "interface_a_rfid_write.html#ac795deec4bb51b02dbe1109bd6917096", null ],
    [ "NS_DESIGNATED_INITIALIZER", "interface_a_rfid_write.html#ab600f9229ade9738ce2035aff86cb5f1", null ],
    [ "data", "interface_a_rfid_write.html#a0880ef588d1d029a46b396aa7c31404f", null ],
    [ "memory", "interface_a_rfid_write.html#a1fa670e7cb5630e19f9cc5c96eb5f124", null ],
    [ "offsetFromStart", "interface_a_rfid_write.html#af742679f0b7c3e9f12dc485d6c35df0d", null ],
    [ "password", "interface_a_rfid_write.html#a5056445234f68cca9428f91ffae4b3f8", null ],
    [ "passwordType", "interface_a_rfid_write.html#ab7ce4ab1f18b43a16bf7262d26f4c724", null ]
];