var protocol_i_cell_square_p =
[
    [ "ruler", "protocol_i_cell_square-p.html#a94fe6cb92fe74fa572db47bf93bc8b14", null ],
    [ "xdim", "protocol_i_cell_square-p.html#a5891256ffc5cd4c535de9dfdcc1841ed", null ]
];