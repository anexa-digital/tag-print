var interface_pgl_data_matrix_barcode =
[
    [ "description", "interface_pgl_data_matrix_barcode.html#ad7657843e6b7a9d7f7f182196180d6bc", null ],
    [ "init", "interface_pgl_data_matrix_barcode.html#a8c42a01b9ac1ca7943593df73cdbf02b", null ],
    [ "initWithStart:data:", "interface_pgl_data_matrix_barcode.html#ae724a51d823bc64c7326b5bc78076ae2", null ]
];