var protocol_i_barcode__1_d___properties_p =
[
    [ "barWidths", "protocol_i_barcode__1_d___properties-p.html#a9e37b17da2354c8812d8f58096e03d0e", null ],
    [ "printHumanReadable", "protocol_i_barcode__1_d___properties-p.html#ab562e9f75af103e4f1e5f27260544abd", null ],
    [ "ruler", "protocol_i_barcode__1_d___properties-p.html#a30ee38de75906fe9266401030847e5e4", null ]
];