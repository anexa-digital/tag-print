var interface_pgl_line =
[
    [ "description", "interface_pgl_line.html#a013df8670e1414e8edae54fc562334db", null ],
    [ "initWithStart:end:lineThickness:", "interface_pgl_line.html#af6ca237f12d82e933b07ca7a24c7e664", null ],
    [ "initWithXStart:yStart:xEnd:yEnd:lineThickness:", "interface_pgl_line.html#ac0ed40e954810da86f8a65da5e49f9a9", null ]
];