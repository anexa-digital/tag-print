var interface_points =
[
    [ "initWithX:y:", "interface_points.html#aeb0b0071e74dad566f5e4ab39b61c052", null ]
];