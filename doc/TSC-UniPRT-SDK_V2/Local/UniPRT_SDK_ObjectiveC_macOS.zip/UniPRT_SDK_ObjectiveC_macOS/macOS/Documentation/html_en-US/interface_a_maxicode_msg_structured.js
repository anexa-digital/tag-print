var interface_a_maxicode_msg_structured =
[
    [ "data", "interface_a_maxicode_msg_structured.html#a88ee55f7cae762534ddebc6b29025fd8", null ],
    [ "init", "interface_a_maxicode_msg_structured.html#a6c30d40bfb6499befcf7e87516f740b6", null ],
    [ "initWithMode:postalCode:countryCode:serviceClass:remainingMsg:", "interface_a_maxicode_msg_structured.html#ae665587166e1497097d0c03e4854f215", null ],
    [ "countryCode", "interface_a_maxicode_msg_structured.html#a8a6ce5ccf03faf9b62f5dff9c57141c5", null ],
    [ "mode", "interface_a_maxicode_msg_structured.html#a3f987abc9c8a84ebc6ec46fdb18e0f70", null ],
    [ "postalCode", "interface_a_maxicode_msg_structured.html#ab8ada2889a441778f1fb973496a2b648", null ],
    [ "remainingMsg", "interface_a_maxicode_msg_structured.html#a9d159f230394d3a6ec170559ffdea10d", null ],
    [ "serviceClass", "interface_a_maxicode_msg_structured.html#a1ed558d1ebfc7eb9e44220e334651cbd", null ]
];