var protocol_i_barcode_item_p =
[
    [ "data", "protocol_i_barcode_item-p.html#ad4177389ffdcd0b0aba17f554b980832", null ],
    [ "height", "protocol_i_barcode_item-p.html#ac56bbe7ae0e99d4a9baa774081cc7ac7", null ],
    [ "start", "protocol_i_barcode_item-p.html#a0f1858a8d37ecf1c453d474417009bbf", null ]
];