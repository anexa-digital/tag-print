var interface_json_messenger =
[
    [ "dispose", "interface_json_messenger.html#addb1d3f5ef8ff4f85f37542fd101d54b", null ],
    [ "initWithCommToPtr:iCommTyp:maxInputMsgCapacity:usingDataPort:", "interface_json_messenger.html#a5826aeb1d5014c70fe2089725762baf9", null ],
    [ "readNextMsg", "interface_json_messenger.html#a2069b4decaa7591405e7c3142065cd0f", null ],
    [ "sendMsgAndWaitForResponseWithCommand:content:maxWaitTimeSecs:", "interface_json_messenger.html#ad644c93052216185168079c83a5356b3", null ],
    [ "sendMsgRawWithDataToSend:", "interface_json_messenger.html#a8213123925027dfc42128bf1d9bd8df8", null ],
    [ "sendMsgWithCommand:content:trackNo:", "interface_json_messenger.html#ab6b9f9f5babc4a791ea898345b8075c8", null ]
];