var interface_pgl_utilities =
[
    [ "PglWindowsFontWithImageName:fontSize:rotation:fontStyle:fontFamilyName:content:", "interface_pgl_utilities.html#a50113af29af3a6c90086f2c65762a215", null ]
];