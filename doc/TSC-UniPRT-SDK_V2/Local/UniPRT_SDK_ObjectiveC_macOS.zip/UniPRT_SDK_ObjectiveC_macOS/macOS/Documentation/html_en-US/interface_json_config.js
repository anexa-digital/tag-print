var interface_json_config =
[
    [ "getAllConfigWithTimeout:", "interface_json_config.html#a84aafeec174fd4895d69cc02d9234c1a", null ],
    [ "getConfigWithNumber:timeout:", "interface_json_config.html#a22aa8e12b9941029140d7a86749777a1", null ],
    [ "initWithBleComm:usingDataPort:", "interface_json_config.html#a1ba1b6bf9470e477b91b04ae7e78f9c3", null ],
    [ "initWithBtComm:usingDataPort:", "interface_json_config.html#a5172f93676fd473a22eed99fb5eb9257", null ],
    [ "initWithCommDescriptor:", "interface_json_config.html#a51045451798549528dd31b46afa4433d", null ],
    [ "initWithJsonComm:", "interface_json_config.html#a6bf944700538f307b313b13c295267d1", null ],
    [ "initWithTcpComm:usingDataPort:", "interface_json_config.html#a09ec0e9f66514892352cc294ab991302", null ],
    [ "initWithUsbComm:usingDataPort:", "interface_json_config.html#adb329b8c95770a60e6b299e7c014e3a2", null ],
    [ "setConfig:pCfg:", "interface_json_config.html#a1c18e0a8d099de0af634754cf1472c35", null ]
];