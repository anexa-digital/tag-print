var group___settings =
[
    [ "Config", "interface_config.html", [
      [ "description", "interface_config.html#a75ca3995b5590125d21b8e9beaea85e1", null ],
      [ "getData", "interface_config.html#a892802c78f2bf896ba353c07771182f9", null ],
      [ "getModel", "interface_config.html#a300f5543eebab881565ebbb80840c1e1", null ],
      [ "getName", "interface_config.html#ae17ac5633ca70af3fdaf8624d4ecd817", null ],
      [ "getNumber", "interface_config.html#a6a73de2a52deb1c5314d3a974f2c7189", null ],
      [ "getProgramFile", "interface_config.html#af7bb93bdeadfb27a8044dd67ccd96db9", null ],
      [ "init", "interface_config.html#aadb6e9ac83603b18eb9c9fced73ef0ef", null ],
      [ "initWithCfgContent:", "interface_config.html#a2764accd7ef264ef3c524bb3055cadea", null ],
      [ "setData:", "interface_config.html#a7f3558a7b5522b0e985348edbc5e2b78", null ],
      [ "setModel:", "interface_config.html#ad12be2e65f47de864ffe261cd22b30a8", null ],
      [ "setName:", "interface_config.html#ae2248439c607a17c1c1e18b9f3168257", null ],
      [ "setNumber:", "interface_config.html#a47c62dadd449c2284fa815d41a274463", null ],
      [ "setProgramFile:", "interface_config.html#a0880fb122d303415156c661609296b10", null ]
    ] ],
    [ "JsonConfig", "interface_json_config.html", [
      [ "getAllConfigWithTimeout:", "interface_json_config.html#a84aafeec174fd4895d69cc02d9234c1a", null ],
      [ "getConfigWithNumber:timeout:", "interface_json_config.html#a22aa8e12b9941029140d7a86749777a1", null ],
      [ "initWithBleComm:usingDataPort:", "interface_json_config.html#a1ba1b6bf9470e477b91b04ae7e78f9c3", null ],
      [ "initWithBtComm:usingDataPort:", "interface_json_config.html#a5172f93676fd473a22eed99fb5eb9257", null ],
      [ "initWithCommDescriptor:", "interface_json_config.html#a51045451798549528dd31b46afa4433d", null ],
      [ "initWithJsonComm:", "interface_json_config.html#a6bf944700538f307b313b13c295267d1", null ],
      [ "initWithTcpComm:usingDataPort:", "interface_json_config.html#a09ec0e9f66514892352cc294ab991302", null ],
      [ "initWithUsbComm:usingDataPort:", "interface_json_config.html#adb329b8c95770a60e6b299e7c014e3a2", null ],
      [ "setConfig:pCfg:", "interface_json_config.html#a1c18e0a8d099de0af634754cf1472c35", null ]
    ] ],
    [ "Setting", "interface_setting.html", [
      [ "description", "interface_setting.html#a32540d2db72cfbf8b4a7ec455ead5eeb", null ],
      [ "increment", "interface_setting.html#a9e8e60dd62c32a853f97c2f6404fc55c", null ],
      [ "maximum", "interface_setting.html#a2ff9bb219fa51232a36c75448ba7b49d", null ],
      [ "minimum", "interface_setting.html#a1ca8fcb9527b1067f12b9a0d724bb7b1", null ],
      [ "options", "interface_setting.html#a92af968672aa17f2143f510b32cb8ac8", null ],
      [ "permission", "interface_setting.html#a45f5d6f2260be4f26735a558a11fb110", null ],
      [ "type", "interface_setting.html#a074df4ca47e559eaca97182c2efe7b51", null ],
      [ "value", "interface_setting.html#a18d6c65e7d1b05613eecfe8828999de3", null ]
    ] ],
    [ "SettingsReadWrite", "interface_settings_read_write.html", [
      [ "getAllPropertiesWithTimeout:", "interface_settings_read_write.html#afcdd88474ef75464242512f3bd2f7b26", null ],
      [ "getAllValuesWithTimeout:", "interface_settings_read_write.html#ae49c5b44d84d0e873ab5db60cc5939e0", null ],
      [ "getPropertiesForKey:timeout:", "interface_settings_read_write.html#a3bbe28c5706cc4a2e6d6798c78f724f0", null ],
      [ "getPropertiesForKeys:timeout:", "interface_settings_read_write.html#afe05120526708851e75ecbc6c95ffe5c", null ],
      [ "getValueForKey:timeout:", "interface_settings_read_write.html#a65f3cc06959a0f8cf51d55e04474ffa1", null ],
      [ "getValuesForKeys:timeout:", "interface_settings_read_write.html#ac76deb8d53c7b14ed75549d97f5fccef", null ],
      [ "initWithBleComm:usingDataPort:", "interface_settings_read_write.html#a1fdc9bab3745510063c7d32d3affa378", null ],
      [ "initWithBtComm:usingDataPort:", "interface_settings_read_write.html#a1d805745b74e8e15fe4a019f22d78aa3", null ],
      [ "initWithCommDescriptor:", "interface_settings_read_write.html#a42713fce7a83e6fe7263bb3b38156a08", null ],
      [ "initWithJsonComm:", "interface_settings_read_write.html#ad9db67d4401dc25322f91b9b1bd3a538", null ],
      [ "initWithTcpComm:usingDataPort:", "interface_settings_read_write.html#adcadaaef31b04a935f93cc2eb1601b4a", null ],
      [ "initWithUsbComm:usingDataPort:", "interface_settings_read_write.html#a6422145407253d780b53d42ee1995c32", null ],
      [ "setValue:forKey:timeout:", "interface_settings_read_write.html#adafda9dccef1bad9aa05f5ee06f42158", null ],
      [ "setValues:timeout:", "interface_settings_read_write.html#aa9c0489bcef1699abe07f271c2ad3326", null ]
    ] ]
];