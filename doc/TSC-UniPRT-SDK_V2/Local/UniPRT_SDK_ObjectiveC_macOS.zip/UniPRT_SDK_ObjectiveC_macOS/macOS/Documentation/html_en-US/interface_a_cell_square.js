var interface_a_cell_square =
[
    [ "initWithXDim:ruler:", "interface_a_cell_square.html#ac87f919a9e3a9cbd7e828a131b05980b", null ],
    [ "NS_DESIGNATED_INITIALIZER", "interface_a_cell_square.html#aaaea5cb68534dbe315aeb3534a49fb0d", null ],
    [ "ruler", "interface_a_cell_square.html#a18f491381172dfd0d32e4ed0af89ea49", null ],
    [ "xdim", "interface_a_cell_square.html#a9b677d528e5d8f9ed4db6861913901de", null ]
];