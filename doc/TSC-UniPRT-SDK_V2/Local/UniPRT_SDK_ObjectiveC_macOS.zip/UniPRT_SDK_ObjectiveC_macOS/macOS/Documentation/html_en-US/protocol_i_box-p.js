var protocol_i_box_p =
[
    [ "cornerRounding", "protocol_i_box-p.html#ab0fa8ff9f837d8b42c8dc8fcb0e3fb9c", null ],
    [ "end", "protocol_i_box-p.html#a289584f129f3346554cea0aa9ca914ee", null ],
    [ "lineThickness", "protocol_i_box-p.html#a54833f0e24772dd6811e046f89bea6b8", null ],
    [ "ruler", "protocol_i_box-p.html#a03392db0acc18481eafb170ecb7384e2", null ],
    [ "start", "protocol_i_box-p.html#a5534780059beb217bc60004c5554b264", null ]
];