var interface_a_q_r_barcode =
[
    [ "initWithStart:data:", "interface_a_q_r_barcode.html#abc9daf28b36e33045ef5e19d172e4f74", null ],
    [ "initWithStart:manuallyEncodedData:", "interface_a_q_r_barcode.html#abf9b4b3db87a85785fd00584dd3deb3e", null ],
    [ "cellSize", "interface_a_q_r_barcode.html#afd9c6b277990566ebcaa0ab08849cfc6", null ],
    [ "data", "interface_a_q_r_barcode.html#a25b6dddbb67791c10db7a8dfd1bf57b3", null ],
    [ "dataManuallyEncoded", "interface_a_q_r_barcode.html#a1cd13a96f5090990084aefc91b7f8c41", null ],
    [ "errorCorrection", "interface_a_q_r_barcode.html#aa2ceae973c2d58cc614c3290641e86ae", null ],
    [ "mask", "interface_a_q_r_barcode.html#af89458b7f84c1143745ee6dc8aec4b70", null ],
    [ "model", "interface_a_q_r_barcode.html#ad7dcaa06d27e9a5d553d760ed018667d", null ],
    [ "start", "interface_a_q_r_barcode.html#a9e7d9a6cc857db33d1f1f8f111503fd0", null ]
];