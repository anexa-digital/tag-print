var hierarchy =
[
    [ "_Box", "class___box.html", null ],
    [ "AlignEnum", "class_align_enum.html", null ],
    [ "AMaxicodebarcode", "class_a_maxicodebarcode.html", null ],
    [ "AztecCodeTypeEnum", "class_aztec_code_type_enum.html", null ],
    [ "BarcodeTypeEnum_1D", "class_barcode_type_enum__1_d.html", null ],
    [ "<CBCentralManagerDelegate>", null, [
      [ "BleComm", "interface_ble_comm.html", null ]
    ] ],
    [ "<CBPeripheralDelegate>", null, [
      [ "BleComm", "interface_ble_comm.html", null ]
    ] ],
    [ "DISCOVER", "struct_d_i_s_c_o_v_e_r.html", null ],
    [ "DISCOVERY_PTX", "struct_d_i_s_c_o_v_e_r_y___p_t_x.html", null ],
    [ "FontStyleEnum", "class_font_style_enum.html", null ],
    [ "<IFontStyle>", null, [
      [ "<IFontSettings>", "protocol_i_font_settings-p.html", null ],
      [ "<ITextSettings>", "protocol_i_text_settings-p.html", [
        [ "<IText>", "protocol_i_text-p.html", [
          [ "AText", "interface_a_text.html", [
            [ "PglText", "interface_pgl_text.html", null ],
            [ "Text", "interface_text.html", null ]
          ] ]
        ] ]
      ] ]
    ] ],
    [ "MaxicodeModeEnum", "class_maxicode_mode_enum.html", null ],
    [ "NSObject", null, [
      [ "ABarWidths", "interface_a_bar_widths.html", [
        [ "BarWidths", "interface_bar_widths.html", null ],
        [ "PglBarWidths", "interface_pgl_bar_widths.html", null ]
      ] ],
      [ "ABarcode1D", "interface_a_barcode1_d.html", [
        [ "Barcode_1D", "interface_barcode__1_d.html", null ],
        [ "PglBarcode_1D", "interface_pgl_barcode__1_d.html", null ]
      ] ],
      [ "ABarcode2D", "interface_a_barcode2_d.html", [
        [ "AAztecBarcode", "interface_a_aztec_barcode.html", [
          [ "AztecBarcode", "interface_aztec_barcode.html", null ],
          [ "PglAztecBarcode", "interface_pgl_aztec_barcode.html", null ]
        ] ],
        [ "ADataMatrix", "interface_a_data_matrix.html", [
          [ "DataMatrixBarcode", "interface_data_matrix_barcode.html", null ],
          [ "PglDataMatrixBarcode", "interface_pgl_data_matrix_barcode.html", null ]
        ] ],
        [ "APdf417", "interface_a_pdf417.html", [
          [ "Pdf417Barcode", "interface_pdf417_barcode.html", null ],
          [ "PglPdf417Barcode", "interface_pgl_pdf417_barcode.html", null ]
        ] ],
        [ "AQRBarcode", "interface_a_q_r_barcode.html", [
          [ "PglQRBarcode", "interface_pgl_q_r_barcode.html", null ],
          [ "QRBarcode", "interface_q_r_barcode.html", null ]
        ] ]
      ] ],
      [ "ABarcodeItem", "interface_a_barcode_item.html", [
        [ "BarcodeItem", "interface_barcode_item.html", null ]
      ] ],
      [ "ACellSquare", "interface_a_cell_square.html", [
        [ "CellRect", "interface_cell_rect.html", null ],
        [ "CellSquare", "interface_cell_square.html", null ]
      ] ],
      [ "AComm", "interface_a_comm.html", [
        [ "BleComm", "interface_ble_comm.html", null ],
        [ "BtComm", "interface_bt_comm.html", null ],
        [ "TcpComm", "interface_tcp_comm.html", null ],
        [ "UsbComm", "interface_usb_comm.html", null ]
      ] ],
      [ "ALine", "interface_a_line.html", [
        [ "Line", "interface_line.html", null ],
        [ "PglLine", "interface_pgl_line.html", null ]
      ] ],
      [ "AMaxicodeBarcode", "interface_a_maxicode_barcode.html", [
        [ "MaxicodeBarcode", "interface_maxicode_barcode.html", null ],
        [ "PglMaxicodeBarcode", "interface_pgl_maxicode_barcode.html", null ]
      ] ],
      [ "AMaxicodeMsg", "interface_a_maxicode_msg.html", [
        [ "MaxicodeMsg", "interface_maxicode_msg.html", null ],
        [ "PglMaxicodeMsg", "interface_pgl_maxicode_msg.html", null ]
      ] ],
      [ "AMaxicodeMsgStructured", "interface_a_maxicode_msg_structured.html", [
        [ "MaxicodeMsgStructured", "interface_maxicode_msg_structured.html", null ],
        [ "PglMaxicodeMsgStructured", "interface_pgl_maxicode_msg_structured.html", null ]
      ] ],
      [ "AMaxicodeMsgStructuredOpenSystemStandard", "interface_a_maxicode_msg_structured_open_system_standard.html", [
        [ "MaxicodeMsgStructuredOpenSystemStandard", "interface_maxicode_msg_structured_open_system_standard.html", null ],
        [ "PglMaxicodeMsgStructuredOpenSystemStandard", "interface_pgl_maxicode_msg_structured_open_system_standard.html", null ]
      ] ],
      [ "APair", "interface_a_pair.html", [
        [ "FontSize", "interface_font_size.html", null ],
        [ "Points", "interface_points.html", null ]
      ] ],
      [ "APicture", "interface_a_picture.html", null ],
      [ "ARfidWrite", "interface_a_rfid_write.html", [
        [ "PglRfid_Write", "interface_pgl_rfid___write.html", null ],
        [ "Rfid_Write", "interface_rfid___write.html", null ]
      ] ],
      [ "AText", "interface_a_text.html", null ],
      [ "ATextItem", "interface_a_text_item.html", [
        [ "TextItem", "interface_text_item.html", null ]
      ] ],
      [ "Box", "interface_box.html", null ],
      [ "ByteSwapper", "interface_byte_swapper.html", null ],
      [ "Config", "interface_config.html", null ],
      [ "Defaults", "interface_defaults.html", null ],
      [ "DiscoveryNetwork", "interface_discovery_network.html", null ],
      [ "DiscoveryPacket", "interface_discovery_packet.html", null ],
      [ "JsonConfig", "interface_json_config.html", null ],
      [ "JsonMessenger", "interface_json_messenger.html", null ],
      [ "JsonMng", "interface_json_mng.html", null ],
      [ "Label", "interface_label.html", null ],
      [ "NetworkDiscover", "interface_network_discover.html", null ],
      [ "OdvMonitor", "interface_odv_monitor.html", null ],
      [ "OdvReport", "interface_odv_report.html", null ],
      [ "PglBox", "interface_pgl_box.html", null ],
      [ "PglLabel", "interface_pgl_label.html", null ],
      [ "PglPicture", "interface_pgl_picture.html", null ],
      [ "PglUtilities", "interface_pgl_utilities.html", null ],
      [ "PrintResolution", "interface_print_resolution.html", null ],
      [ "PrinterInfo", "interface_printer_info.html", null ],
      [ "PrinterMonitor", "interface_printer_monitor.html", null ],
      [ "RfidConvert", "interface_rfid_convert.html", null ],
      [ "RfidMonitor", "interface_rfid_monitor.html", null ],
      [ "RfidReport", "interface_rfid_report.html", null ],
      [ "Ruler", "interface_ruler.html", null ],
      [ "Setting", "interface_setting.html", null ],
      [ "SettingsReadWrite", "interface_settings_read_write.html", null ],
      [ "TsplPicture", "interface_tspl_picture.html", null ],
      [ "Utilities", "interface_utilities.html", null ],
      [ "_Picture", "interface___picture.html", null ]
    ] ],
    [ "<NSObject>", null, [
      [ "<IAlignment>", "protocol_i_alignment-p.html", [
        [ "<ITextSettings>", "protocol_i_text_settings-p.html", null ]
      ] ],
      [ "<IBarWidths>", "protocol_i_bar_widths-p.html", [
        [ "ABarWidths", "interface_a_bar_widths.html", null ]
      ] ],
      [ "<IBarcodeItem>", "protocol_i_barcode_item-p.html", [
        [ "ABarcodeItem", "interface_a_barcode_item.html", null ]
      ] ],
      [ "<IBarcodeItem_2D>", "protocol_i_barcode_item__2_d-p.html", [
        [ "<IBarcode2D>", "protocol_i_barcode2_d-p.html", [
          [ "ABarcode2D", "interface_a_barcode2_d.html", null ]
        ] ]
      ] ],
      [ "<IBarcodeType1D>", "protocol_i_barcode_type1_d-p.html", [
        [ "<IBarcode_1D_Properties>", "protocol_i_barcode__1_d___properties-p.html", [
          [ "<IBarcode1D>", "protocol_i_barcode1_d-p.html", [
            [ "ABarcode1D", "interface_a_barcode1_d.html", null ]
          ] ]
        ] ]
      ] ],
      [ "<IBox>", "protocol_i_box-p.html", [
        [ "Box", "interface_box.html", null ],
        [ "PglBox", "interface_pgl_box.html", null ]
      ] ],
      [ "<ICellSquare>", "protocol_i_cell_square-p.html", [
        [ "ACellSquare", "interface_a_cell_square.html", null ],
        [ "<ICellRect>", "protocol_i_cell_rect-p.html", [
          [ "CellRect", "interface_cell_rect.html", null ]
        ] ]
      ] ],
      [ "<IComm>", "protocol_i_comm-p.html", [
        [ "AComm", "interface_a_comm.html", null ]
      ] ],
      [ "<IFont>", "protocol_i_font-p.html", [
        [ "<IFontSettings>", "protocol_i_font_settings-p.html", null ],
        [ "<ITextSettings>", "protocol_i_text_settings-p.html", null ]
      ] ],
      [ "<IFontSizeUnits>", "protocol_i_font_size_units-p.html", [
        [ "<IFontSettings>", "protocol_i_font_settings-p.html", null ],
        [ "<ITextSettings>", "protocol_i_text_settings-p.html", null ]
      ] ],
      [ "<ILabel>", "protocol_i_label-p.html", [
        [ "Label", "interface_label.html", null ]
      ] ],
      [ "<ILine>", "protocol_i_line-p.html", [
        [ "ALine", "interface_a_line.html", null ]
      ] ],
      [ "<IMaxicodeBarcode>", "protocol_i_maxicode_barcode-p.html", [
        [ "AMaxicodeBarcode", "interface_a_maxicode_barcode.html", null ]
      ] ],
      [ "<IMaxicodeData>", "protocol_i_maxicode_data-p.html", [
        [ "<IMaxicodeMsg>", "protocol_i_maxicode_msg-p.html", [
          [ "AMaxicodeMsg", "interface_a_maxicode_msg.html", null ]
        ] ],
        [ "<IMaxicodeMsgStructured>", "protocol_i_maxicode_msg_structured-p.html", [
          [ "AMaxicodeMsgStructured", "interface_a_maxicode_msg_structured.html", null ]
        ] ],
        [ "<IMaxicodeMsgStructuredOpenSystemStandard>", "protocol_i_maxicode_msg_structured_open_system_standard-p.html", [
          [ "AMaxicodeMsgStructuredOpenSystemStandard", "interface_a_maxicode_msg_structured_open_system_standard.html", null ]
        ] ]
      ] ],
      [ "<IPair>", "protocol_i_pair-p.html", [
        [ "APair", "interface_a_pair.html", null ],
        [ "<IFontSize>", "protocol_i_font_size-p.html", [
          [ "FontSize", "interface_font_size.html", null ]
        ] ],
        [ "<IPoint>", "protocol_i_point-p.html", [
          [ "Points", "interface_points.html", null ]
        ] ]
      ] ],
      [ "<IPicture>", "protocol_i_picture-p.html", [
        [ "APicture", "interface_a_picture.html", null ],
        [ "PglPicture", "interface_pgl_picture.html", null ],
        [ "TsplPicture", "interface_tspl_picture.html", null ]
      ] ],
      [ "<IPositionRuler>", "protocol_i_position_ruler-p.html", [
        [ "<IBarcode2D>", "protocol_i_barcode2_d-p.html", null ],
        [ "<IMaxicodeBarcode>", "protocol_i_maxicode_barcode-p.html", null ]
      ] ],
      [ "<IPrintResolution>", "protocol_i_print_resolution-p.html", [
        [ "PrintResolution", "interface_print_resolution.html", null ]
      ] ],
      [ "<IRectangleCell>", "protocol_i_rectangle_cell-p.html", [
        [ "APdf417", "interface_a_pdf417.html", null ]
      ] ],
      [ "<IRfidBankSelect>", "protocol_i_rfid_bank_select-p.html", [
        [ "ARfidWrite", "interface_a_rfid_write.html", null ]
      ] ],
      [ "<IRfidBitField>", "protocol_i_rfid_bit_field-p.html", [
        [ "ARfidWrite", "interface_a_rfid_write.html", null ]
      ] ],
      [ "<IRfidPassword>", "protocol_i_rfid_password-p.html", [
        [ "ARfidWrite", "interface_a_rfid_write.html", null ]
      ] ],
      [ "<IRfidWrite>", "protocol_i_rfid_write-p.html", null ],
      [ "<IRotation>", "protocol_i_rotation-p.html", [
        [ "<IBarcode2D>", "protocol_i_barcode2_d-p.html", null ],
        [ "<IBarcode_1D_Properties>", "protocol_i_barcode__1_d___properties-p.html", null ],
        [ "<ITextSettings>", "protocol_i_text_settings-p.html", null ],
        [ "MaxicodeBarcode", "interface_maxicode_barcode.html", null ],
        [ "PglMaxicodeBarcode", "interface_pgl_maxicode_barcode.html", null ]
      ] ],
      [ "<IRuler>", "protocol_i_ruler-p.html", [
        [ "Ruler", "interface_ruler.html", null ]
      ] ],
      [ "<ISquareCell>", "protocol_i_square_cell-p.html", [
        [ "AAztecBarcode", "interface_a_aztec_barcode.html", null ],
        [ "ADataMatrix", "interface_a_data_matrix.html", null ],
        [ "AQRBarcode", "interface_a_q_r_barcode.html", null ]
      ] ],
      [ "<IStartPoint>", "protocol_i_start_point-p.html", [
        [ "<IMaxicodeBarcode>", "protocol_i_maxicode_barcode-p.html", null ]
      ] ],
      [ "<ITextItem>", "protocol_i_text_item-p.html", [
        [ "ATextItem", "interface_a_text_item.html", null ]
      ] ]
    ] ],
    [ "<NSStreamDelegate>", null, [
      [ "TcpComm", "interface_tcp_comm.html", null ]
    ] ],
    [ "QRCodeErrorCorrectionEnum", "class_q_r_code_error_correction_enum.html", null ],
    [ "QRCodeManualEncodingEnum", "class_q_r_code_manual_encoding_enum.html", null ],
    [ "QRCodeMaskEnum", "class_q_r_code_mask_enum.html", null ],
    [ "QRCodeModelEnum", "class_q_r_code_model_enum.html", null ],
    [ "RfidMemBlockEnum", "class_rfid_mem_block_enum.html", null ],
    [ "RfidPasswordTypeEnum", "class_rfid_password_type_enum.html", null ],
    [ "RotateEnum", "class_rotate_enum.html", null ],
    [ "ScaleEnum", "class_scale_enum.html", null ],
    [ "<SimplePingDelegate>", null, [
      [ "PrinterUtil", "class_printer_util.html", null ]
    ] ],
    [ "UTILHEADER", "struct_u_t_i_l_h_e_a_d_e_r.html", null ]
];