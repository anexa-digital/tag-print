var interface_network_discover =
[
    [ "getPrinterList", "interface_network_discover.html#a11355421b2f76f5891e862009140f91e", null ],
    [ "getPrinterListWithBrand:", "interface_network_discover.html#a0f00aa25987c500e266bdd6cb5f926b1", null ],
    [ "getPrinterListWithBrand:timeout:", "interface_network_discover.html#a2eec131e985ca6ca4373c459a06e4232", null ]
];