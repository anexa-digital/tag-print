var interface_printer_info =
[
    [ "firmwarePartNumber", "interface_printer_info.html#acdc9df37181cbb726f4ce8ad6005a2a7", null ],
    [ "firmwareVersion", "interface_printer_info.html#a11e68b3d929b6e76b70ecf4eb5532f77", null ],
    [ "hasClockOption", "interface_printer_info.html#a24547b83c4252effafdbbc635daa5769", null ],
    [ "hasOdvOption", "interface_printer_info.html#a981b46f047f7511be8b86c9ee7207d9b", null ],
    [ "hasRfidOption", "interface_printer_info.html#a400772f19be0686909c6efdaa3fff26f", null ],
    [ "model", "interface_printer_info.html#a566b128a2b49bb3a3f11397fb778b278", null ],
    [ "printheadResolution", "interface_printer_info.html#a4f98ec7151803042ef061cb27fcb9b84", null ],
    [ "serialNumber", "interface_printer_info.html#ad1cf57e45a03b4839f78321500946b73", null ],
    [ "setRawInfoWithDictionary:", "interface_printer_info.html#a27311568b452f95d3a9e25fd0828be23", null ],
    [ "rawInfo", "interface_printer_info.html#a8348cdaec7dc11823d5106ea26c36a1f", null ]
];