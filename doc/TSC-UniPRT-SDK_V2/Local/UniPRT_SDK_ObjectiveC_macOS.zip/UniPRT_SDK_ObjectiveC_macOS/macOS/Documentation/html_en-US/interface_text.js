var interface_text =
[
    [ "description", "interface_text.html#ae235bc45d9f38e853666ee6f32859297", null ],
    [ "init", "interface_text.html#ac3ede3f36b3b6f75450f38feb2f00f08", null ],
    [ "initWithTextItem:", "interface_text.html#a85d746068fc4aca214caa2769502f428", null ],
    [ "referencePoint", "interface_text.html#aabbb28102c444a4cfb6c56dfc30aefd8", null ],
    [ "reverse", "interface_text.html#a372f8395f19b5e96d807b5b4f8ac629f", null ]
];