var interface_a_text_item =
[
    [ "initWithStart:data:", "interface_a_text_item.html#ad39607c8c19b9069be9d1951c51becce", null ],
    [ "data", "interface_a_text_item.html#adaa0784451f8186663030e43b4cc4e01", null ],
    [ "fontSize", "interface_a_text_item.html#af66ecc4206667ba31916e960315518b7", null ],
    [ "start", "interface_a_text_item.html#a24bd70fe59352e28cd9b44ebde30bca2", null ]
];