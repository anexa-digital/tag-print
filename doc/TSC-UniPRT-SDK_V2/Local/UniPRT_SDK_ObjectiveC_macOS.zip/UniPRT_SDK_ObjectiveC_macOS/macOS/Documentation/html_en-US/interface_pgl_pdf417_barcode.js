var interface_pgl_pdf417_barcode =
[
    [ "description", "interface_pgl_pdf417_barcode.html#a8aaa82cee77cf1fdfdc75b35d31002d6", null ],
    [ "initWithStart:data:", "interface_pgl_pdf417_barcode.html#a35bf002ed5a1b5e6060ab0e9ee8b39a5", null ],
    [ "data", "interface_pgl_pdf417_barcode.html#a3e4e5bb6291d595c16deec88ad6a75d5", null ],
    [ "start", "interface_pgl_pdf417_barcode.html#aece0e51946b46f2e254eb526a73ff9b4", null ]
];