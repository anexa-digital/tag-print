var interface_pgl_maxicode_msg_structured_open_system_standard =
[
    [ "data", "interface_pgl_maxicode_msg_structured_open_system_standard.html#ac101a2e9ed7b4f047029b20268843d4c", null ]
];