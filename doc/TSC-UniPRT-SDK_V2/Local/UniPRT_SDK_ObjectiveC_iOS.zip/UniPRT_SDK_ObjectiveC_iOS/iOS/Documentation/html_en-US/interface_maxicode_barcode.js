var interface_maxicode_barcode =
[
    [ "description", "interface_maxicode_barcode.html#a1dc545f2b4bb05aed7aeace11567691e", null ],
    [ "initWithStart:data:", "interface_maxicode_barcode.html#a3efed6921822bcc4915b956dc24c8b33", null ],
    [ "data", "interface_maxicode_barcode.html#ad76c10716c3b886abe879a11f16da611", null ],
    [ "rotation", "interface_maxicode_barcode.html#a35f5e3f29c99d5a09d8a5b8397257964", null ],
    [ "start", "interface_maxicode_barcode.html#a9d57963d8aab9564c5a95ca0273ded40", null ],
    [ "zipperPattern", "interface_maxicode_barcode.html#a28f3f502e7526229345797764be58cd0", null ]
];