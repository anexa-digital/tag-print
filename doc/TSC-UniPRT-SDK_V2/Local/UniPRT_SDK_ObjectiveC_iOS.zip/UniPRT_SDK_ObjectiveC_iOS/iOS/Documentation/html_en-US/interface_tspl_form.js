var interface_tspl_form =
[
    [ "addTsplObject:", "interface_tspl_form.html#af5c6c12a108d73785ec7d2bfe8dec5bf", null ],
    [ "barcode1DWithSetup:startRow:startCol:bcdData:", "interface_tspl_form.html#a100baecc50544d41f9bcc8656c8a3bf2", null ],
    [ "barcode1DWithType:startRow:startCol:bcdData:", "interface_tspl_form.html#ae35f593d73630730fbcbd5fa62388a1e", null ],
    [ "barcode2DWithSetup:startRow:startCol:bcdData:", "interface_tspl_form.html#ad2b8bbf819a20b2cacce1e62703bf6ce", null ],
    [ "barcode2DWithType:startRow:startCol:bcdData:", "interface_tspl_form.html#ab404ff70f026c92408fa8b306c9aa315", null ],
    [ "boxWithLineThickness:startRow:startCol:endRow:endCol:", "interface_tspl_form.html#a3fbc69753a3f898eccdac4365117592a", null ],
    [ "description", "interface_tspl_form.html#adf33edcc7fa9756df1a09e41e3ecafe4", null ],
    [ "getAsString", "interface_tspl_form.html#a44b0b59da6be2c416dd66e55e0149200", null ],
    [ "initWithName:", "interface_tspl_form.html#a36c89803ba51c191ac6c2b7e5d9b3474", null ],
    [ "lineWithLineThickness:startRow:startCol:endRow:endCol:", "interface_tspl_form.html#a5f66247ebc41a373e1b2e6edae01943f", null ],
    [ "rawContent:", "interface_tspl_form.html#a16b753d4eab426936599fd412ebc7e88", null ],
    [ "rfidVerifyWithProps:readBitField:", "interface_tspl_form.html#ab51c132c7ac5293dd560abc648fe66d8", null ],
    [ "rfidWriteWithMemBank:dataFormat:bitCount:data:", "interface_tspl_form.html#a6a150498d5f1b81b7815cf9ee1d7896e", null ],
    [ "rfidWriteWithProps:bitField:", "interface_tspl_form.html#a8d1b88935c0e3c32b1c49e10b5dec57e", null ],
    [ "scaleWithUnits:horzRes:vertRes:", "interface_tspl_form.html#af162ec2b5a255e898324113b105b8c8e", null ],
    [ "textWithStartRow:startCol:vertExpand:horzExpand:data:", "interface_tspl_form.html#a99d411d396d32bacc634fa6939efd081", null ],
    [ "name", "interface_tspl_form.html#a315b02c318d29b3342efd1ff461f9dfa", null ],
    [ "tsplObjects", "interface_tspl_form.html#aaf77121d6e8e20a5b4693d16dbbc2c62", null ]
];