var interface_pgl_maxicode_msg_structured =
[
    [ "initWithMode:postalCode:countryCode:serviceClass:remainingMsg:", "interface_pgl_maxicode_msg_structured.html#a4f15334e7f63aaaf25b5a0dcaa6d2ae8", null ],
    [ "data", "interface_pgl_maxicode_msg_structured.html#a3d9f0a4d72b4a80275951d8f15190a09", null ]
];