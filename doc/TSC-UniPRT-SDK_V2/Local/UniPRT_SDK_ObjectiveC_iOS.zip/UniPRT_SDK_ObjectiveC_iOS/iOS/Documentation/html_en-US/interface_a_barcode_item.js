var interface_a_barcode_item =
[
    [ "initWithStart:data:", "interface_a_barcode_item.html#a2de5aa7e7f420feca9762daa4c06aceb", null ]
];