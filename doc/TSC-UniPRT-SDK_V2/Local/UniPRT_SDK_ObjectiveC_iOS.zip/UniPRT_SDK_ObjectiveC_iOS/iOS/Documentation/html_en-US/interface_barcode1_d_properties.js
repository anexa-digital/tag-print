var interface_barcode1_d_properties =
[
    [ "init", "interface_barcode1_d_properties.html#a34b0521c636bda6a44a44968056c5b7c", null ],
    [ "height", "interface_barcode1_d_properties.html#a3e55dc793a5203763aaf7d16b7407013", null ],
    [ "magnification", "interface_barcode1_d_properties.html#aa7bb14862a49d1b9bb8c81d1a7f803d0", null ],
    [ "printHumanReadable", "interface_barcode1_d_properties.html#a8b0c2735abbf3315fd810427232999a1", null ],
    [ "printHumanReadableOnTop", "interface_barcode1_d_properties.html#aa63bdd822deae7ad2f15b655501e8dcd", null ],
    [ "rotation", "interface_barcode1_d_properties.html#a7e7fc81416b8f94a853ec7032ac1baf2", null ],
    [ "type", "interface_barcode1_d_properties.html#ac9502f9b07f54eaa0089e2280c84075a", null ]
];