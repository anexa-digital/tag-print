var interface_ruler =
[
    [ "initWithScale:", "interface_ruler.html#afec401ba8f0d58febc99087a8e75313d", null ],
    [ "scale", "interface_ruler.html#a04945250856b4fbc6e6396e10a7dff07", null ]
];