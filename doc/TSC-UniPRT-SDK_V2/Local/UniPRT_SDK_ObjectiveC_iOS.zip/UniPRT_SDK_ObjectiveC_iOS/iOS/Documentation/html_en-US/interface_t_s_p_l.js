var interface_t_s_p_l =
[
    [ "alignmentToString:", "interface_t_s_p_l.html#a24bd5c384bd98089aa999e886e273d78", null ],
    [ "barcodeType1DToString:", "interface_t_s_p_l.html#a2235a2f00807ff5ecc89271995d24a69", null ],
    [ "barcodeType2DToString:", "interface_t_s_p_l.html#ab5b1402e1fb56852c739549103e7c524", null ],
    [ "builtInFontSizeForFontName:", "interface_t_s_p_l.html#af1ba0a73c65150b2d20e95bc4b65fee8", null ],
    [ "getPrintableDataFrameChar:", "interface_t_s_p_l.html#aba18548ef82fa178c2b159d9e01b9b17", null ],
    [ "igpDotsFromDots:dpiResolution:", "interface_t_s_p_l.html#acd684aae182d6155bb728b664edcf866", null ],
    [ "minLT:", "interface_t_s_p_l.html#a4ed201bd21c2c522b56549a0b56bdcfa", null ],
    [ "rfidFormatForType:", "interface_t_s_p_l.html#ae76b1d159fd4bc966dddc324e2f738f0", null ],
    [ "rfidMemBlockToString:", "interface_t_s_p_l.html#a331d3097dec9e8155242f8c6d0b68b93", null ],
    [ "rotationToString:", "interface_t_s_p_l.html#a48132e9c6fac2192e21602578ed62692", null ]
];