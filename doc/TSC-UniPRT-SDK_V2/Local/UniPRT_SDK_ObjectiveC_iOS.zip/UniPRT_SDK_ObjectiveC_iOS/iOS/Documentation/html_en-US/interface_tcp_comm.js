var interface_tcp_comm =
[
    [ "close", "interface_tcp_comm.html#a2f338a3455f6dc67b0ae5f903fb3b54d", null ],
    [ "descriptorUseIp:descriptorUsePort:", "interface_tcp_comm.html#a1f191ecd315d06d4b1747398cf5b2c96", null ],
    [ "initWithIPAddress:port:", "interface_tcp_comm.html#a02c4c7903dc81ccace2dd8cc45db4a68", null ],
    [ "NS_ENUM", "interface_tcp_comm.html#a8a196727d58ea83bc4a186757ffbc402", null ],
    [ "open", "interface_tcp_comm.html#ab37670c3e525710fed0958e9035f040d", null ],
    [ "read", "interface_tcp_comm.html#adec7c2cd1597828cdc452728e68dd1ed", null ],
    [ "sendPrintFile:fileName:", "interface_tcp_comm.html#abfcc9fd628361740cc36e46fe127a0bc", null ],
    [ "sendPrintString:data:", "interface_tcp_comm.html#a58d867f249efb6adc1c1706167ef96a6", null ],
    [ "validateDescriptor:withPortType:", "interface_tcp_comm.html#a40456b165a20a57f88014917a80b66e1", null ],
    [ "write:", "interface_tcp_comm.html#ae8ff8e14f6820e8775877100e5f8a544", null ],
    [ "writeAndWaitForResponse:responseStartTimeOut:responseEndTimeOut:completionToken:", "interface_tcp_comm.html#a89cfe061867147294b3da84577472159", null ],
    [ "writeAndWaitForResponseJson:responseStartTimeOut:responseEndTimeOut:completionToken:", "interface_tcp_comm.html#ad150364261d84e16dff0f37864d4e69f", null ],
    [ "writePrinterFile:", "interface_tcp_comm.html#a90f28cbbd15fad4b1cdf5877e27c1da0", null ],
    [ "connected", "interface_tcp_comm.html#a3b853c777ffd77a3f3a8b461e7ac4abf", null ]
];