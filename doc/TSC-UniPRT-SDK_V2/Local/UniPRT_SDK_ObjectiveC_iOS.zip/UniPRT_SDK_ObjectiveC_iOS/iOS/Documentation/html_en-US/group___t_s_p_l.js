var group___t_s_p_l =
[
    [ "Barcode_1D", "interface_barcode__1_d.html", [
      [ "description", "interface_barcode__1_d.html#a4d45a85b0de300708af17dc29160b803", null ],
      [ "init", "interface_barcode__1_d.html#ae09a57a54ebce54b2f19083fafd46527", null ],
      [ "initWithBarcodeItem:", "interface_barcode__1_d.html#ac088e3681a68f88b8a95bae05c8c4708", null ]
    ] ],
    [ "BarWidths", "interface_bar_widths.html", [
      [ "bcdMagnification1DWithType:printPlane:barWidths:", "interface_bar_widths.html#a46d85db3f81d2e005c86c5f861f96a20", null ],
      [ "init", "interface_bar_widths.html#a2ab9bb8c0045e3779987306de5799cf5", null ],
      [ "initWithNarrowBar:wideBar:", "interface_bar_widths.html#a4fe7ead5eed68f6edfa33ec63a394844", null ]
    ] ],
    [ "AztecBarcode", "interface_aztec_barcode.html", [
      [ "description", "interface_aztec_barcode.html#a47bf17e5f2e6bdcf35e883beaff2a334", null ],
      [ "init", "interface_aztec_barcode.html#a082d37e2a4db6c80d532e3f6ca952054", null ],
      [ "initWithStart:data:", "interface_aztec_barcode.html#adef4dc9246bc59127fb30a9c0c8c762d", null ]
    ] ],
    [ "DataMatrixBarcode", "interface_data_matrix_barcode.html", [
      [ "description", "interface_data_matrix_barcode.html#a35c2563b5519b42b05a75ad6fdc81046", null ],
      [ "init", "interface_data_matrix_barcode.html#a1e4bdf7ea02007ef4d80de05ea294d0e", null ],
      [ "initWithStart:data:", "interface_data_matrix_barcode.html#aecad65c8602a956325f07cf5d8634775", null ]
    ] ],
    [ "MaxicodeBarcode", "interface_maxicode_barcode.html", [
      [ "description", "interface_maxicode_barcode.html#a1dc545f2b4bb05aed7aeace11567691e", null ],
      [ "initWithStart:data:", "interface_maxicode_barcode.html#a3efed6921822bcc4915b956dc24c8b33", null ],
      [ "data", "interface_maxicode_barcode.html#ad76c10716c3b886abe879a11f16da611", null ],
      [ "rotation", "interface_maxicode_barcode.html#a35f5e3f29c99d5a09d8a5b8397257964", null ],
      [ "start", "interface_maxicode_barcode.html#a9d57963d8aab9564c5a95ca0273ded40", null ],
      [ "zipperPattern", "interface_maxicode_barcode.html#a28f3f502e7526229345797764be58cd0", null ]
    ] ],
    [ "MaxicodeMsg", "interface_maxicode_msg.html", [
      [ "initWithMode:primaryMsg:remainingMsg:", "interface_maxicode_msg.html#a929853ffb34a59744fb65190ad37f263", null ]
    ] ],
    [ "MaxicodeMsgStructured", "interface_maxicode_msg_structured.html", [
      [ "initWithMode:postalCode:countryCode:serviceClass:remainingMsg:", "interface_maxicode_msg_structured.html#a8979486210231e6aaa2763f6e0088067", null ],
      [ "data", "interface_maxicode_msg_structured.html#a3ce068e62e761aa81c9c3bf5bcd9ca3e", null ]
    ] ],
    [ "MaxicodeMsgStructuredOpenSystemStandard", "interface_maxicode_msg_structured_open_system_standard.html", [
      [ "initWithMode:year:postalCode:countryCode:serviceClass:remainingMsg:", "interface_maxicode_msg_structured_open_system_standard.html#a32ed2b92c446b33d2b0c0c7a530802a0", null ],
      [ "data", "interface_maxicode_msg_structured_open_system_standard.html#a78cb5682b6063c561748a0a0fc8880c0", null ]
    ] ],
    [ "Pdf417Barcode", "interface_pdf417_barcode.html", [
      [ "description", "interface_pdf417_barcode.html#a8505a9f6741b4b04f16edf0e00fb058a", null ],
      [ "init", "interface_pdf417_barcode.html#a0de754922c18bc774cc61f1382fc7b45", null ],
      [ "initWithStart:data:", "interface_pdf417_barcode.html#a913842f91a3c22cfebcfb2f86832ef21", null ],
      [ "data", "interface_pdf417_barcode.html#aed1b5b83755e5e3a8b51b52b89fd41e2", null ],
      [ "start", "interface_pdf417_barcode.html#a3d55e51abadd643a6d7f6eff670ee126", null ]
    ] ],
    [ "QRBarcode", "interface_q_r_barcode.html", [
      [ "description", "interface_q_r_barcode.html#a56eee5fc33a78488d0833aa0fe09bf20", null ],
      [ "init", "interface_q_r_barcode.html#ae79d9c1411df553ef4b84b88adfb164b", null ],
      [ "initWithStart:data:", "interface_q_r_barcode.html#af9c1ad34ec79fac55ff1f8dc81979431", null ],
      [ "initWithStart:manuallyEncodedData:", "interface_q_r_barcode.html#af5274c1adcef84dc3804b9caf2e6f543", null ]
    ] ],
    [ "Label", "interface_label.html", [
      [ "addObject:", "interface_label.html#a9193c0b98cd1b806c31538160a422cd1", null ],
      [ "addRawContent:", "interface_label.html#adf581a7505de359705f534d17ef45590", null ],
      [ "description", "interface_label.html#a43db2bf185180de3bcc1306bbd0b2447", null ],
      [ "initWithName:", "interface_label.html#a67eb8f8e05639e11674c8fdc22415fd4", null ],
      [ "SetName:", "interface_label.html#ac397ebbd2974b5dc059e3c0b5d210bdd", null ],
      [ "form", "interface_label.html#a2e0641f8c0f450ad749729bf79b66f46", null ],
      [ "name", "interface_label.html#a96d09ab19df0547c9586cdd5168c94a9", null ],
      [ "scale", "interface_label.html#ae4bd8832cb127ca266103e6f9c35d02c", null ]
    ] ],
    [ "TsplPicture", "interface_tspl_picture.html", [
      [ "description", "interface_tspl_picture.html#a3a7793c96228d9e08aad32c1e361e372", null ],
      [ "initWithStart:imageName:", "interface_tspl_picture.html#aff8bb187f9001f6315a1c9ac0e3b7797", null ],
      [ "ImageName", "interface_tspl_picture.html#a37f9a7f334102dc900d61f648ed01b65", null ],
      [ "Ruler", "interface_tspl_picture.html#a5f2835005a24bcb2b203686bc6f1e8eb", null ],
      [ "Start", "interface_tspl_picture.html#af544f20c681f6ee07b1d69d85a21608c", null ]
    ] ],
    [ "Rfid_Write", "interface_rfid___write.html", [
      [ "description", "interface_rfid___write.html#a9bd433b1c14a9cc3f17e5cf3d1ff56e1", null ],
      [ "init", "interface_rfid___write.html#a464d6ff3ad0ffd07f8f240d1cb98cf6d", null ],
      [ "initWithMemBlock:data:", "interface_rfid___write.html#a4b453630f504be5c95c06180c965d782", null ]
    ] ],
    [ "_Box", "class___box.html", null ],
    [ "Line", "interface_line.html", [
      [ "description", "interface_line.html#a7cbd5497031df5552d3ba6530fff78af", null ],
      [ "initWithStart:end:lineThickness:", "interface_line.html#a3722f840633ba2359573baa9c99367e2", null ],
      [ "initWithXStart:yStart:xEnd:yEnd:lineThickness:", "interface_line.html#a96fad6f51ff1f333ee00d984357a475d", null ]
    ] ],
    [ "Text", "interface_text.html", [
      [ "description", "interface_text.html#ae235bc45d9f38e853666ee6f32859297", null ],
      [ "init", "interface_text.html#ac3ede3f36b3b6f75450f38feb2f00f08", null ],
      [ "initWithTextItem:", "interface_text.html#a85d746068fc4aca214caa2769502f428", null ],
      [ "referencePoint", "interface_text.html#aabbb28102c444a4cfb6c56dfc30aefd8", null ],
      [ "reverse", "interface_text.html#a372f8395f19b5e96d807b5b4f8ac629f", null ]
    ] ],
    [ "Utilities", "interface_utilities.html", [
      [ "TsplWindowsFontWithImageName:fontSize:rotation:fontStyle:fontFamilyName:content:", "interface_utilities.html#a536f69e35b9d305efcbc5527947bdd34", null ]
    ] ]
];