var interface_text_item =
[
    [ "initWithStart:data:", "interface_text_item.html#ac66501a41367a7d119be848d71f94d52", null ],
    [ "initWithStart:fontSize:data:", "interface_text_item.html#ae5db8fc3d0a2807ca9785d32cc946043", null ],
    [ "initWithX:y:data:", "interface_text_item.html#af64b0180aff922b2d8a4136bc186442d", null ],
    [ "initWithX:y:sizeX:sizeY:data:", "interface_text_item.html#a1fd6efac44e4484e41b56bfee14aa7ea", null ]
];