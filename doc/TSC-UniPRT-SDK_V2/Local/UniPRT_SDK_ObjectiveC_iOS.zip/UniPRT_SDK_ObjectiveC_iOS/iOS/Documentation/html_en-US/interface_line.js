var interface_line =
[
    [ "description", "interface_line.html#a7cbd5497031df5552d3ba6530fff78af", null ],
    [ "initWithStart:end:lineThickness:", "interface_line.html#a3722f840633ba2359573baa9c99367e2", null ],
    [ "initWithXStart:yStart:xEnd:yEnd:lineThickness:", "interface_line.html#a96fad6f51ff1f333ee00d984357a475d", null ]
];