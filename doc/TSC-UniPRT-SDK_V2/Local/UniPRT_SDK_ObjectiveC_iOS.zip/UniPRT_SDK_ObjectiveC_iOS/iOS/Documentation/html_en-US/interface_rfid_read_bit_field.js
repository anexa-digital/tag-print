var interface_rfid_read_bit_field =
[
    [ "init", "interface_rfid_read_bit_field.html#a06bfb0ac6d3b94186d12de3edc9f992b", null ],
    [ "initWithBitCount:dataFormat:fieldId:", "interface_rfid_read_bit_field.html#a4f77172984e11bd9d4b126f245e414b0", null ],
    [ "bitCount", "interface_rfid_read_bit_field.html#a405e4b95ac0c25912b3f2110f44af275", null ],
    [ "dataFormat", "interface_rfid_read_bit_field.html#a28f461cefaa1f9092bd069fdec1cc2e0", null ],
    [ "fieldId", "interface_rfid_read_bit_field.html#aa77bd4a2df5ffa10073cc8b83f7bd624", null ],
    [ "fieldTag", "interface_rfid_read_bit_field.html#a6106262bf144dc61fd1d024d8271101b", null ]
];