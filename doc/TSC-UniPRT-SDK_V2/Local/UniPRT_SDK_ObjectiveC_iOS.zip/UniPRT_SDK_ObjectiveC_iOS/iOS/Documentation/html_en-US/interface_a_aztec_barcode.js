var interface_a_aztec_barcode =
[
    [ "getErrCorrectionPercent", "interface_a_aztec_barcode.html#a21bcb25b14e8e560af96c6ab26a82776", null ],
    [ "getLayersWithinRange", "interface_a_aztec_barcode.html#aaea9b07ebebe024e19e98f463f91f31a", null ],
    [ "hasLayers", "interface_a_aztec_barcode.html#aef03de7f1680157bf9a99fc1aa0e227b", null ],
    [ "init", "interface_a_aztec_barcode.html#a09c0081ffa085f0c41651d11be62fdc7", null ],
    [ "initWithStart:data:", "interface_a_aztec_barcode.html#aa793c9d2e8b08dacaffaa8fcfa413a16", null ],
    [ "cellSize", "interface_a_aztec_barcode.html#ad04765aee4421b9cd0739aed78e5e7e0", null ],
    [ "fixedErrCorrection", "interface_a_aztec_barcode.html#afa22e888d082a4ece4c9d8de7adad8b9", null ],
    [ "layers", "interface_a_aztec_barcode.html#a4f088da480db2c77a0d7c592e428b3c3", null ],
    [ "type", "interface_a_aztec_barcode.html#a2d7332c47c5233eb0cb5d7e3772e1716", null ]
];