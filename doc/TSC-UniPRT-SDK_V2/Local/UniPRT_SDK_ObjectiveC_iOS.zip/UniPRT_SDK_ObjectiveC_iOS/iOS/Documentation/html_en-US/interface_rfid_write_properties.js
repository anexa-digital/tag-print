var interface_rfid_write_properties =
[
    [ "init", "interface_rfid_write_properties.html#a620746c6057e6f42a412ba4d26bd99dc", null ],
    [ "bitCountTotal", "interface_rfid_write_properties.html#a9f9d663d227990cb6004184936a6d154", null ],
    [ "lockPW", "interface_rfid_write_properties.html#a9f317fb619b5981e4ec205cb90c35abb", null ],
    [ "mask", "interface_rfid_write_properties.html#a4f8d7f15ed2e8c813b44613fb9cd6b11", null ],
    [ "memoryBlock", "interface_rfid_write_properties.html#a41a5112fa03ae4605092c027636e1de0", null ],
    [ "offsetFromStart", "interface_rfid_write_properties.html#a49c081a860a262726b744d1c5281e4c5", null ],
    [ "permaLockPW", "interface_rfid_write_properties.html#ac7a9c8f6d79efce06a3aa72c222d52ec", null ],
    [ "pwFormat", "interface_rfid_write_properties.html#a72ecfbde87dfdcd229ac128474300625", null ]
];