var group___p_g_l =
[
    [ "PglBarcode_1D", "interface_pgl_barcode__1_d.html", [
      [ "description", "interface_pgl_barcode__1_d.html#a8020860e0773e0031076a7251e3af17e", null ],
      [ "init", "interface_pgl_barcode__1_d.html#a54f8c6d31284a2f434698e3b202ff0ec", null ],
      [ "initWithBarcodeItem:", "interface_pgl_barcode__1_d.html#a1c419b9cc4004e38a5ecdd1b6445ebfd", null ]
    ] ],
    [ "PglBarWidths", "interface_pgl_bar_widths.html", [
      [ "bcdMagnification1DWithType:printPlane:barWidths:", "interface_pgl_bar_widths.html#a75f9a23a815f35ce4db7e568a2096ca8", null ],
      [ "init", "interface_pgl_bar_widths.html#a65351c5ee03db7939a07185c04be45be", null ],
      [ "initWithNarrowBar:wideBar:", "interface_pgl_bar_widths.html#aa7a8d0280dd83ae4d2081ba9284c4953", null ]
    ] ],
    [ "PglAztecBarcode", "interface_pgl_aztec_barcode.html", [
      [ "description", "interface_pgl_aztec_barcode.html#a4709a1315d5619c2a08ed872c2965325", null ],
      [ "init", "interface_pgl_aztec_barcode.html#a19c29e69f11fd7044d1f150a3b5a4839", null ],
      [ "initWithStart:data:", "interface_pgl_aztec_barcode.html#a610adefe5c282e17b987d52c0c26aab4", null ]
    ] ],
    [ "PglDataMatrixBarcode", "interface_pgl_data_matrix_barcode.html", [
      [ "description", "interface_pgl_data_matrix_barcode.html#ad7657843e6b7a9d7f7f182196180d6bc", null ],
      [ "init", "interface_pgl_data_matrix_barcode.html#a8c42a01b9ac1ca7943593df73cdbf02b", null ],
      [ "initWithStart:data:", "interface_pgl_data_matrix_barcode.html#ae724a51d823bc64c7326b5bc78076ae2", null ]
    ] ],
    [ "PglMaxicodeBarcode", "interface_pgl_maxicode_barcode.html", [
      [ "description", "interface_pgl_maxicode_barcode.html#a452e86f39069ce8ee094e65a7c95f7fd", null ],
      [ "initWithStart:data:", "interface_pgl_maxicode_barcode.html#a9bba4a50ff3b296b7ebefa707f8df82d", null ],
      [ "data", "interface_pgl_maxicode_barcode.html#a9c43c13fe44f9f76fe56bd678182a0cd", null ],
      [ "rotation", "interface_pgl_maxicode_barcode.html#a368a2774b21bae619ed7343bc16af08d", null ],
      [ "start", "interface_pgl_maxicode_barcode.html#adba66916f37303f9dbba64e771e22481", null ],
      [ "zipperPattern", "interface_pgl_maxicode_barcode.html#aab7956c03a02e0b3c8df2ac7ed3bbc6d", null ]
    ] ],
    [ "PglMaxicodeMsg", "interface_pgl_maxicode_msg.html", [
      [ "initWithMode:primaryMsg:remainingMsg:", "interface_pgl_maxicode_msg.html#ae7d0205d192517a1ea862fae676e8d2e", null ],
      [ "data", "interface_pgl_maxicode_msg.html#a8e984dad31e445feedc35b2ad950ce5b", null ]
    ] ],
    [ "PglMaxicodeMsgStructured", "interface_pgl_maxicode_msg_structured.html", [
      [ "initWithMode:postalCode:countryCode:serviceClass:remainingMsg:", "interface_pgl_maxicode_msg_structured.html#a4f15334e7f63aaaf25b5a0dcaa6d2ae8", null ],
      [ "data", "interface_pgl_maxicode_msg_structured.html#a3d9f0a4d72b4a80275951d8f15190a09", null ]
    ] ],
    [ "PglMaxicodeMsgStructuredOpenSystemStandard", "interface_pgl_maxicode_msg_structured_open_system_standard.html", [
      [ "data", "interface_pgl_maxicode_msg_structured_open_system_standard.html#ac101a2e9ed7b4f047029b20268843d4c", null ]
    ] ],
    [ "PglPdf417Barcode", "interface_pgl_pdf417_barcode.html", [
      [ "description", "interface_pgl_pdf417_barcode.html#a8aaa82cee77cf1fdfdc75b35d31002d6", null ],
      [ "initWithStart:data:", "interface_pgl_pdf417_barcode.html#a35bf002ed5a1b5e6060ab0e9ee8b39a5", null ],
      [ "data", "interface_pgl_pdf417_barcode.html#a3e4e5bb6291d595c16deec88ad6a75d5", null ],
      [ "start", "interface_pgl_pdf417_barcode.html#aece0e51946b46f2e254eb526a73ff9b4", null ]
    ] ],
    [ "PglQRBarcode", "interface_pgl_q_r_barcode.html", [
      [ "description", "interface_pgl_q_r_barcode.html#afeccf9b28450c2a9663bbce0d5f41bc0", null ],
      [ "initWithStart:data:", "interface_pgl_q_r_barcode.html#a8ae6c13a17d74728a2531820efea0e41", null ],
      [ "initWithStart:dataManuallyEncoded:", "interface_pgl_q_r_barcode.html#a38c3d860f6dd0675f6b977ef030b3862", null ]
    ] ],
    [ "PglLabel", "interface_pgl_label.html", [
      [ "addObject:", "interface_pgl_label.html#ad6f080ac48fccb9f67e0c7f3ad0c9eef", null ],
      [ "addRawContent:", "interface_pgl_label.html#a34d1ae09bd48fb438f06f149e2e6935f", null ],
      [ "description", "interface_pgl_label.html#a2953f6fa21a98e245524961179fcb244", null ],
      [ "initWithName:", "interface_pgl_label.html#a084b72ded1ed42bccebc1dd02261bbd4", null ],
      [ "form", "interface_pgl_label.html#a9d0fb6f6c93516b37dfd2f86c6716194", null ],
      [ "name", "interface_pgl_label.html#ac93c470f6e87e75f384ea6080c16dc2f", null ],
      [ "scale", "interface_pgl_label.html#a6b9ef430fb32ad3100743cd872868c98", null ]
    ] ],
    [ "PglPicture", "interface_pgl_picture.html", [
      [ "description", "interface_pgl_picture.html#a7e4d83fc10e1e9c41c53b9db1917020c", null ],
      [ "initWithStart:ImageName:", "interface_pgl_picture.html#ae81ff20c07b304c76d2676b6807fc647", null ],
      [ "ImageName", "interface_pgl_picture.html#a7313b4bc59e3f6fdba766b7bc6d784d1", null ],
      [ "Ruler", "interface_pgl_picture.html#a4ae333f0b221674f78979c979085c270", null ],
      [ "Start", "interface_pgl_picture.html#a0d08296cc538aff49761653d9e024286", null ]
    ] ],
    [ "PglRfid_Write", "interface_pgl_rfid___write.html", [
      [ "description", "interface_pgl_rfid___write.html#a005f5bd5c775b2e85bcc872e46b20955", null ],
      [ "init", "interface_pgl_rfid___write.html#aa30ef3b100b04a93866044c40028a7d8", null ],
      [ "initWithMemBlock:data:", "interface_pgl_rfid___write.html#a49be9dbb00ae1542e997c360059f29e4", null ]
    ] ],
    [ "PglBox", "interface_pgl_box.html", [
      [ "description", "interface_pgl_box.html#a58399b0d67dfafa0260373235120a628", null ],
      [ "initWithStart:end:lineThickness:", "interface_pgl_box.html#a3e5c8bfa2bcd03ff794fb20f38fe872b", null ],
      [ "initWithXStart:yStart:xEnd:yEnd:lineThickness:", "interface_pgl_box.html#a14b3ea17e8cec46aa122a5c907fb3219", null ],
      [ "cornerRounding", "interface_pgl_box.html#a1607986e5732ebc8d78385f9d08342a0", null ],
      [ "end", "interface_pgl_box.html#ab835bd9aa930ffba77fce9faf6995db6", null ],
      [ "lineThickness", "interface_pgl_box.html#a74f81b2d108ffd82618be09729c12f44", null ],
      [ "ruler", "interface_pgl_box.html#a6fce19bf7023d3dad794f8624cff1709", null ],
      [ "start", "interface_pgl_box.html#a40a49fada2544ac3c463b7534fcac065", null ]
    ] ],
    [ "PglLine", "interface_pgl_line.html", [
      [ "description", "interface_pgl_line.html#a013df8670e1414e8edae54fc562334db", null ],
      [ "initWithStart:end:lineThickness:", "interface_pgl_line.html#af6ca237f12d82e933b07ca7a24c7e664", null ],
      [ "initWithXStart:yStart:xEnd:yEnd:lineThickness:", "interface_pgl_line.html#ac0ed40e954810da86f8a65da5e49f9a9", null ]
    ] ],
    [ "PglText", "interface_pgl_text.html", [
      [ "description", "interface_pgl_text.html#afce754e4b5fad0f2a2eb4b35990a2157", null ],
      [ "init", "interface_pgl_text.html#ac1fcc748169840b6d29695a917f94330", null ],
      [ "initWithText:", "interface_pgl_text.html#a5dccb6a9482a1fd66f9dec6f410b0192", null ]
    ] ],
    [ "PglUtilities", "interface_pgl_utilities.html", [
      [ "PglWindowsFontWithImageName:fontSize:rotation:fontStyle:fontFamilyName:content:", "interface_pgl_utilities.html#a50113af29af3a6c90086f2c65762a215", null ]
    ] ]
];