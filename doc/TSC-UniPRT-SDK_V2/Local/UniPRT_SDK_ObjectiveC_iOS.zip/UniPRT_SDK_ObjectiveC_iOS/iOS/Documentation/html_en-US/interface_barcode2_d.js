var interface_barcode2_d =
[
    [ "description", "interface_barcode2_d.html#acb8b0ce4a994c1e5ce913a333e760739", null ],
    [ "initWithBcdProps:SR:SC:Data:", "interface_barcode2_d.html#a7ea27e05a836a509f20e384feb2198cc", null ],
    [ "initWithBcdType:SR:SC:Data:", "interface_barcode2_d.html#a0c23b0067d31cd0dc6ae2a0ee214ee51", null ],
    [ "bcdType", "interface_barcode2_d.html#a2ae6e06867e777ac630490ee0eee2945", null ],
    [ "data", "interface_barcode2_d.html#a6f20b7dcebdcf1871eb5a9742cbdfcc4", null ],
    [ "rotation", "interface_barcode2_d.html#a0b10121c19127f4f72550e6bfd8bb323", null ],
    [ "SC", "interface_barcode2_d.html#a8f6e5785fded0fde1d6874e264fa91ef", null ],
    [ "SR", "interface_barcode2_d.html#aade0991f247bc172725edd3889d013f1", null ]
];