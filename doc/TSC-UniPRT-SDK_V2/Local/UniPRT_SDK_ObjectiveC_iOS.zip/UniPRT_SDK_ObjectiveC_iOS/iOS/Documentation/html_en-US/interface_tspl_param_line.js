var interface_tspl_param_line =
[
    [ "init", "interface_tspl_param_line.html#ad3f8b29b3ec756de621acf20ab30dbb4", null ],
    [ "initWithStartOfLine:", "interface_tspl_param_line.html#a89272618f28f09ca19355f9827258752", null ],
    [ "initWithStartOfLine:endOfLine:", "interface_tspl_param_line.html#aabeca56dd70d1b8586c8e4ff9cab4b6a", null ]
];