var interface_bar_widths =
[
    [ "bcdMagnification1DWithType:printPlane:barWidths:", "interface_bar_widths.html#a46d85db3f81d2e005c86c5f861f96a20", null ],
    [ "init", "interface_bar_widths.html#a2ab9bb8c0045e3779987306de5799cf5", null ],
    [ "initWithNarrowBar:wideBar:", "interface_bar_widths.html#a4fe7ead5eed68f6edfa33ec63a394844", null ]
];