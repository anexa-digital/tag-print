var interface_cell_square =
[
    [ "init", "interface_cell_square.html#ab314da598af154b5b3a3e97cb90f24f0", null ],
    [ "initWithXDim:ruler:", "interface_cell_square.html#aea31e355ea16449dd5b42836358e8a24", null ]
];