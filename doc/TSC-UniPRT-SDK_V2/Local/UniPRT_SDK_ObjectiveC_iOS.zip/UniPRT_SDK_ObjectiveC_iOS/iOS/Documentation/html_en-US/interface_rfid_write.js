var interface_rfid_write =
[
    [ "addBitField:", "interface_rfid_write.html#a10f22a8d6e8937533b84e124797aa667", null ],
    [ "description", "interface_rfid_write.html#abdeeafe04343de28bea352679acf1d5f", null ],
    [ "init", "interface_rfid_write.html#a309568c77147cb8c8d3803da05f3c00b", null ],
    [ "initWithMemBank:dataFormat:bitCount:data:", "interface_rfid_write.html#a9d64c41ab012907a3605dcb11e94dbfb", null ],
    [ "initWithWriteProperties:firstBitField:", "interface_rfid_write.html#abcfd217dcb55febc88f00e77b6781c94", null ],
    [ "bitFields", "interface_rfid_write.html#a2ec57d1f4064ca2d33ebf42cd59d15c9", null ],
    [ "props", "interface_rfid_write.html#a1748ffba1b53f9df3c16aae9d80a3707", null ]
];