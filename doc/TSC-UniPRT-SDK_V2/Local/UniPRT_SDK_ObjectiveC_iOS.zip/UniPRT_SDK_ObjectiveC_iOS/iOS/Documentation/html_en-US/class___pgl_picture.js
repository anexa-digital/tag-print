var class___pgl_picture =
[
    [ "description", "class___pgl_picture.html#a01d854cdf5afb399d6ee6c99d7a950fd", null ],
    [ "initWithSR:SC:LogoName:", "class___pgl_picture.html#a5990763dbf934ac4d8245f0eb579e4b9", null ]
];