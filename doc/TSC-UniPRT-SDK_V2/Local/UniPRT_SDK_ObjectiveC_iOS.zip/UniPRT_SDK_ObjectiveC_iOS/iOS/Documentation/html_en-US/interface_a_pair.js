var interface_a_pair =
[
    [ "initWithX:y:", "interface_a_pair.html#a56c82642c6807f1879da636cfc0fb139", null ],
    [ "x", "interface_a_pair.html#a5f8e07575f898ee32114b1f5d1c9d8be", null ],
    [ "y", "interface_a_pair.html#a54c68a305f8793eddc2e996239500875", null ]
];