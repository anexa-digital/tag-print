var interface_maxicode_msg_structured =
[
    [ "initWithMode:postalCode:countryCode:serviceClass:remainingMsg:", "interface_maxicode_msg_structured.html#a8979486210231e6aaa2763f6e0088067", null ],
    [ "data", "interface_maxicode_msg_structured.html#a3ce068e62e761aa81c9c3bf5bcd9ca3e", null ]
];