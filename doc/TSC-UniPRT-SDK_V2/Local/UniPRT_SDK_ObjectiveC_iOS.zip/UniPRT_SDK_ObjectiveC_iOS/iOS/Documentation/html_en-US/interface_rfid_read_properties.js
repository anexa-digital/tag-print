var interface_rfid_read_properties =
[
    [ "init", "interface_rfid_read_properties.html#af34c77fc42caf37ca916b062b222db7c", null ],
    [ "initWithBitCountTotal:memoryBlock:", "interface_rfid_read_properties.html#ab483d232201fe86c138983fefcad0cf2", null ],
    [ "aesKey", "interface_rfid_read_properties.html#adb23e9afaa627de9a6391003c030758d", null ],
    [ "bitCountTotal", "interface_rfid_read_properties.html#a00155dad6f0769e6fdfed0dbc22b2443", null ],
    [ "memoryBlock", "interface_rfid_read_properties.html#a6d87813d556c01b6aad491f533572f46", null ],
    [ "offsetFromStart", "interface_rfid_read_properties.html#a75fc2bc1a93922b5fa10a0ccad8211bc", null ],
    [ "permaUnLockPW", "interface_rfid_read_properties.html#a0acbea038f403538cbeaf6676740688f", null ],
    [ "pwFormat", "interface_rfid_read_properties.html#a62943ab7f8f97ca2c34fb6cac4c41ac8", null ],
    [ "unlockPW", "interface_rfid_read_properties.html#a10d100872eefe5d6263c866b1752f62e", null ]
];