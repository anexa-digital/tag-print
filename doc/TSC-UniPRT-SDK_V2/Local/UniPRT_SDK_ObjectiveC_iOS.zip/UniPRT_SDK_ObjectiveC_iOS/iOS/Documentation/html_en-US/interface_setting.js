var interface_setting =
[
    [ "description", "interface_setting.html#a32540d2db72cfbf8b4a7ec455ead5eeb", null ],
    [ "increment", "interface_setting.html#a9e8e60dd62c32a853f97c2f6404fc55c", null ],
    [ "maximum", "interface_setting.html#a2ff9bb219fa51232a36c75448ba7b49d", null ],
    [ "minimum", "interface_setting.html#a1ca8fcb9527b1067f12b9a0d724bb7b1", null ],
    [ "options", "interface_setting.html#a92af968672aa17f2143f510b32cb8ac8", null ],
    [ "permission", "interface_setting.html#a45f5d6f2260be4f26735a558a11fb110", null ],
    [ "type", "interface_setting.html#a074df4ca47e559eaca97182c2efe7b51", null ],
    [ "value", "interface_setting.html#a18d6c65e7d1b05613eecfe8828999de3", null ]
];