var interface_label =
[
    [ "addObject:", "interface_label.html#a9193c0b98cd1b806c31538160a422cd1", null ],
    [ "addRawContent:", "interface_label.html#adf581a7505de359705f534d17ef45590", null ],
    [ "description", "interface_label.html#a43db2bf185180de3bcc1306bbd0b2447", null ],
    [ "initWithName:", "interface_label.html#a67eb8f8e05639e11674c8fdc22415fd4", null ],
    [ "SetName:", "interface_label.html#ac397ebbd2974b5dc059e3c0b5d210bdd", null ],
    [ "form", "interface_label.html#a2e0641f8c0f450ad749729bf79b66f46", null ],
    [ "name", "interface_label.html#a96d09ab19df0547c9586cdd5168c94a9", null ],
    [ "scale", "interface_label.html#ae4bd8832cb127ca266103e6f9c35d02c", null ]
];