var group___reports =
[
    [ "OdvReport", "interface_odv_report.html", [
      [ "data", "interface_odv_report.html#adcabf779a27bc91ea8908f7415730515", null ],
      [ "failed", "interface_odv_report.html#a9b869a5ee9408e50b557a86f010263a4", null ],
      [ "overallGrade", "interface_odv_report.html#a944810ad14b8a94480070879be5a0491", null ],
      [ "overallGradeAsFloat", "interface_odv_report.html#a385f799101afac01fb12b1e0b714a8f9", null ],
      [ "overallGradeLetter", "interface_odv_report.html#a1a2a4f7db66aa895cba9f737dafe3172", null ],
      [ "symbology", "interface_odv_report.html#a754f844f13e63ac11fb8c3140bf858c7", null ]
    ] ],
    [ "PrinterInfo", "interface_printer_info.html", [
      [ "firmwarePartNumber", "interface_printer_info.html#acdc9df37181cbb726f4ce8ad6005a2a7", null ],
      [ "firmwareVersion", "interface_printer_info.html#a11e68b3d929b6e76b70ecf4eb5532f77", null ],
      [ "hasClockOption", "interface_printer_info.html#a24547b83c4252effafdbbc635daa5769", null ],
      [ "hasOdvOption", "interface_printer_info.html#a981b46f047f7511be8b86c9ee7207d9b", null ],
      [ "hasRfidOption", "interface_printer_info.html#a400772f19be0686909c6efdaa3fff26f", null ],
      [ "model", "interface_printer_info.html#a566b128a2b49bb3a3f11397fb778b278", null ],
      [ "printheadResolution", "interface_printer_info.html#a4f98ec7151803042ef061cb27fcb9b84", null ],
      [ "serialNumber", "interface_printer_info.html#ad1cf57e45a03b4839f78321500946b73", null ],
      [ "setRawInfoWithDictionary:", "interface_printer_info.html#a27311568b452f95d3a9e25fd0828be23", null ],
      [ "rawInfo", "interface_printer_info.html#a8348cdaec7dc11823d5106ea26c36a1f", null ]
    ] ],
    [ "RfidReport", "interface_rfid_report.html", [
      [ "data", "interface_rfid_report.html#ae9da90fec940702389f5401dbff2c6f5", null ],
      [ "dataType", "interface_rfid_report.html#a525726f5dd9079bb29c71422872a78ea", null ],
      [ "failed", "interface_rfid_report.html#aabcc047bf493481a317e3a6e7c91f67d", null ],
      [ "isWriteOperation", "interface_rfid_report.html#aaad8974a6ce12d3d121d17699b41f5e8", null ],
      [ "rawReport", "interface_rfid_report.html#ac1a27148641e14c090c1a7e067cc5277", null ]
    ] ]
];