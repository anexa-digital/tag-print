var group___monitor =
[
    [ "OdvMonitor", "interface_odv_monitor.html", [
      [ "OdvReportCallback", "interface_odv_monitor.html#add4e1a191d3d54d7e6587cbba9c3b4d5", null ],
      [ "initWithCommDescriptor:", "interface_odv_monitor.html#a0e14b1e45aadc1ba83f391f466c53f38", null ],
      [ "initWithJsonComm:", "interface_odv_monitor.html#a7eee9ca0a1e8a611da0195f29c58ad3c", null ],
      [ "initWithTcpComm:", "interface_odv_monitor.html#a44dafd5dbf2836f1aed1ec3a1fff3427", null ],
      [ "SetOdvReportListening:", "interface_odv_monitor.html#a2937e077db4d1cfa07fa07408ee9c71f", null ],
      [ "odvReportCallback", "interface_odv_monitor.html#a190cabce1b08bcb0ea3ea794c43b0e61", null ],
      [ "odvReportListening", "interface_odv_monitor.html#a3d1781fac2c26ccd5070d0da4c94bbef", null ]
    ] ],
    [ "PrinterMonitor", "interface_printer_monitor.html", [
      [ "AlertStatusCallback", "interface_printer_monitor.html#a7a0656a13a2709e103fe24e0da7926a4", null ],
      [ "DisplayStatusCallback", "interface_printer_monitor.html#a9c1350443f6eb45649ac61cba964545f", null ],
      [ "EngineStatusCallback", "interface_printer_monitor.html#a28a158c1491480f38f25d80642ff8f9e", null ],
      [ "getEngineStatus", "interface_printer_monitor.html#a49593e3dbcfa06f14afdcffd98aca2cd", null ],
      [ "getFaultStatus", "interface_printer_monitor.html#a8fc0e17acec3a67ec0fd48bc3720996d", null ],
      [ "getPrinterInfo", "interface_printer_monitor.html#ad14199f37407ae0c8c92c96616e5881e", null ],
      [ "initWithCommDescriptor:", "interface_printer_monitor.html#a8a5e1a31232205e2663edd20ff0b0b02", null ],
      [ "initWithJsonComm:", "interface_printer_monitor.html#a080d86843306c3e6b76a535b795b55f4", null ],
      [ "initWithTcpComm:", "interface_printer_monitor.html#a162b5660badcc65c8c3e4c7f32f49962", null ],
      [ "SetAlertStatusListening:", "interface_printer_monitor.html#ae0f4f8b9816b44ba69b0fd1216d1c40f", null ],
      [ "SetDisplayStatusListening:", "interface_printer_monitor.html#ae7b88a5f33d95ef96310a2a1f93c991a", null ],
      [ "SetEngineStatusListening:", "interface_printer_monitor.html#a5460d780e95c766f6a00682abedf71e9", null ],
      [ "alertStatusCallback", "interface_printer_monitor.html#a8caadc56510dbf5a4c33d3c40e082c79", null ],
      [ "alertStatusListening", "interface_printer_monitor.html#a4b3ade732ee86891229d29076cca7115", null ],
      [ "displayStatusCallback", "interface_printer_monitor.html#afed4865406d32044098ab7cbbdb23720", null ],
      [ "displayStatusListening", "interface_printer_monitor.html#a11ff96a07db063e6c948d72f8be659d6", null ],
      [ "engineStatusCallback", "interface_printer_monitor.html#a81fc87ce175b64747f53890103c13c49", null ],
      [ "engineStatusListening", "interface_printer_monitor.html#acbca044f9e7ab7a77edaf5ad9d224816", null ]
    ] ],
    [ "RfidMonitor", "interface_rfid_monitor.html", [
      [ "RfidReportCallback", "interface_rfid_monitor.html#a810d18dace038478d018c0218984c760", null ],
      [ "initWithCommDescriptor:", "interface_rfid_monitor.html#ab89bbd61970abe07108b212fa0c9f147", null ],
      [ "initWithJsonComm:", "interface_rfid_monitor.html#a997d4ef3e4dad773eab381c0e508bd90", null ],
      [ "initWithTcpComm:", "interface_rfid_monitor.html#a670aa96095c489c48fd32d19658b3da3", null ],
      [ "SetRfidReportListening:", "interface_rfid_monitor.html#ae95183fe60ce54e587962ef5a6cdbecc", null ],
      [ "rfidReportCallback", "interface_rfid_monitor.html#a51d2fa7b0cc21d752fdc6886c4961cff", null ],
      [ "rfidReportListening", "interface_rfid_monitor.html#a6374661fbc5ac1d78a4eccb089d1a1e1", null ]
    ] ]
];