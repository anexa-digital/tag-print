var interface_a_maxicode_msg =
[
    [ "init", "interface_a_maxicode_msg.html#a4ff7d77c445fed36b5e56250289073b1", null ],
    [ "initWithMode:primaryMsg:remainingMsg:", "interface_a_maxicode_msg.html#a8c2c59a24fca071303a9a64fe341955a", null ],
    [ "data", "interface_a_maxicode_msg.html#a0fb11b15c5e8f7c3607dae975923f69e", null ],
    [ "mode", "interface_a_maxicode_msg.html#aef64cc203cd73ed67158c5dd6d2fca16", null ],
    [ "primaryMsg", "interface_a_maxicode_msg.html#ad51494900a87c50751065ce96a6f59a6", null ],
    [ "remainingMsg", "interface_a_maxicode_msg.html#af202025d2ec7f8bfb847440ea408e8b5", null ]
];