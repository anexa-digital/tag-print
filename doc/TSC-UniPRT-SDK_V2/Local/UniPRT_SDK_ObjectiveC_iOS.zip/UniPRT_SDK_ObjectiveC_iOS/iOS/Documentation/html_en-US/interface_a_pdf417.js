var interface_a_pdf417 =
[
    [ "initWithStart:data:", "interface_a_pdf417.html#a87acaf7a0ab3f462f1a6804723e0f4f2", null ],
    [ "limitRange:minimum:maximum:", "interface_a_pdf417.html#a4a261aadd155495cbd6c33ddd29c29d0", null ],
    [ "cellSize", "interface_a_pdf417.html#aa4d2916a9b1c935c57cb8801e370f974", null ],
    [ "columns", "interface_a_pdf417.html#a94a575986eabd042fccb00cb608d6d89", null ],
    [ "data", "interface_a_pdf417.html#a2c4a8184aa096be68a7df81e58c2e24c", null ],
    [ "errorCorrection", "interface_a_pdf417.html#a86b31833fd5b4f44d5601a8208a8caf7", null ],
    [ "rows", "interface_a_pdf417.html#a7ae135a3e1f46e7a016c623bdd790b85", null ],
    [ "start", "interface_a_pdf417.html#ad3a6d64dd2e3ac4a3b6526b9e66020ca", null ]
];