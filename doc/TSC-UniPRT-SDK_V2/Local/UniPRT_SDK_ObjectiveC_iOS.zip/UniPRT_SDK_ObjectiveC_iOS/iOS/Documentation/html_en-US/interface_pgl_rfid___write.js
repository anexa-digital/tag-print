var interface_pgl_rfid___write =
[
    [ "description", "interface_pgl_rfid___write.html#a005f5bd5c775b2e85bcc872e46b20955", null ],
    [ "init", "interface_pgl_rfid___write.html#aa30ef3b100b04a93866044c40028a7d8", null ],
    [ "initWithMemBlock:data:", "interface_pgl_rfid___write.html#a49be9dbb00ae1542e997c360059f29e4", null ]
];