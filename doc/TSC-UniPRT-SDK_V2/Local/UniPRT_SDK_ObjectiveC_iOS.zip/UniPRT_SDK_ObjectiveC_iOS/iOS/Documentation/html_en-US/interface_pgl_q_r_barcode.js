var interface_pgl_q_r_barcode =
[
    [ "description", "interface_pgl_q_r_barcode.html#afeccf9b28450c2a9663bbce0d5f41bc0", null ],
    [ "initWithStart:data:", "interface_pgl_q_r_barcode.html#a8ae6c13a17d74728a2531820efea0e41", null ],
    [ "initWithStart:dataManuallyEncoded:", "interface_pgl_q_r_barcode.html#a38c3d860f6dd0675f6b977ef030b3862", null ]
];