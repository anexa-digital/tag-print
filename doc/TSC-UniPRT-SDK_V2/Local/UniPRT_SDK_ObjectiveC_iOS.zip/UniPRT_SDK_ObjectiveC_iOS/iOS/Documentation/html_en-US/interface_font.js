var interface_font =
[
    [ "description", "interface_font.html#a52a9c7ea26de4dcc509aeb5c7a944e69", null ],
    [ "init", "interface_font.html#a60acba5a6701ae0ea17f0e06f475d75d", null ],
    [ "initWithName:", "interface_font.html#af3ef63b0320cecead1ce1e8b821a08e0", null ],
    [ "bold", "interface_font.html#a7482fda6e304ae940c32de1f51a8bc27", null ],
    [ "italic", "interface_font.html#ac3ca0d4baa1befa0f31cb27c6acbb00e", null ],
    [ "name", "interface_font.html#a3b81a0bedc05b120c140e86960a91677", null ]
];