var interface_rfid_read =
[
    [ "addBitField:", "interface_rfid_read.html#a3b179837f2b37b11e686f84fd2dcbfef", null ],
    [ "description", "interface_rfid_read.html#a5375abcd69330e70af922c6dca880400", null ],
    [ "initWithMemBank:dataFormat:bitCount:fieldId:", "interface_rfid_read.html#a86090c0e8813c0391764ff62f19bfc3e", null ],
    [ "initWithReadProperties:firstBitField:", "interface_rfid_read.html#ac45a279513ac4e6a9b7cf2fd0519ffa2", null ],
    [ "bitFields", "interface_rfid_read.html#ad6cdfdcce840f89e93a612ab9b893736", null ],
    [ "props", "interface_rfid_read.html#a53bb5d4935a556ceb7b84c0daa7fc2e6", null ]
];