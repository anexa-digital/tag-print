var interface_a_maxicode_msg_structured_open_system_standard =
[
    [ "init", "interface_a_maxicode_msg_structured_open_system_standard.html#a06bb2b6c8d51bd722b87691b308ef942", null ],
    [ "initWithMode:year:postalCode:countryCode:serviceClass:remainingMsg:", "interface_a_maxicode_msg_structured_open_system_standard.html#a36cd4c44bab9415d963cd57ab42f6731", null ],
    [ "countryCode", "interface_a_maxicode_msg_structured_open_system_standard.html#afb29a021678812798f582a82cbf2a134", null ],
    [ "mode", "interface_a_maxicode_msg_structured_open_system_standard.html#ad897170df41266f32cd9d7559d2d0932", null ],
    [ "postalCode", "interface_a_maxicode_msg_structured_open_system_standard.html#a12a30304c4d0b0355a583c6aacdc6bc5", null ],
    [ "remainingMsg", "interface_a_maxicode_msg_structured_open_system_standard.html#a2ceb205dd064edf06bf37952c31b6a21", null ],
    [ "serviceClass", "interface_a_maxicode_msg_structured_open_system_standard.html#ab695bf99f6f8839861f1b23411d1651c", null ],
    [ "year", "interface_a_maxicode_msg_structured_open_system_standard.html#a9fe6f8cd3d5c8b884fad7576864cd643", null ]
];