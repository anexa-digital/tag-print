var interface_ble_comm =
[
    [ "availableDevices", "interface_ble_comm.html#a1bb3ad2e3511a0c2aa4d84d6523701ea", null ],
    [ "close", "interface_ble_comm.html#a2e35255305a4b36a923a8b5ce7e541f3", null ],
    [ "isConnected", "interface_ble_comm.html#a987e7a4c3ddb358eb81d39e199629d0b", null ],
    [ "open:", "interface_ble_comm.html#a555de8b58a14ab735d957d2ee27ae541", null ],
    [ "read", "interface_ble_comm.html#a1145c377de9fcd23bdc5ede9c145c9e1", null ],
    [ "waitForDataWithTimeout:", "interface_ble_comm.html#a5ac71ded72e98b8f8a21ef823fbb8248", null ],
    [ "write:", "interface_ble_comm.html#a9d9b1b20b997f254c2c259b651a31d11", null ],
    [ "writeAndWaitForResponse:responseStartTimeOut:responseEndTimeOut:completionToken:", "interface_ble_comm.html#ad213a66c1b9c5f30929d62f35d79a09e", null ],
    [ "writeAndWaitForResponseJson:responseStartTimeOut:responseEndTimeOut:completionToken:", "interface_ble_comm.html#a7b931496225da819ebc224a1765de44a", null ],
    [ "_Nullable", "interface_ble_comm.html#a4ddc27f591651af05b082b2c4e912e20", null ],
    [ "centralManager", "interface_ble_comm.html#a6002087bbbcec45468f912946163d204", null ],
    [ "connectedPeripheral", "interface_ble_comm.html#aec70155b4d608845466fccae45a0fa76", null ],
    [ "discoveredDevices", "interface_ble_comm.html#afb998d239acc629c2f1ca35ee4fd0e3c", null ],
    [ "foundPeripherals", "interface_ble_comm.html#a40e50c4d4ebc106e43b4779ff3683aa6", null ],
    [ "readCharacteristics", "interface_ble_comm.html#a367a5d0ad59ef701f77dcc9c5a60787c", null ],
    [ "receivedData", "interface_ble_comm.html#ad14fcd7f141541089569a9eb36649fc8", null ],
    [ "writeCharacteristics", "interface_ble_comm.html#a8b40f0d8b6db540cb70728bcaec0b310", null ]
];