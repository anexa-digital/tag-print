var interface_pgl_picture =
[
    [ "description", "interface_pgl_picture.html#a7e4d83fc10e1e9c41c53b9db1917020c", null ],
    [ "initWithStart:ImageName:", "interface_pgl_picture.html#ae81ff20c07b304c76d2676b6807fc647", null ],
    [ "ImageName", "interface_pgl_picture.html#a7313b4bc59e3f6fdba766b7bc6d784d1", null ],
    [ "Ruler", "interface_pgl_picture.html#a4ae333f0b221674f78979c979085c270", null ],
    [ "Start", "interface_pgl_picture.html#a0d08296cc538aff49761653d9e024286", null ]
];