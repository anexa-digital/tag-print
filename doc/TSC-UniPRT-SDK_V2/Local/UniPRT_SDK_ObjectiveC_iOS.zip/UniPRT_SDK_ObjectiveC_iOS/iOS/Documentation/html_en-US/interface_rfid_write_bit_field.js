var interface_rfid_write_bit_field =
[
    [ "initWithBitCount:dataFormat:data:", "interface_rfid_write_bit_field.html#a45dc947821111934f6cc195f3b5a39d6", null ],
    [ "bitCount", "interface_rfid_write_bit_field.html#ae6ec8906bd9eea9b6abc147c578397c0", null ],
    [ "data", "interface_rfid_write_bit_field.html#a7ad186ed0e762f5f68773ce865cf964c", null ],
    [ "dataFormat", "interface_rfid_write_bit_field.html#a19586c48be8c23c466d08198bfa45047", null ]
];