var interface_a_picture =
[
    [ "initWithStart:imageName:", "interface_a_picture.html#aebee0dab47515069a639fc968628b714", null ],
    [ "ImageName", "interface_a_picture.html#acbbb90344f94859b72ee7a5db04fd48a", null ],
    [ "Ruler", "interface_a_picture.html#ab715731dc740792894921c01a9a2f418", null ],
    [ "Start", "interface_a_picture.html#adb10afb846d1bd747fae163835c31e06", null ]
];