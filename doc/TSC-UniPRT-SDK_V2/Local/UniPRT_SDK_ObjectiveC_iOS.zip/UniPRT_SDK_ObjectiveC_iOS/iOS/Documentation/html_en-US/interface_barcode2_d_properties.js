var interface_barcode2_d_properties =
[
    [ "init", "interface_barcode2_d_properties.html#ac1e6f7346c35c7b8cc0fb9606425b3aa", null ],
    [ "rotation", "interface_barcode2_d_properties.html#a8db3410da3f88d01a60f8c8cfb1a1c5e", null ],
    [ "type", "interface_barcode2_d_properties.html#a9f8e3bd8b93d1dfabb876b68b7317759", null ]
];