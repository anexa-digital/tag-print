var interface_a_bar_widths =
[
    [ "initWithNarrowBar:wideBar:", "interface_a_bar_widths.html#ac6c0b5a872bfb002a62dbeb3ac02362e", null ],
    [ "NS_UNAVAILABLE", "interface_a_bar_widths.html#ad962c29cee662ad79a32157aaeedd44d", null ]
];