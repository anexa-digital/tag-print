var interface_pgl_box =
[
    [ "description", "interface_pgl_box.html#a58399b0d67dfafa0260373235120a628", null ],
    [ "initWithStart:end:lineThickness:", "interface_pgl_box.html#a3e5c8bfa2bcd03ff794fb20f38fe872b", null ],
    [ "initWithXStart:yStart:xEnd:yEnd:lineThickness:", "interface_pgl_box.html#a14b3ea17e8cec46aa122a5c907fb3219", null ],
    [ "cornerRounding", "interface_pgl_box.html#a1607986e5732ebc8d78385f9d08342a0", null ],
    [ "end", "interface_pgl_box.html#ab835bd9aa930ffba77fce9faf6995db6", null ],
    [ "lineThickness", "interface_pgl_box.html#a74f81b2d108ffd82618be09729c12f44", null ],
    [ "ruler", "interface_pgl_box.html#a6fce19bf7023d3dad794f8624cff1709", null ],
    [ "start", "interface_pgl_box.html#a40a49fada2544ac3c463b7534fcac065", null ]
];