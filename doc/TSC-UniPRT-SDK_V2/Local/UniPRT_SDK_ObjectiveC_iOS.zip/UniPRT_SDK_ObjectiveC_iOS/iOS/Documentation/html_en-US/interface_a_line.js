var interface_a_line =
[
    [ "description", "interface_a_line.html#afabbbea028f41b2ed7fbeabf8e2c74b1", null ],
    [ "initWithStart:end:lineThickness:", "interface_a_line.html#ac9f3f32d7c5075127ad81c9eca64c72d", null ],
    [ "end", "interface_a_line.html#a1d4c7c77580efa285ba17dba32904697", null ],
    [ "lineThickness", "interface_a_line.html#af0f8022c39c36e6139e8f5df8ad9820d", null ],
    [ "ruler", "interface_a_line.html#afe9ee71cf3972cdbccd944bf10b77ffa", null ],
    [ "start", "interface_a_line.html#ad827571287ce272b5e66e470ce495312", null ]
];