var interface_scale =
[
    [ "description", "interface_scale.html#ac14778dabcea5babfced02d1ae633ea8", null ],
    [ "init", "interface_scale.html#add4e61975dc7e60cc9dcf66285940000", null ],
    [ "initWithUnits:horizontalDPI:verticalDPI:", "interface_scale.html#a6ed4d6ca7f84f9e1b432d2fa39fc0bcb", null ],
    [ "horzResolution", "interface_scale.html#a910265dcd263cf982dbbc1d2a4b88fdc", null ],
    [ "units", "interface_scale.html#a134af848e19cd4fa9934caf146fa0414", null ],
    [ "vertResolution", "interface_scale.html#afbf8781e186d9dd06da7bd5e74df58ff", null ]
];