var interface_maxicode_msg =
[
    [ "initWithMode:primaryMsg:remainingMsg:", "interface_maxicode_msg.html#a929853ffb34a59744fb65190ad37f263", null ]
];