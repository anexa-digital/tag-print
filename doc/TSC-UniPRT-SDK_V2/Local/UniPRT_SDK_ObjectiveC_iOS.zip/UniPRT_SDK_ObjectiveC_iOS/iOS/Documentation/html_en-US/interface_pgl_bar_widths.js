var interface_pgl_bar_widths =
[
    [ "bcdMagnification1DWithType:printPlane:barWidths:", "interface_pgl_bar_widths.html#a75f9a23a815f35ce4db7e568a2096ca8", null ],
    [ "init", "interface_pgl_bar_widths.html#a65351c5ee03db7939a07185c04be45be", null ],
    [ "initWithNarrowBar:wideBar:", "interface_pgl_bar_widths.html#aa7a8d0280dd83ae4d2081ba9284c4953", null ]
];