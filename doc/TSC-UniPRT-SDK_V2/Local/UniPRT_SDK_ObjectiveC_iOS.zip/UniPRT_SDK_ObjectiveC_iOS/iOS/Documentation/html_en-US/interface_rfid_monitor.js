var interface_rfid_monitor =
[
    [ "RfidReportCallback", "interface_rfid_monitor.html#a810d18dace038478d018c0218984c760", null ],
    [ "initWithCommDescriptor:", "interface_rfid_monitor.html#ab89bbd61970abe07108b212fa0c9f147", null ],
    [ "initWithJsonComm:", "interface_rfid_monitor.html#a997d4ef3e4dad773eab381c0e508bd90", null ],
    [ "initWithTcpComm:", "interface_rfid_monitor.html#a670aa96095c489c48fd32d19658b3da3", null ],
    [ "SetRfidReportListening:", "interface_rfid_monitor.html#ae95183fe60ce54e587962ef5a6cdbecc", null ],
    [ "rfidReportCallback", "interface_rfid_monitor.html#a51d2fa7b0cc21d752fdc6886c4961cff", null ],
    [ "rfidReportListening", "interface_rfid_monitor.html#a6374661fbc5ac1d78a4eccb089d1a1e1", null ]
];