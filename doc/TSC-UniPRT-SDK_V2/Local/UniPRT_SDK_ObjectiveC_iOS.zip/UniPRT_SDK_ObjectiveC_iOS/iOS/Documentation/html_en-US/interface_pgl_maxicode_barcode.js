var interface_pgl_maxicode_barcode =
[
    [ "description", "interface_pgl_maxicode_barcode.html#a452e86f39069ce8ee094e65a7c95f7fd", null ],
    [ "initWithStart:data:", "interface_pgl_maxicode_barcode.html#a9bba4a50ff3b296b7ebefa707f8df82d", null ],
    [ "data", "interface_pgl_maxicode_barcode.html#a9c43c13fe44f9f76fe56bd678182a0cd", null ],
    [ "rotation", "interface_pgl_maxicode_barcode.html#a368a2774b21bae619ed7343bc16af08d", null ],
    [ "start", "interface_pgl_maxicode_barcode.html#adba66916f37303f9dbba64e771e22481", null ],
    [ "zipperPattern", "interface_pgl_maxicode_barcode.html#aab7956c03a02e0b3c8df2ac7ed3bbc6d", null ]
];