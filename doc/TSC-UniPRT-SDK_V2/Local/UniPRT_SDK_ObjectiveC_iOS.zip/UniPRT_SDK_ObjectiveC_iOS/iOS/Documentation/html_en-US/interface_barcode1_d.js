var interface_barcode1_d =
[
    [ "description", "interface_barcode1_d.html#ab1e4fb331f552efde04c30cda2547dae", null ],
    [ "initWithBcdProps:SR:SC:Data:", "interface_barcode1_d.html#a7ad3351408c5759346facc1bb69f2a9c", null ],
    [ "initWithBcdType:SR:SC:Data:", "interface_barcode1_d.html#a47015df2ecf6e1d17d07b8c68ce5df44", null ],
    [ "bcdType", "interface_barcode1_d.html#a24535384bc885ebe11c491b072081536", null ],
    [ "data", "interface_barcode1_d.html#a75b3e17b92b1cbd103bc91c57a723eb5", null ],
    [ "height", "interface_barcode1_d.html#a451be18c4d3a33f9bce31086402a8ea8", null ],
    [ "magnification", "interface_barcode1_d.html#ae75e422d501fb5d69a2fa0670eec91f4", null ],
    [ "pdf", "interface_barcode1_d.html#aa43e5be8e741b648031f3600fc0dca6e", null ],
    [ "pdfLocTop", "interface_barcode1_d.html#af805c8c8e64d68b153a8d533e62abc10", null ],
    [ "rotation", "interface_barcode1_d.html#a6a3b1a5d0786dd15c509b6d2852b9f9b", null ],
    [ "SC", "interface_barcode1_d.html#afdb276f389d36b1ec7346af9ac3c630f", null ],
    [ "SR", "interface_barcode1_d.html#ad41aa77287217fc044bc24592f38eb4f", null ]
];