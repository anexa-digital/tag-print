var interface_tspl_cmd =
[
    [ "init", "interface_tspl_cmd.html#a701f3cc5a6ff992021d7025716f4f1ff", null ],
    [ "initWithCmd:", "interface_tspl_cmd.html#ae71e4e3cf04f95ab3b6db32bcba95986", null ],
    [ "initWithCmd:cmdSuffix:", "interface_tspl_cmd.html#a193180c3b25f9e31c80a8fb9952fe099", null ],
    [ "initWithUseSfcc:cmd:cmdSuffix:", "interface_tspl_cmd.html#afc6463bc675713564ec952fa9805a36c", null ]
];