var interface_pgl_aztec_barcode =
[
    [ "description", "interface_pgl_aztec_barcode.html#a4709a1315d5619c2a08ed872c2965325", null ],
    [ "init", "interface_pgl_aztec_barcode.html#a19c29e69f11fd7044d1f150a3b5a4839", null ],
    [ "initWithStart:data:", "interface_pgl_aztec_barcode.html#a610adefe5c282e17b987d52c0c26aab4", null ]
];