var indexSectionsWithContent =
{
  0: "123_abcdfghijlmnopqrstuw与写加命我支数管范读软载键",
  1: "bcdjlst",
  2: "cdjl",
  3: "cdgjlr",
  4: "_bcglmoprstuw",
  5: "_abcdfghjlmnopqrstuw",
  6: "jpu与数软载"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "命名空间",
  3: "文件",
  4: "函数",
  5: "变量",
  6: "页"
};

