var searchData=
[
  ['width_20in_20键_0',['Width in 键',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'范例 1 - 读取 &quot;Image.Width-in&quot; 键'],['../_json_data_interchange_with_printer.html#autotoc_md10',1,'范例 2 - 写入 &quot;Image.Width-in&quot; 键']]],
  ['windowsfont_1',['WindowsFont',['../class_label_maker_s_d_k_1_1_label_maker_s_d_k.html#a83dea818a1503725c0c0ec99915922ba',1,'LabelMakerSDK::LabelMakerSDK']]],
  ['windowsfont_5ftyp_2',['WINDOWSFONT_TYP',['../namespace_label_maker_s_d_k.html#aecff1808aee1cfdce561fd14efef425c',1,'LabelMakerSDK']]],
  ['write_3',['Write',['../class_comm_s_d_k_1_1_comm_s_d_k.html#a593531104919b1773036ed4ca5d93042',1,'CommSDK::CommSDK']]],
  ['writeandwaitforresponse_4',['WriteAndWaitForResponse',['../class_comm_s_d_k_1_1_comm_s_d_k.html#a116d5d001fc59e3609ce63af8d38a85b',1,'CommSDK::CommSDK']]]
];
