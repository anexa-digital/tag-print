var searchData=
[
  ['read_0',['Read',['../class_comm_s_d_k_1_1_comm_s_d_k.html#a91372a3266a210afc835e94fcaef280c',1,'CommSDK::CommSDK']]],
  ['rfidmonitorconnection_1',['RfidMonitorConnection',['../class_json_s_d_k_1_1_json_s_d_k.html#a88f396133e51dcab25d81310cecf6625',1,'JsonSDK::JsonSDK']]],
  ['rfidmonitordispose_2',['RfidMonitorDispose',['../class_json_s_d_k_1_1_json_s_d_k.html#aa2d2feae0946848287bceb5d1b6fa646',1,'JsonSDK::JsonSDK']]]
];
