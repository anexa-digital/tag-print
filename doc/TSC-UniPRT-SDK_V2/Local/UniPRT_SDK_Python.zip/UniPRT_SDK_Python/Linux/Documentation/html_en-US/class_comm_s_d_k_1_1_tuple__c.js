var class_comm_s_d_k_1_1_tuple__c =
[
    [ "_fields_", "class_comm_s_d_k_1_1_tuple__c.html#a7cf0d2d8992bd73782aa2fb1b6236f15", null ],
    [ "_pack_", "class_comm_s_d_k_1_1_tuple__c.html#a091cb3d4d95b061d3456aced9a36f734", null ]
];