var searchData=
[
  ['read_0',['Read',['../class_comm_s_d_k_1_1_comm_s_d_k.html#a91372a3266a210afc835e94fcaef280c',1,'CommSDK::CommSDK']]],
  ['read_20image_20width_20in_20key_1',['Example 1 - Read &quot;Image.Width-in&quot; key',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'']]],
  ['read_20properties_20for_20multiple_20keys_2',['Example 3 - Read Properties for multiple keys',['../_json_data_interchange_with_printer.html#autotoc_md11',1,'']]],
  ['readme_5fautoidsdk_2emd_3',['README_AutoIdSdk.md',['../_r_e_a_d_m_e___auto_id_sdk_8md.html',1,'']]],
  ['rfid_5fmonitor_4',['Rfid_Monitor',['../namespace_json_s_d_k.html#ac25047299dec36ca7a2f66820b6108bb',1,'JsonSDK']]],
  ['rfid_5freport_5',['Rfid_Report',['../namespace_json_s_d_k.html#ae3f8664fcf2828af6b078c284da40bcc',1,'JsonSDK']]],
  ['rfid_5ftyp_6',['RFID_TYP',['../namespace_json_s_d_k.html#a55b17abcf209d86a8447b86f65feb3ee',1,'JsonSDK']]],
  ['rfidmonitorconnection_7',['RfidMonitorConnection',['../class_json_s_d_k_1_1_json_s_d_k.html#a88f396133e51dcab25d81310cecf6625',1,'JsonSDK::JsonSDK']]],
  ['rfidmonitordispose_8',['RfidMonitorDispose',['../class_json_s_d_k_1_1_json_s_d_k.html#aa2d2feae0946848287bceb5d1b6fa646',1,'JsonSDK::JsonSDK']]],
  ['rfidwr_5ftyp_9',['RFIDWR_TYP',['../namespace_label_maker_s_d_k.html#ac25f9b2dc81618c174a3e1167a334e5f',1,'LabelMakerSDK']]]
];
