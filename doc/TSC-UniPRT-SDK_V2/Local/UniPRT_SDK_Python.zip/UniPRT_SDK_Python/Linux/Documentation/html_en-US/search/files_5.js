var searchData=
[
  ['readme_5fautoidsdk_2emd_0',['README_AutoIdSdk.md',['../_r_e_a_d_m_e___auto_id_sdk_8md.html',1,'']]]
];
