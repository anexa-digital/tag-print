var searchData=
[
  ['rfid_5fmonitor_0',['Rfid_Monitor',['../namespace_json_s_d_k.html#ac25047299dec36ca7a2f66820b6108bb',1,'JsonSDK']]],
  ['rfid_5freport_1',['Rfid_Report',['../namespace_json_s_d_k.html#ae3f8664fcf2828af6b078c284da40bcc',1,'JsonSDK']]],
  ['rfid_5ftyp_2',['RFID_TYP',['../namespace_json_s_d_k.html#a55b17abcf209d86a8447b86f65feb3ee',1,'JsonSDK']]],
  ['rfidwr_5ftyp_3',['RFIDWR_TYP',['../namespace_label_maker_s_d_k.html#ac25f9b2dc81618c174a3e1167a334e5f',1,'LabelMakerSDK']]]
];
