var class_comm_s_d_k_1_1_descriptor_port_type =
[
    [ "DATA", "class_comm_s_d_k_1_1_descriptor_port_type.html#ab0f53362024dd34c26f1f283386844af", null ],
    [ "MGMT", "class_comm_s_d_k_1_1_descriptor_port_type.html#a042a08c780f20c578ec754a530743929", null ],
    [ "STATUS", "class_comm_s_d_k_1_1_descriptor_port_type.html#a3165cfaf55d8d3ca71c4234814c28c36", null ]
];