var searchData=
[
  ['data_0',['DATA',['../class_comm_s_d_k_1_1_descriptor_port_type.html#ab0f53362024dd34c26f1f283386844af',1,'CommSDK::DescriptorPortType']]],
  ['data_20interchange_20with_20printer_1',['JSON data-interchange with printer',['../_json_data_interchange_with_printer.html',1,'']]],
  ['data_20port_2',['General JSON Command Syntax - Data Port',['../_json_data_interchange_with_printer.html#autotoc_md5',1,'']]],
  ['datamatrix_5ftyp_3',['DATAMATRIX_TYP',['../namespace_label_maker_s_d_k.html#a851b2b1400fbdaa36eee0597831bece6',1,'LabelMakerSDK']]],
  ['descriptorporttype_4',['DescriptorPortType',['../class_comm_s_d_k_1_1_descriptor_port_type.html',1,'CommSDK']]],
  ['discovery_5',['Discovery',['../class_discovery_1_1_discovery.html',1,'Discovery.Discovery'],['../namespace_discovery.html',1,'Discovery']]],
  ['discovery_2epy_6',['Discovery.py',['../_discovery_8py.html',1,'']]]
];
