var searchData=
[
  ['brand_5fidx_0',['BRAND_IDX',['../class_discovery_1_1_b_r_a_n_d___i_d_x.html',1,'Discovery']]]
];
