var searchData=
[
  ['hasodvoption_0',['HasOdvOption',['../class_json_s_d_k_1_1st_printer_info.html#ad786ae9428c111d37b62d39fd8eb7dea',1,'JsonSDK::stPrinterInfo']]],
  ['hasrfidoption_1',['HasRfidOption',['../class_json_s_d_k_1_1st_printer_info.html#ad83b54433d75254452fc3fa3957d1e25',1,'JsonSDK::stPrinterInfo']]]
];
