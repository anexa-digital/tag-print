var searchData=
[
  ['qr_5ftyp_0',['QR_TYP',['../namespace_label_maker_s_d_k.html#a4635487dd9a8ae503cf03b99773319cc',1,'LabelMakerSDK']]]
];
