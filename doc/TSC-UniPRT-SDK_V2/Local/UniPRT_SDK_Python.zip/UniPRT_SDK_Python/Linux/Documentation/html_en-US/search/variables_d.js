var searchData=
[
  ['pdf417_5ftyp_0',['PDF417_TYP',['../namespace_label_maker_s_d_k.html#a7f88537b91a6dcb41f0703add36caf6b',1,'LabelMakerSDK']]],
  ['pgl_1',['PGL',['../namespace_label_maker_s_d_k.html#aaeb0ad4336d096dbaf461eed5b798271',1,'LabelMakerSDK']]],
  ['picture_5ftyp_2',['PICTURE_TYP',['../namespace_label_maker_s_d_k.html#abe98343a4fa79852726edc2800237334',1,'LabelMakerSDK']]],
  ['ping_5fipv6_5faddress_3',['ping_ipv6_address',['../class_discovery_1_1_discovery.html#a1d32cf37f9b110da6da2e1723e122f1a',1,'Discovery::Discovery']]],
  ['printer_5fmonitor_4',['Printer_Monitor',['../namespace_json_s_d_k.html#a6d49885acfd1c3481cc07143687f7285',1,'JsonSDK']]],
  ['printer_5ftyp_5',['PRINTER_TYP',['../namespace_json_s_d_k.html#a1fbc9d33660bf5795193c26139116005',1,'JsonSDK']]],
  ['printermonitor_5fodv_6',['PrinterMonitor_Odv',['../namespace_json_s_d_k.html#a211fce3547742826bf695304fbc8870d',1,'JsonSDK']]],
  ['printermonitor_5frfid_7',['PrinterMonitor_Rfid',['../namespace_json_s_d_k.html#a6e5223b646f8accf4e97fa3c698d8187',1,'JsonSDK']]],
  ['printheadresolution_8',['PrintheadResolution',['../class_json_s_d_k_1_1st_printer_info.html#adfca4b34685d1d77cfbadea620f8adfa',1,'JsonSDK::stPrinterInfo']]],
  ['ptx_9',['PTX',['../class_discovery_1_1_b_r_a_n_d___i_d_x.html#a2d133b530aeafed3200974f48822eb89',1,'Discovery::BRAND_IDX']]],
  ['ptx_5fusb_5fvid_10',['PTX_USB_VID',['../namespace_label_maker_s_d_k.html#abb42014cac9cd4aaaa8cbce7ba7e0e98',1,'LabelMakerSDK']]]
];
