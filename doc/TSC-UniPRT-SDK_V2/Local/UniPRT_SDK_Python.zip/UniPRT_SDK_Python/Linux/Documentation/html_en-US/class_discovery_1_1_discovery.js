var class_discovery_1_1_discovery =
[
    [ "GetPrinterList", "class_discovery_1_1_discovery.html#aa51670a0802020108a604f240f188587", null ],
    [ "GetPrinterList_IPv6", "class_discovery_1_1_discovery.html#acdc4cb5113d46125d9672ae4c28dd0cf", null ],
    [ "ping_ipv6_address", "class_discovery_1_1_discovery.html#a1d32cf37f9b110da6da2e1723e122f1a", null ]
];