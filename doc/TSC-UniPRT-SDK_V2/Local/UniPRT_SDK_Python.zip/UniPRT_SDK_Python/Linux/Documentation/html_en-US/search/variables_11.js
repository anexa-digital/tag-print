var searchData=
[
  ['tcp_5fbufsize_0',['TCP_BUFSIZE',['../namespace_json_s_d_k.html#a20c07da3102719578ae04a2a9f5b9c93',1,'JsonSDK']]],
  ['tcp_5fcomm_1',['TCP_COMM',['../class_comm_s_d_k_1_1_c_o_m_m___i_d_x.html#ae25f47fdf5082f0660e436912512e448',1,'CommSDK.COMM_IDX.TCP_COMM'],['../class_json_s_d_k_1_1_c_o_m_m___t_y_p.html#aa89decb37c8a7f48651fb6966e1ff1a9',1,'JsonSDK.COMM_TYP.TCP_COMM'],['../class_label_maker_s_d_k_1_1_c_o_m_m___t_y_p.html#a86a2a8e555fbfea3c6d6ac2c9f727ffb',1,'LabelMakerSDK.COMM_TYP.TCP_COMM']]],
  ['tcp_5fcomm_2',['Tcp_Comm',['../namespace_comm_s_d_k.html#aa8a2782b900778678fbc3a8d49b06736',1,'CommSDK']]],
  ['tcp_5fconnection_3',['Tcp_Connection',['../namespace_comm_s_d_k.html#a3fe2508cfe026dbf8f6135ae1057e2df',1,'CommSDK']]],
  ['text_5ftyp_4',['TEXT_TYP',['../namespace_label_maker_s_d_k.html#a70a71c12eb78a36fa028872bfe52e89c',1,'LabelMakerSDK']]],
  ['tsc_5',['TSC',['../class_discovery_1_1_b_r_a_n_d___i_d_x.html#a3c3a0fa9a5ba0650108fa9948065417a',1,'Discovery::BRAND_IDX']]],
  ['tsc_5fusb_5fvid_6',['TSC_USB_VID',['../namespace_label_maker_s_d_k.html#a81aa14526524a7923fba8e0f5cd87ecc',1,'LabelMakerSDK']]],
  ['tspl_7',['TSPL',['../namespace_label_maker_s_d_k.html#a6ded5ce66734d3c71d51381f8181b228',1,'LabelMakerSDK']]]
];
