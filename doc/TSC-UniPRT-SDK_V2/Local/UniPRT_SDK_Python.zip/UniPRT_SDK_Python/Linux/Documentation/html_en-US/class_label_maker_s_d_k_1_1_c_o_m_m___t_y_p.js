var class_label_maker_s_d_k_1_1_c_o_m_m___t_y_p =
[
    [ "BT_COMM", "class_label_maker_s_d_k_1_1_c_o_m_m___t_y_p.html#a8ad2ff690626c7ad738691172a122a0c", null ],
    [ "COM_COMM", "class_label_maker_s_d_k_1_1_c_o_m_m___t_y_p.html#a3fdead3b5f475c9a9ebc2d62e367351c", null ],
    [ "TCP_COMM", "class_label_maker_s_d_k_1_1_c_o_m_m___t_y_p.html#a86a2a8e555fbfea3c6d6ac2c9f727ffb", null ],
    [ "USB_COMM", "class_label_maker_s_d_k_1_1_c_o_m_m___t_y_p.html#a7995563ae78885323f25e81b02e45406", null ]
];