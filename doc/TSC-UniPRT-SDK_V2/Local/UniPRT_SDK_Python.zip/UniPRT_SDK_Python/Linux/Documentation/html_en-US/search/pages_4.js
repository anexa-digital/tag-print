var searchData=
[
  ['printer_0',['JSON data-interchange with printer',['../_json_data_interchange_with_printer.html',1,'']]],
  ['python_1',['Importing SDK Into Python',['../md_python__files_2get_started_import_sdk_to_vs.html',1,'']]]
];
