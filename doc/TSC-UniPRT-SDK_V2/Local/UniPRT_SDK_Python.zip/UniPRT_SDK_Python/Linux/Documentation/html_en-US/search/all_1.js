var searchData=
[
  ['2_20write_20image_20width_20in_20key_0',['Example 2 - Write &quot;Image.Width-in&quot; key',['../_json_data_interchange_with_printer.html#autotoc_md10',1,'']]]
];
