var searchData=
[
  ['pdf417_5ftyp_0',['PDF417_TYP',['../namespace_label_maker_s_d_k.html#a7f88537b91a6dcb41f0703add36caf6b',1,'LabelMakerSDK']]],
  ['pgl_1',['PGL',['../namespace_label_maker_s_d_k.html#aaeb0ad4336d096dbaf461eed5b798271',1,'LabelMakerSDK']]],
  ['picture_2',['Picture',['../class_label_maker_s_d_k_1_1_label_maker_s_d_k.html#a9bca8a5bd1f867405ea7673f322838b9',1,'LabelMakerSDK::LabelMakerSDK']]],
  ['picture_5ftyp_3',['PICTURE_TYP',['../namespace_label_maker_s_d_k.html#abe98343a4fa79852726edc2800237334',1,'LabelMakerSDK']]],
  ['ping_5fipv6_5faddress_4',['ping_ipv6_address',['../class_discovery_1_1_discovery.html#a1d32cf37f9b110da6da2e1723e122f1a',1,'Discovery::Discovery']]],
  ['port_5',['Port',['../_json_data_interchange_with_printer.html#autotoc_md5',1,'General JSON Command Syntax - Data Port'],['../_json_data_interchange_with_printer.html#autotoc_md4',1,'General JSON Command Syntax - Management Port']]],
  ['printer_6',['JSON data-interchange with printer',['../_json_data_interchange_with_printer.html',1,'']]],
  ['printer_5fmonitor_7',['Printer_Monitor',['../namespace_json_s_d_k.html#a6d49885acfd1c3481cc07143687f7285',1,'JsonSDK']]],
  ['printer_5ftyp_8',['PRINTER_TYP',['../namespace_json_s_d_k.html#a1fbc9d33660bf5795193c26139116005',1,'JsonSDK']]],
  ['printermonitor_5fodv_9',['PrinterMonitor_Odv',['../namespace_json_s_d_k.html#a211fce3547742826bf695304fbc8870d',1,'JsonSDK']]],
  ['printermonitor_5frfid_10',['PrinterMonitor_Rfid',['../namespace_json_s_d_k.html#a6e5223b646f8accf4e97fa3c698d8187',1,'JsonSDK']]],
  ['printermonitorconnection_11',['PrinterMonitorConnection',['../class_json_s_d_k_1_1_json_s_d_k.html#a0e9ab7fcfcdd13788d4c8b04373abfb4',1,'JsonSDK::JsonSDK']]],
  ['printermonitordispose_12',['PrinterMonitorDispose',['../class_json_s_d_k_1_1_json_s_d_k.html#a4c1a396b16256483fa5e516018e46fe1',1,'JsonSDK::JsonSDK']]],
  ['printheadresolution_13',['PrintheadResolution',['../class_json_s_d_k_1_1st_printer_info.html#adfca4b34685d1d77cfbadea620f8adfa',1,'JsonSDK::stPrinterInfo']]],
  ['project_14',['Add SDK to Python project',['../md_python__files_2get_started_import_sdk_to_vs.html#autotoc_md3',1,'']]],
  ['properties_20for_20multiple_20keys_15',['Example 3 - Read Properties for multiple keys',['../_json_data_interchange_with_printer.html#autotoc_md11',1,'']]],
  ['ptx_16',['PTX',['../class_discovery_1_1_b_r_a_n_d___i_d_x.html#a2d133b530aeafed3200974f48822eb89',1,'Discovery::BRAND_IDX']]],
  ['ptx_5fusb_5fvid_17',['PTX_USB_VID',['../namespace_label_maker_s_d_k.html#abb42014cac9cd4aaaa8cbce7ba7e0e98',1,'LabelMakerSDK']]],
  ['python_18',['Importing SDK Into Python',['../md_python__files_2get_started_import_sdk_to_vs.html',1,'']]],
  ['python_20project_19',['Add SDK to Python project',['../md_python__files_2get_started_import_sdk_to_vs.html#autotoc_md3',1,'']]]
];
