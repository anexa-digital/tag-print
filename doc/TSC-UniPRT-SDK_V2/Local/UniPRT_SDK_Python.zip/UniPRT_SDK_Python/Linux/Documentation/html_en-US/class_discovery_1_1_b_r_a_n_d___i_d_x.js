var class_discovery_1_1_b_r_a_n_d___i_d_x =
[
    [ "ALL", "class_discovery_1_1_b_r_a_n_d___i_d_x.html#a07302f8845ae1f93f344a1ab5ce30535", null ],
    [ "PTX", "class_discovery_1_1_b_r_a_n_d___i_d_x.html#a2d133b530aeafed3200974f48822eb89", null ],
    [ "TSC", "class_discovery_1_1_b_r_a_n_d___i_d_x.html#a3c3a0fa9a5ba0650108fa9948065417a", null ]
];