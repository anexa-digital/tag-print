var searchData=
[
  ['key_0',['Key',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'Example 1 - Read &quot;Image.Width-in&quot; key'],['../_json_data_interchange_with_printer.html#autotoc_md10',1,'Example 2 - Write &quot;Image.Width-in&quot; key']]],
  ['keys_1',['Keys',['../_json_data_interchange_with_printer.html#autotoc_md11',1,'Example 3 - Read Properties for multiple keys'],['../_json_data_interchange_with_printer.html#autotoc_md7',1,'Supported JSON Keys']]]
];
