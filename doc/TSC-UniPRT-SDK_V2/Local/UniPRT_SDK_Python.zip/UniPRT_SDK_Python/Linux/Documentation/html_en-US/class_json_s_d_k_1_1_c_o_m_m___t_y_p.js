var class_json_s_d_k_1_1_c_o_m_m___t_y_p =
[
    [ "BT_COMM", "class_json_s_d_k_1_1_c_o_m_m___t_y_p.html#a8374342fe03f82b1a576f3863126b5ad", null ],
    [ "TCP_COMM", "class_json_s_d_k_1_1_c_o_m_m___t_y_p.html#aa89decb37c8a7f48651fb6966e1ff1a9", null ],
    [ "USB_COMM", "class_json_s_d_k_1_1_c_o_m_m___t_y_p.html#ac0e9a4aa9b0953a1d624cf8472d4c552", null ]
];