var searchData=
[
  ['objcellrectptr_0',['ObjCellRectPtr',['../class_label_maker_s_d_k_1_1_label_maker_s_d_k.html#ab65a8f05ac4156794c8afb4dc64d4f9d',1,'LabelMakerSDK::LabelMakerSDK']]],
  ['objcellsquareptr_1',['ObjCellSquarePtr',['../class_label_maker_s_d_k_1_1_label_maker_s_d_k.html#a5df9d1f75ef5a191683c74977bee8247',1,'LabelMakerSDK::LabelMakerSDK']]],
  ['objectsptr_2',['ObjectsPtr',['../class_label_maker_s_d_k_1_1_label_maker_s_d_k.html#ae1a60e72d1c98fdcc2976f86e3d45af2',1,'LabelMakerSDK::LabelMakerSDK']]],
  ['objendptr_3',['ObjEndPtr',['../class_label_maker_s_d_k_1_1_label_maker_s_d_k.html#a547ebdf15a78ffcb663668bc7e075073',1,'LabelMakerSDK::LabelMakerSDK']]],
  ['objrulerptr_4',['ObjRulerPtr',['../class_label_maker_s_d_k_1_1_label_maker_s_d_k.html#a210432c2b28afbe969a3e0d95dbdbef5',1,'LabelMakerSDK::LabelMakerSDK']]],
  ['objstartptr_5',['ObjStartPtr',['../class_label_maker_s_d_k_1_1_label_maker_s_d_k.html#a51723ecdfed51c39dff970d0987ff6ec',1,'LabelMakerSDK::LabelMakerSDK']]],
  ['objtextitemptr_6',['ObjTextItemPtr',['../class_label_maker_s_d_k_1_1_label_maker_s_d_k.html#a4ba2f4fe43d32ab15e90874cbdff92d5',1,'LabelMakerSDK::LabelMakerSDK']]],
  ['odv_5fmonitor_7',['Odv_Monitor',['../namespace_json_s_d_k.html#a5a0ce510dad6c1f80edcb9417f1ccb60',1,'JsonSDK']]],
  ['odv_5ftyp_8',['ODV_TYP',['../namespace_json_s_d_k.html#ace7ce51f79d4662cf436900b90ea2201',1,'JsonSDK']]]
];
