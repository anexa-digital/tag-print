var class_json_s_d_k_1_1st_printer_info =
[
    [ "__init__", "class_json_s_d_k_1_1st_printer_info.html#a16a820a7d1f1a9faecec3ba222a0a166", null ],
    [ "FirmwarePartNumber", "class_json_s_d_k_1_1st_printer_info.html#a5564fbc9ca42cbce0ad844f51b384649", null ],
    [ "FirmwareVersion", "class_json_s_d_k_1_1st_printer_info.html#ae266673f163fb556cf737d0a92381047", null ],
    [ "HasOdvOption", "class_json_s_d_k_1_1st_printer_info.html#ad786ae9428c111d37b62d39fd8eb7dea", null ],
    [ "HasRfidOption", "class_json_s_d_k_1_1st_printer_info.html#ad83b54433d75254452fc3fa3957d1e25", null ],
    [ "Model", "class_json_s_d_k_1_1st_printer_info.html#a9e8a231c09ab0680dfdb09e17064f29c", null ],
    [ "PrintheadResolution", "class_json_s_d_k_1_1st_printer_info.html#adfca4b34685d1d77cfbadea620f8adfa", null ],
    [ "SerialNumber", "class_json_s_d_k_1_1st_printer_info.html#ac4a295d9ed111793ce695c716e707797", null ]
];