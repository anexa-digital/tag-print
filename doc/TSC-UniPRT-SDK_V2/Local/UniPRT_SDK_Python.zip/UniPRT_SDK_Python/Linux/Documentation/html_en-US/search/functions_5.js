var searchData=
[
  ['messengerget_0',['MessengerGet',['../class_json_s_d_k_1_1_json_s_d_k.html#a20852ff416c2afaaa0fa60a4efc614db',1,'JsonSDK::JsonSDK']]],
  ['messengerreadnextmsg_1',['MessengerReadNextMsg',['../class_json_s_d_k_1_1_json_s_d_k.html#ac53cfdef4c81232d81f8e8e523ef2cb0',1,'JsonSDK::JsonSDK']]],
  ['messengerrelease_2',['MessengerRelease',['../class_json_s_d_k_1_1_json_s_d_k.html#a36ca0c07ca2c18e4f5a8658732c72538',1,'JsonSDK::JsonSDK']]],
  ['messengersendmsg_3',['MessengerSendMsg',['../class_json_s_d_k_1_1_json_s_d_k.html#af8b8c3accf664bbd0550839c09f1d5a3',1,'JsonSDK::JsonSDK']]],
  ['messengersendmsgandwaitforresponse_4',['MessengerSendMsgAndWaitForResponse',['../class_json_s_d_k_1_1_json_s_d_k.html#ae14e3ce80951ebabeae147b8c06ba33f',1,'JsonSDK::JsonSDK']]],
  ['messengerunreadmsgcount_5',['MessengerUnreadMsgCount',['../class_json_s_d_k_1_1_json_s_d_k.html#a6dd1ac847d4883a2bb29df6d828e9756',1,'JsonSDK::JsonSDK']]]
];
