var indexSectionsWithContent =
{
  0: "123_abcdefghijklmnopqrstuw",
  1: "bcdjlst",
  2: "cdjl",
  3: "cdgjlr",
  4: "_bcglmoprstuw",
  5: "_abcdfghjlmnopqrstuw",
  6: "dfijpsuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

