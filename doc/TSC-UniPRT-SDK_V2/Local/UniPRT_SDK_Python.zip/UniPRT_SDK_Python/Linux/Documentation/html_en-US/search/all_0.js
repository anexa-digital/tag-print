var searchData=
[
  ['1_20read_20image_20width_20in_20key_0',['Example 1 - Read &quot;Image.Width-in&quot; key',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'']]]
];
