var class_comm_s_d_k_1_1_comm_s_d_k =
[
    [ "__init__", "class_comm_s_d_k_1_1_comm_s_d_k.html#ac9c3100c1f24e9842e2f1af6f3937071", null ],
    [ "BtConnection", "class_comm_s_d_k_1_1_comm_s_d_k.html#af3fd164dea6ee771558feee785aaa33e", null ],
    [ "Close", "class_comm_s_d_k_1_1_comm_s_d_k.html#a3baa3fa0409b9e3d166335392c2fde87", null ],
    [ "ComConnection", "class_comm_s_d_k_1_1_comm_s_d_k.html#a9b0917615c842f59548e1d3e63292f63", null ],
    [ "Connected", "class_comm_s_d_k_1_1_comm_s_d_k.html#a9dfd8b6aa02edad844035e8a32103dd1", null ],
    [ "GetAvailableDevices", "class_comm_s_d_k_1_1_comm_s_d_k.html#a002f21890c0d62262bf8b0b1e4406c8e", null ],
    [ "GetBytesAvailable", "class_comm_s_d_k_1_1_comm_s_d_k.html#a296757bf2583436cdbffd00c5f4a2872", null ],
    [ "GetComm", "class_comm_s_d_k_1_1_comm_s_d_k.html#a9ce781e55cb869147796e831b31a5293", null ],
    [ "Open", "class_comm_s_d_k_1_1_comm_s_d_k.html#abf7b968bbea7f7547f4428f4c17259ae", null ],
    [ "Read", "class_comm_s_d_k_1_1_comm_s_d_k.html#a91372a3266a210afc835e94fcaef280c", null ],
    [ "SendPrintFile", "class_comm_s_d_k_1_1_comm_s_d_k.html#a33e4ac4ab86b8c4e81b915efc0892bbf", null ],
    [ "SendPrintString", "class_comm_s_d_k_1_1_comm_s_d_k.html#adfb3ba18c0d02e89ab1a3bed09de3ade", null ],
    [ "TcpConnection", "class_comm_s_d_k_1_1_comm_s_d_k.html#a9ab85cd70d1be551599eeb5eebdb4b54", null ],
    [ "UsbConnection", "class_comm_s_d_k_1_1_comm_s_d_k.html#a8e7b6a08b1e9b2719f24a029f4367283", null ],
    [ "Write", "class_comm_s_d_k_1_1_comm_s_d_k.html#a593531104919b1773036ed4ca5d93042", null ],
    [ "WriteAndWaitForResponse", "class_comm_s_d_k_1_1_comm_s_d_k.html#a116d5d001fc59e3609ce63af8d38a85b", null ],
    [ "_socket", "class_comm_s_d_k_1_1_comm_s_d_k.html#af72f144586603642bd2fc9c28317e473", null ],
    [ "giComm", "class_comm_s_d_k_1_1_comm_s_d_k.html#ad9efc19351749c3e4a0a39126667130e", null ]
];