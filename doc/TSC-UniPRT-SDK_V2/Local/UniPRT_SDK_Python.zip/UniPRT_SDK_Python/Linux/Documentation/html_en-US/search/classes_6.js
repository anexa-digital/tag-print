var searchData=
[
  ['tuple_5fc_0',['Tuple_c',['../class_comm_s_d_k_1_1_tuple__c.html',1,'CommSDK.Tuple_c'],['../class_label_maker_s_d_k_1_1_tuple__c.html',1,'LabelMakerSDK.Tuple_c']]]
];
