var searchData=
[
  ['windowsfont_5ftyp_0',['WINDOWSFONT_TYP',['../namespace_label_maker_s_d_k.html#aecff1808aee1cfdce561fd14efef425c',1,'LabelMakerSDK']]]
];
