var searchData=
[
  ['data_0',['DATA',['../class_comm_s_d_k_1_1_descriptor_port_type.html#ab0f53362024dd34c26f1f283386844af',1,'CommSDK::DescriptorPortType']]],
  ['datamatrix_5ftyp_1',['DATAMATRIX_TYP',['../namespace_label_maker_s_d_k.html#a851b2b1400fbdaa36eee0597831bece6',1,'LabelMakerSDK']]]
];
