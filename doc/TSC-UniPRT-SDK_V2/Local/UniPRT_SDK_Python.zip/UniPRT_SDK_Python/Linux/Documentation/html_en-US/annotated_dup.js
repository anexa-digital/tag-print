var annotated_dup =
[
    [ "CommSDK", "namespace_comm_s_d_k.html", [
      [ "CObject", "class_comm_s_d_k_1_1_c_object.html", null ],
      [ "COMM_IDX", "class_comm_s_d_k_1_1_c_o_m_m___i_d_x.html", "class_comm_s_d_k_1_1_c_o_m_m___i_d_x" ],
      [ "CommSDK", "class_comm_s_d_k_1_1_comm_s_d_k.html", "class_comm_s_d_k_1_1_comm_s_d_k" ],
      [ "DescriptorPortType", "class_comm_s_d_k_1_1_descriptor_port_type.html", "class_comm_s_d_k_1_1_descriptor_port_type" ],
      [ "Tuple_c", "class_comm_s_d_k_1_1_tuple__c.html", "class_comm_s_d_k_1_1_tuple__c" ]
    ] ],
    [ "Discovery", "namespace_discovery.html", [
      [ "BRAND_IDX", "class_discovery_1_1_b_r_a_n_d___i_d_x.html", "class_discovery_1_1_b_r_a_n_d___i_d_x" ],
      [ "Discovery", "class_discovery_1_1_discovery.html", "class_discovery_1_1_discovery" ]
    ] ],
    [ "JsonSDK", "namespace_json_s_d_k.html", [
      [ "COMM_TYP", "class_json_s_d_k_1_1_c_o_m_m___t_y_p.html", "class_json_s_d_k_1_1_c_o_m_m___t_y_p" ],
      [ "JsonSDK", "class_json_s_d_k_1_1_json_s_d_k.html", "class_json_s_d_k_1_1_json_s_d_k" ],
      [ "stPrinterInfo", "class_json_s_d_k_1_1st_printer_info.html", "class_json_s_d_k_1_1st_printer_info" ]
    ] ],
    [ "LabelMakerSDK", "namespace_label_maker_s_d_k.html", [
      [ "COMM_TYP", "class_label_maker_s_d_k_1_1_c_o_m_m___t_y_p.html", "class_label_maker_s_d_k_1_1_c_o_m_m___t_y_p" ],
      [ "LabelMakerSDK", "class_label_maker_s_d_k_1_1_label_maker_s_d_k.html", "class_label_maker_s_d_k_1_1_label_maker_s_d_k" ],
      [ "Tuple_c", "class_label_maker_s_d_k_1_1_tuple__c.html", "class_label_maker_s_d_k_1_1_tuple__c" ]
    ] ]
];