var searchData=
[
  ['read_0',['Read',['../_comm_s_d_k_8cpp.html#a28792b9129f6c4b5ab9b0e1782b7a37c',1,'CommSDK.cpp']]],
  ['readme_5fautoidsdk_2emd_1',['README_AutoIdSdk.md',['../_r_e_a_d_m_e___auto_id_sdk_8md.html',1,'']]],
  ['rfid_5ftyp_2',['RFID_TYP',['../_json_s_d_k_8cpp.html#aba97ac7f06af4aaccf79c3e9f589bda2a191329af89d9795e517c337585916711',1,'JsonSDK.cpp']]],
  ['rfidmonitorconnection_3',['RfidMonitorConnection',['../_json_s_d_k_8cpp.html#a7a1c8e0c35beee3f6845192dff9d0c58',1,'JsonSDK.cpp']]],
  ['rfidmonitordispose_4',['RfidMonitorDispose',['../_json_s_d_k_8cpp.html#a350310216133a830def18ab4e85cba9d',1,'JsonSDK.cpp']]],
  ['rfidwritetype_5',['RfidWriteType',['../_label_maker_s_d_k_8cpp.html#aabdbb68e97a4bec3483a6c90fea939b7',1,'LabelMakerSDK.cpp']]]
];
