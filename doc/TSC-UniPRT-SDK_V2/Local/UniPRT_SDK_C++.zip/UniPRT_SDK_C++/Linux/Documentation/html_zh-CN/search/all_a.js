var searchData=
[
  ['image_20width_20in_20键_0',['Image Width in 键',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'范例 1 - 读取 &quot;Image.Width-in&quot; 键'],['../_json_data_interchange_with_printer.html#autotoc_md10',1,'范例 2 - 写入 &quot;Image.Width-in&quot; 键']]],
  ['in_20键_1',['In 键',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'范例 1 - 读取 &quot;Image.Width-in&quot; 键'],['../_json_data_interchange_with_printer.html#autotoc_md10',1,'范例 2 - 写入 &quot;Image.Width-in&quot; 键']]],
  ['info_5ftyp_2',['INFO_TYP',['../_json_s_d_k_8cpp.html#aba97ac7f06af4aaccf79c3e9f589bda2',1,'JsonSDK.cpp']]],
  ['items_3',['Settings Key/Value Items',['../ref_json_key_values.html',1,'']]]
];
