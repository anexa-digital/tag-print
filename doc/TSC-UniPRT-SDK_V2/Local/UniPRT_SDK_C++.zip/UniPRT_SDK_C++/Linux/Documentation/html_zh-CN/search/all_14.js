var searchData=
[
  ['sendprintfile_0',['SendPrintFile',['../_comm_s_d_k_8cpp.html#ab5ccd9a0b6828f1a7a4b4102fd3a9b3e',1,'CommSDK.cpp']]],
  ['sendprintstring_1',['SendPrintString',['../_comm_s_d_k_8cpp.html#a536215772922733d60d81b184191c7d2',1,'CommSDK.cpp']]],
  ['setalertstatuscallback_2',['SetAlertStatusCallback',['../_json_s_d_k_8cpp.html#a739bfb0d5d4287107f15978eaad2cfdc',1,'JsonSDK.cpp']]],
  ['setalertstatuslistening_3',['SetAlertStatusListening',['../_json_s_d_k_8cpp.html#a7dcdbf3de2bc21bd87422ead19cc1d68',1,'JsonSDK.cpp']]],
  ['setdisplaystatuscallback_4',['SetDisplayStatusCallback',['../_json_s_d_k_8cpp.html#a9d66c45b55c01aacd2a727671b0f4cfd',1,'JsonSDK.cpp']]],
  ['setdisplaystatuslistening_5',['SetDisplayStatusListening',['../_json_s_d_k_8cpp.html#ad1c4479d915febe32e27397b1265d1af',1,'JsonSDK.cpp']]],
  ['setenginestatuscallback_6',['SetEngineStatusCallback',['../_json_s_d_k_8cpp.html#aa45eb829a79e73a7f0582cbf5a0f85cb',1,'JsonSDK.cpp']]],
  ['setenginestatuslistening_7',['SetEngineStatusListening',['../_json_s_d_k_8cpp.html#aa298b35fe417f97493d77e6d1d032377',1,'JsonSDK.cpp']]],
  ['setodvreportcallback_8',['SetOdvReportCallback',['../_json_s_d_k_8cpp.html#aa769bf515e276443f75673bb7bc0d426',1,'JsonSDK.cpp']]],
  ['setodvreportlistening_9',['SetOdvReportListening',['../_json_s_d_k_8cpp.html#ae46ad71a186aa5c57774406b7412d5b3',1,'JsonSDK.cpp']]],
  ['setprinterconfig_10',['SetPrinterConfig',['../_json_s_d_k_8cpp.html#a11b28c936963bd235d58afcf86dcb13b',1,'JsonSDK.cpp']]],
  ['setprintervalue_11',['SetPrinterValue',['../_json_s_d_k_8cpp.html#aae32d8c80d61818a89de92b6e23703c3',1,'JsonSDK.cpp']]],
  ['setprintervalues_12',['SetPrinterValues',['../_json_s_d_k_8cpp.html#a3db146a995bfdc026da7f33217e2be76',1,'JsonSDK.cpp']]],
  ['setrfidreportcallback_13',['SetRfidReportCallback',['../_json_s_d_k_8cpp.html#a3d53f7303df79b2383b337f49f8754c8',1,'JsonSDK.cpp']]],
  ['setrfidreportlistening_14',['SetRfidReportListening',['../_json_s_d_k_8cpp.html#a0f70010c8fe28b067c5aaf1fb7077016',1,'JsonSDK.cpp']]],
  ['settings_20key_20value_20items_15',['Settings Key/Value Items',['../ref_json_key_values.html',1,'']]]
];
