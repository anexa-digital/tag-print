var searchData=
[
  ['c_20project_0',['加入软件开发工具包至 Linux C++ project',['../md_md__files_2get_started_import_sdk_to_vs.html#autotoc_md3',1,'']]],
  ['close_1',['Close',['../_comm_s_d_k_8cpp.html#a7f7a3199c392465d0767c6506c1af5b4',1,'CommSDK.cpp']]],
  ['closelabel_2',['CloseLabel',['../_label_maker_s_d_k_8cpp.html#adeece7ea266ad59129454c0c4de77f7b',1,'LabelMakerSDK.cpp']]],
  ['com_5fcomm_3',['COM_COMM',['../_comm_s_d_k_8cpp.html#a2dabfdd0beaed500a4be03ecd9b55ebaa83298c47029f5576c4cf9a8e8571cd6c',1,'COM_COMM:&#160;CommSDK.cpp'],['../_label_maker_s_d_k_8cpp.html#aa550a9606519a25b64fe3dc10b19dbd7a83298c47029f5576c4cf9a8e8571cd6c',1,'COM_COMM:&#160;LabelMakerSDK.cpp']]],
  ['comconnect_4',['ComConnect',['../_comm_s_d_k_8cpp.html#a32d3cad5773854018188dbb3ff69ecb9',1,'CommSDK.cpp']]],
  ['comm_5fidx_5',['COMM_IDX',['../_comm_s_d_k_8cpp.html#a2dabfdd0beaed500a4be03ecd9b55eba',1,'CommSDK.cpp']]],
  ['comm_5ftyp_6',['COMM_TYP',['../_label_maker_s_d_k_8cpp.html#aa550a9606519a25b64fe3dc10b19dbd7',1,'LabelMakerSDK.cpp']]],
  ['commsdk_2ecpp_7',['CommSDK.cpp',['../_comm_s_d_k_8cpp.html',1,'']]],
  ['connected_8',['Connected',['../_comm_s_d_k_8cpp.html#afe4e281f67d64c2d1fb66231242db18d',1,'CommSDK.cpp']]],
  ['createaztecbarcodes_9',['CreateAztecBarcodes',['../_label_maker_s_d_k_8cpp.html#a795af3951e972a97c581d0a88af16f2c',1,'LabelMakerSDK.cpp']]],
  ['createbarcode1d_10',['CreateBarcode1D',['../_label_maker_s_d_k_8cpp.html#a9f07b4e5f46b044e6c2e9760a7353ed8',1,'LabelMakerSDK.cpp']]],
  ['createboxs_11',['CreateBoxs',['../_label_maker_s_d_k_8cpp.html#ae7b88779e48ca98754f2641a443780e0',1,'LabelMakerSDK.cpp']]],
  ['createdatamatrixbarcodes_12',['CreateDataMatrixBarcodes',['../_label_maker_s_d_k_8cpp.html#a02e718ca09a13462ab9d8faef895ae9e',1,'LabelMakerSDK.cpp']]],
  ['createlabel_13',['CreateLabel',['../_label_maker_s_d_k_8cpp.html#af1e12a379bc0e98bcaa09e1be06f1fbb',1,'LabelMakerSDK.cpp']]],
  ['createlines_14',['CreateLines',['../_label_maker_s_d_k_8cpp.html#a51988141e1baaecfcf78317abf1a8542',1,'LabelMakerSDK.cpp']]],
  ['createmaxicodebarcodes_15',['CreateMaxicodeBarcodes',['../_label_maker_s_d_k_8cpp.html#ac686d452edd3ae4b093831ccfa5f7815',1,'LabelMakerSDK.cpp']]],
  ['createpdf417bcodes_16',['CreatePdf417Bcodes',['../_label_maker_s_d_k_8cpp.html#ad81638e09d5f5cd3ecdc33296ca078cc',1,'LabelMakerSDK.cpp']]],
  ['createqrbarcodes_17',['CreateQRBarcodes',['../_label_maker_s_d_k_8cpp.html#a83ead142f9be06f5f3d16f965a47eaac',1,'LabelMakerSDK.cpp']]],
  ['createrfidencode_18',['CreateRfidEncode',['../_label_maker_s_d_k_8cpp.html#a0e3c57eca5c08d2f837bc3b30926fba4',1,'LabelMakerSDK.cpp']]],
  ['createtexts_19',['CreateTexts',['../_label_maker_s_d_k_8cpp.html#a6654137a4e2699e5b6de004d1e4116a7',1,'LabelMakerSDK.cpp']]]
];
