var indexSectionsWithContent =
{
  0: "123_abcdfgijklmnopqrstuvw与写加命我支数管范读软载键",
  1: "cdgjlr",
  2: "bcfglmoprstuw",
  3: "ago",
  4: "abdlmpqrt",
  5: "ci",
  6: "_bcoprtu",
  7: "mnptu",
  8: "ijklsuv与数软载"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "文件",
  2: "函数",
  3: "变量",
  4: "类型定义",
  5: "枚举",
  6: "枚举值",
  7: "宏定义",
  8: "页"
};

