var searchData=
[
  ['items_0',['Settings Key/Value Items',['../ref_json_key_values.html',1,'']]]
];
