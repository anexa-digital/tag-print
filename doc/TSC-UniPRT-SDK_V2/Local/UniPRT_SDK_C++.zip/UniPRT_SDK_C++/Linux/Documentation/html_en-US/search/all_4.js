var searchData=
[
  ['add_20sdk_20to_20linux_20c_20project_0',['Add SDK to Linux C++ project',['../md_md__files_2get_started_import_sdk_to_vs.html#autotoc_md3',1,'']]],
  ['allmsg_1',['AllMsg',['../_json_s_d_k_8cpp.html#aa7db5cb7c6917f16b06be7695db43c83',1,'JsonSDK.cpp']]],
  ['aztecbarcodetype_2',['AztecBarcodeType',['../_label_maker_s_d_k_8cpp.html#a52b2ee5d817ed1d42f3db6fcdf6a0f5e',1,'LabelMakerSDK.cpp']]]
];
