var searchData=
[
  ['read_0',['Read',['../_comm_s_d_k_8cpp.html#a28792b9129f6c4b5ab9b0e1782b7a37c',1,'CommSDK.cpp']]],
  ['rfidmonitorconnection_1',['RfidMonitorConnection',['../_json_s_d_k_8cpp.html#a7a1c8e0c35beee3f6845192dff9d0c58',1,'JsonSDK.cpp']]],
  ['rfidmonitordispose_2',['RfidMonitorDispose',['../_json_s_d_k_8cpp.html#a350310216133a830def18ab4e85cba9d',1,'JsonSDK.cpp']]]
];
