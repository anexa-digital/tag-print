var searchData=
[
  ['for_20multiple_20keys_0',['Example 3 - Read Properties for multiple keys',['../_json_data_interchange_with_printer.html#autotoc_md11',1,'']]],
  ['for_20using_20uniprt_20sdk_1',['Samples For Using UniPRT SDK',['../index.html',1,'']]],
  ['freeprinterlist_2',['FreePrinterList',['../_discovery_8cpp.html#a9124104acb162513fdd1d2ec7ab5b3e9',1,'Discovery.cpp']]],
  ['freeprinterlist_5fipv6_3',['FreePrinterList_IPv6',['../_discovery_8cpp.html#a51bfc8acf835b8fe105a438d66bd52f2',1,'Discovery.cpp']]],
  ['freestring_4',['FreeString',['../_json_s_d_k_8cpp.html#a2103b7d4728d40e2771373cd05f0ebb3',1,'JsonSDK.cpp']]]
];
