var searchData=
[
  ['鍵_0',['鍵',['../_json_data_interchange_with_printer.html#autotoc_md7',1,'支持的 JSON 鍵'],['../_json_data_interchange_with_printer.html#autotoc_md9',1,'範例 1 - 讀取 &quot;Image.Width-in&quot; 鍵'],['../_json_data_interchange_with_printer.html#autotoc_md10',1,'範例 2 - 寫入 &quot;Image.Width-in&quot; 鍵']]]
];
