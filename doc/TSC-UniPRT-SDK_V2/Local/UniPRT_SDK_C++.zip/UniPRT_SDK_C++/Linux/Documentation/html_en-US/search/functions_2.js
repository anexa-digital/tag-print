var searchData=
[
  ['freeprinterlist_0',['FreePrinterList',['../_discovery_8cpp.html#a9124104acb162513fdd1d2ec7ab5b3e9',1,'Discovery.cpp']]],
  ['freeprinterlist_5fipv6_1',['FreePrinterList_IPv6',['../_discovery_8cpp.html#a51bfc8acf835b8fe105a438d66bd52f2',1,'Discovery.cpp']]],
  ['freestring_2',['FreeString',['../_json_s_d_k_8cpp.html#a2103b7d4728d40e2771373cd05f0ebb3',1,'JsonSDK.cpp']]]
];
