var searchData=
[
  ['uint32_0',['UINT32',['../_label_maker_s_d_k_8cpp.html#a69afa2e50b905f4eab1f2df8a3fd9f23',1,'LabelMakerSDK.cpp']]]
];
