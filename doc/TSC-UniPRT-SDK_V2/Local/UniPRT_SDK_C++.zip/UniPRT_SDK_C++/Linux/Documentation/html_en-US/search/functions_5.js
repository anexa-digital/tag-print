var searchData=
[
  ['messengerget_0',['MessengerGet',['../_json_s_d_k_8cpp.html#aa7aa210731cb7890ce2fa7b8fbb3c303',1,'JsonSDK.cpp']]],
  ['messengerreadnextmsg_1',['MessengerReadNextMsg',['../_json_s_d_k_8cpp.html#a639577f9fd23e639174cc97071da113e',1,'JsonSDK.cpp']]],
  ['messengerrelease_2',['MessengerRelease',['../_json_s_d_k_8cpp.html#a4361dd3fbc851a4e8cab635657d108ea',1,'JsonSDK.cpp']]],
  ['messengersendmsg_3',['MessengerSendMsg',['../_json_s_d_k_8cpp.html#ae4653a17ac5f57809adce52ad9213471',1,'JsonSDK.cpp']]],
  ['messengersendmsgandwaitforresponse_4',['MessengerSendMsgAndWaitForResponse',['../_json_s_d_k_8cpp.html#a73b16aa04e4fd26b7fbbd027fdad7ed2',1,'JsonSDK.cpp']]],
  ['messengerunreadmsgcount_5',['MessengerUnreadMsgCount',['../_json_s_d_k_8cpp.html#a65d1fb62727ba2a09959f2061cbd63e7',1,'JsonSDK.cpp']]]
];
