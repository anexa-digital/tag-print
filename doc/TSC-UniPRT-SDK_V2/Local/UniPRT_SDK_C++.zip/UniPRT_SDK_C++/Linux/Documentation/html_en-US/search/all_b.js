var searchData=
[
  ['i_20would_20like_20to_3a_0',['I would like to:',['../index.html#autotoc_md1',1,'']]],
  ['image_20width_20in_20key_1',['Image Width in key',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'Example 1 - Read &quot;Image.Width-in&quot; key'],['../_json_data_interchange_with_printer.html#autotoc_md10',1,'Example 2 - Write &quot;Image.Width-in&quot; key']]],
  ['importing_20sdk_20into_20linux_2',['Importing SDK Into Linux',['../md_md__files_2get_started_import_sdk_to_vs.html',1,'']]],
  ['in_20key_3',['In key',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'Example 1 - Read &quot;Image.Width-in&quot; key'],['../_json_data_interchange_with_printer.html#autotoc_md10',1,'Example 2 - Write &quot;Image.Width-in&quot; key']]],
  ['info_5ftyp_4',['INFO_TYP',['../_json_s_d_k_8cpp.html#aba97ac7f06af4aaccf79c3e9f589bda2',1,'JsonSDK.cpp']]],
  ['interchange_20with_20printer_5',['JSON data-interchange with printer',['../_json_data_interchange_with_printer.html',1,'']]],
  ['into_20linux_6',['Importing SDK Into Linux',['../md_md__files_2get_started_import_sdk_to_vs.html',1,'']]],
  ['items_7',['Settings Key/Value Items',['../ref_json_key_values.html',1,'']]]
];
