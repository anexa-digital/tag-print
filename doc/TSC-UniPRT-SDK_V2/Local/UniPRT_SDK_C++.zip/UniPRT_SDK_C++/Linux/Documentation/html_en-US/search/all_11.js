var searchData=
[
  ['objcellrectptr_0',['ObjCellRectPtr',['../_label_maker_s_d_k_8cpp.html#a965841e5f7e3e36c1694dcd241f59cd4',1,'LabelMakerSDK.cpp']]],
  ['objcellsquareptr_1',['ObjCellSquarePtr',['../_label_maker_s_d_k_8cpp.html#ab325941c74123902246b17ee28be1ac7',1,'LabelMakerSDK.cpp']]],
  ['objectsptr_2',['ObjectsPtr',['../_label_maker_s_d_k_8cpp.html#a33d7b4515497764a0f8903f2a8e9b81a',1,'LabelMakerSDK.cpp']]],
  ['objendptr_3',['ObjEndPtr',['../_label_maker_s_d_k_8cpp.html#a679446483d4c5bdeef52b41d02e93f79',1,'LabelMakerSDK.cpp']]],
  ['objrulerptr_4',['ObjRulerPtr',['../_label_maker_s_d_k_8cpp.html#a96fba514d427b9bf483d3a7c2b315fd6',1,'LabelMakerSDK.cpp']]],
  ['objstartptr_5',['ObjStartPtr',['../_label_maker_s_d_k_8cpp.html#a2bbc4eade6862986ac9f7dc11a012a81',1,'LabelMakerSDK.cpp']]],
  ['objtextitemptr_6',['ObjTextItemPtr',['../_label_maker_s_d_k_8cpp.html#a061a99dad114c3cc300a4da94486c88c',1,'LabelMakerSDK.cpp']]],
  ['odv_5ftyp_7',['ODV_TYP',['../_json_s_d_k_8cpp.html#aba97ac7f06af4aaccf79c3e9f589bda2a467d99c0101bfe32920fe83e5dbb98f4',1,'JsonSDK.cpp']]],
  ['odvmonitorconnection_8',['OdvMonitorConnection',['../_json_s_d_k_8cpp.html#af642594e581a549f40198f663a396575',1,'JsonSDK.cpp']]],
  ['odvmonitordispose_9',['OdvMonitorDispose',['../_json_s_d_k_8cpp.html#a889bb785b69005b75f04dd2897706f90',1,'JsonSDK.cpp']]],
  ['open_10',['Open',['../_comm_s_d_k_8cpp.html#a5e53001785ff30ae485a113b9b8a0ddc',1,'CommSDK.cpp']]]
];
