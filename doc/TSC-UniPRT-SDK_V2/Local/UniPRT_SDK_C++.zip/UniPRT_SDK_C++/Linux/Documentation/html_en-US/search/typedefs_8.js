var searchData=
[
  ['texttype_0',['TextType',['../_label_maker_s_d_k_8cpp.html#adbb8a1068841d8ed8dcc4a16e6f1dce7',1,'LabelMakerSDK.cpp']]]
];
