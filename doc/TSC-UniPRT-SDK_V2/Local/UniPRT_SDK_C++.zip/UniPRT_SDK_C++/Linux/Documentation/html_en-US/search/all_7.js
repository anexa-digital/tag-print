var searchData=
[
  ['data_20interchange_20with_20printer_0',['JSON data-interchange with printer',['../_json_data_interchange_with_printer.html',1,'']]],
  ['data_20port_1',['General JSON Command Syntax - Data Port',['../_json_data_interchange_with_printer.html#autotoc_md5',1,'']]],
  ['datamatrixbarcodetype_2',['DataMatrixBarcodeType',['../_label_maker_s_d_k_8cpp.html#a7829cf77cc4a7980f43306f0e06c28da',1,'LabelMakerSDK.cpp']]],
  ['discovery_2ecpp_3',['Discovery.cpp',['../_discovery_8cpp.html',1,'']]]
];
