var searchData=
[
  ['barcode1dtype_0',['Barcode1DType',['../_label_maker_s_d_k_8cpp.html#a4a0c063c6ccdc1a6215cb884e9050580',1,'LabelMakerSDK.cpp']]],
  ['boxtype_1',['BoxType',['../_label_maker_s_d_k_8cpp.html#ae77f970c821da81abe64509ab75b27bd',1,'LabelMakerSDK.cpp']]]
];
