var _comm_s_d_k_8cpp =
[
    [ "COMM_IDX", "_comm_s_d_k_8cpp.html#a2dabfdd0beaed500a4be03ecd9b55eba", [
      [ "USB_COMM", "_comm_s_d_k_8cpp.html#a2dabfdd0beaed500a4be03ecd9b55ebaa4d026e5d01acb4d1deefb0ab40a3bffc", null ],
      [ "TCP_COMM", "_comm_s_d_k_8cpp.html#a2dabfdd0beaed500a4be03ecd9b55ebaa25d98961276ab44e4dcf7c027a0dda8d", null ],
      [ "BT_COMM", "_comm_s_d_k_8cpp.html#a2dabfdd0beaed500a4be03ecd9b55ebaaeefb26a868c8e64bf19e456fdeb527ce", null ],
      [ "COM_COMM", "_comm_s_d_k_8cpp.html#a2dabfdd0beaed500a4be03ecd9b55ebaa83298c47029f5576c4cf9a8e8571cd6c", null ]
    ] ],
    [ "BtConnect", "_comm_s_d_k_8cpp.html#a665b32a635eb815eeb392f56a01c5706", null ],
    [ "BytesAvailable", "_comm_s_d_k_8cpp.html#aaa6a14415ae7f6a151f0323180ea6cbe", null ],
    [ "Close", "_comm_s_d_k_8cpp.html#a7f7a3199c392465d0767c6506c1af5b4", null ],
    [ "ComConnect", "_comm_s_d_k_8cpp.html#a32d3cad5773854018188dbb3ff69ecb9", null ],
    [ "Connected", "_comm_s_d_k_8cpp.html#afe4e281f67d64c2d1fb66231242db18d", null ],
    [ "GetAvailableDevices", "_comm_s_d_k_8cpp.html#a131eed8b3f31e8010d8493603f218f68", null ],
    [ "GetComm", "_comm_s_d_k_8cpp.html#a0e05d23713c2daf12f5dba666257228f", null ],
    [ "Open", "_comm_s_d_k_8cpp.html#a5e53001785ff30ae485a113b9b8a0ddc", null ],
    [ "Read", "_comm_s_d_k_8cpp.html#a28792b9129f6c4b5ab9b0e1782b7a37c", null ],
    [ "SendPrintFile", "_comm_s_d_k_8cpp.html#ab5ccd9a0b6828f1a7a4b4102fd3a9b3e", null ],
    [ "SendPrintString", "_comm_s_d_k_8cpp.html#a536215772922733d60d81b184191c7d2", null ],
    [ "TcpConnect", "_comm_s_d_k_8cpp.html#a86846879ea6f0624c718767d7061e6aa", null ],
    [ "UsbConnect", "_comm_s_d_k_8cpp.html#ac31155125beb5ee6cc4ceb2e4ecaa698", null ],
    [ "Write", "_comm_s_d_k_8cpp.html#a994c3f8c38ce7eee1438f6d7e7afed2d", null ],
    [ "WriteAndWaitForResponse", "_comm_s_d_k_8cpp.html#a2b4f58945f7e94b4d4619d5632c1da32", null ],
    [ "gBtComm", "_comm_s_d_k_8cpp.html#a320d40f2f2a7cb0ce66ec5eb77fa265c", null ],
    [ "gBtConnection", "_comm_s_d_k_8cpp.html#a7adedc4e9c23f5fc3c5af6e5df27279b", null ],
    [ "gComComm", "_comm_s_d_k_8cpp.html#ab6952932a298da2c9aa6e795d7d64f5e", null ],
    [ "gComConnection", "_comm_s_d_k_8cpp.html#ad7c36829d7116a1b1d30ac23a72154ac", null ],
    [ "giComm", "_comm_s_d_k_8cpp.html#a4b4c96908f80b0f66184fd519ab8cf5c", null ],
    [ "gTcpComm", "_comm_s_d_k_8cpp.html#a4da437250199b3ad66adb1357ff0b433", null ],
    [ "gTcpConnection", "_comm_s_d_k_8cpp.html#af63e552319de1915dd5b3bd8b7d85e94", null ],
    [ "gUsbComm", "_comm_s_d_k_8cpp.html#a008c3315427648be0804091bf6e85150", null ],
    [ "gUsbConnection", "_comm_s_d_k_8cpp.html#a5d9a9e822e3a3db4d1a311b8c63dbcb5", null ]
];