var searchData=
[
  ['tcp_5fcomm_0',['TCP_COMM',['../_comm_s_d_k_8cpp.html#a2dabfdd0beaed500a4be03ecd9b55ebaa25d98961276ab44e4dcf7c027a0dda8d',1,'TCP_COMM:&#160;CommSDK.cpp'],['../_label_maker_s_d_k_8cpp.html#aa550a9606519a25b64fe3dc10b19dbd7a25d98961276ab44e4dcf7c027a0dda8d',1,'TCP_COMM:&#160;LabelMakerSDK.cpp']]]
];
