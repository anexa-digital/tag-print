var searchData=
[
  ['info_5ftyp_0',['INFO_TYP',['../_json_s_d_k_8cpp.html#aba97ac7f06af4aaccf79c3e9f589bda2',1,'JsonSDK.cpp']]]
];
