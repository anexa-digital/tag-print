var _discovery_8cpp =
[
    [ "MAX_THREADS", "_discovery_8cpp.html#a8b5173357adb02a86c027316e0acdfa0", null ],
    [ "FreePrinterList", "_discovery_8cpp.html#a9124104acb162513fdd1d2ec7ab5b3e9", null ],
    [ "FreePrinterList_IPv6", "_discovery_8cpp.html#a51bfc8acf835b8fe105a438d66bd52f2", null ],
    [ "GetPrinterList", "_discovery_8cpp.html#afd1389df5a1c6b2d6f9f53ea6a1cf7cb", null ],
    [ "GetPrinterList_IPv6", "_discovery_8cpp.html#abe73260eb1f0f0e701f578be3f0050a4", null ],
    [ "g_listMutex", "_discovery_8cpp.html#af136dfb042f740440a018d6cd9a7ccad", null ]
];