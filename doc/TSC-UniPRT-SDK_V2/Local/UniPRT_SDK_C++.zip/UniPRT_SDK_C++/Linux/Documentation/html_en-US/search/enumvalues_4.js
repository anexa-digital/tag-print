var searchData=
[
  ['printer_5ftyp_0',['PRINTER_TYP',['../_json_s_d_k_8cpp.html#aba97ac7f06af4aaccf79c3e9f589bda2a54cefc563c8464d28f0bde26e61dcc90',1,'JsonSDK.cpp']]]
];
