var searchData=
[
  ['comm_5fidx_0',['COMM_IDX',['../_comm_s_d_k_8cpp.html#a2dabfdd0beaed500a4be03ecd9b55eba',1,'CommSDK.cpp']]],
  ['comm_5ftyp_1',['COMM_TYP',['../_label_maker_s_d_k_8cpp.html#aa550a9606519a25b64fe3dc10b19dbd7',1,'LabelMakerSDK.cpp']]]
];
