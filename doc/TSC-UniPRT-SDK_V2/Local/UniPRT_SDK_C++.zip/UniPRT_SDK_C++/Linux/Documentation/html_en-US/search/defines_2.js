var searchData=
[
  ['pgl_0',['PGL',['../_label_maker_s_d_k_8cpp.html#a7be63ac308a7f57bcd213eb3050d1a0e',1,'LabelMakerSDK.cpp']]]
];
