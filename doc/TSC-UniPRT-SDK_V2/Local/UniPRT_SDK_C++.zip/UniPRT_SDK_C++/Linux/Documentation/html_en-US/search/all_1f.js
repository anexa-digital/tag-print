var searchData=
[
  ['数据交换_0',['与打印机的 JSON 数据交换',['../_json_data_interchange_with_printer.html',1,'']]],
  ['数据端口的一般_20json_20命令语法_1',['数据端口的一般 JSON 命令语法',['../_json_data_interchange_with_printer.html#autotoc_md5',1,'']]]
];
