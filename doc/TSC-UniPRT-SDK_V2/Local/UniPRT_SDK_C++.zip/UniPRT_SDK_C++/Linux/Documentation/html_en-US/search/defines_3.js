var searchData=
[
  ['tspl_0',['TSPL',['../_label_maker_s_d_k_8cpp.html#a2ea2c38da05e103bde0493304c584f73',1,'LabelMakerSDK.cpp']]]
];
