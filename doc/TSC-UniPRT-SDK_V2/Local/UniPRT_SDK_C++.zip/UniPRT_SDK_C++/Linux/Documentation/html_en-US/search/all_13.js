var searchData=
[
  ['qrbarcodetype_0',['QRBarcodeType',['../_label_maker_s_d_k_8cpp.html#a27da889ae3bc80a53db66004d315fb0a',1,'LabelMakerSDK.cpp']]]
];
