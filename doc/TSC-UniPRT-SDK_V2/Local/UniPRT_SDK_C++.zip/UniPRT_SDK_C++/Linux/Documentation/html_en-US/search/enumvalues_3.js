var searchData=
[
  ['odv_5ftyp_0',['ODV_TYP',['../_json_s_d_k_8cpp.html#aba97ac7f06af4aaccf79c3e9f589bda2a467d99c0101bfe32920fe83e5dbb98f4',1,'JsonSDK.cpp']]]
];
