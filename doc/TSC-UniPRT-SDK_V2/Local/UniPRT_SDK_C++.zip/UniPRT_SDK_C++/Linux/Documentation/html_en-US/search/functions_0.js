var searchData=
[
  ['btconnect_0',['BtConnect',['../_comm_s_d_k_8cpp.html#a665b32a635eb815eeb392f56a01c5706',1,'CommSDK.cpp']]],
  ['bytesavailable_1',['BytesAvailable',['../_comm_s_d_k_8cpp.html#aaa6a14415ae7f6a151f0323180ea6cbe',1,'CommSDK.cpp']]]
];
