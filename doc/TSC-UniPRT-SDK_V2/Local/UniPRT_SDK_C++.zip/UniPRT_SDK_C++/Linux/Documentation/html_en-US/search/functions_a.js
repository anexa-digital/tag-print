var searchData=
[
  ['tcpconnect_0',['TcpConnect',['../_comm_s_d_k_8cpp.html#a86846879ea6f0624c718767d7061e6aa',1,'CommSDK.cpp']]],
  ['tohexstring_1',['ToHexString',['../_label_maker_s_d_k_8cpp.html#a2690b5561d77ac81cabcbf20827e239e',1,'LabelMakerSDK.cpp']]]
];
