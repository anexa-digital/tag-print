var indexSectionsWithContent =
{
  0: "123_abcdefgijklmnopqrstuvw",
  1: "cdgjlr",
  2: "bcfglmoprstuw",
  3: "ago",
  4: "abdlmpqrt",
  5: "ci",
  6: "_bcoprtu",
  7: "mnptu",
  8: "dfijklpsuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Pages"
};

