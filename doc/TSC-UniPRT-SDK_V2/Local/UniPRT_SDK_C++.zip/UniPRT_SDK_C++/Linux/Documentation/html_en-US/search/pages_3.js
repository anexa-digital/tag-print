var searchData=
[
  ['json_20data_20interchange_20with_20printer_0',['JSON data-interchange with printer',['../_json_data_interchange_with_printer.html',1,'']]]
];
