var searchData=
[
  ['labeltype_0',['LabelType',['../_label_maker_s_d_k_8cpp.html#abd4b85163c5acb385353df4849dd2bac',1,'LabelMakerSDK.cpp']]],
  ['linetype_1',['LineType',['../_label_maker_s_d_k_8cpp.html#a14a469eee33e1022ada34ed53899b91d',1,'LabelMakerSDK.cpp']]]
];
