var searchData=
[
  ['datamatrixbarcodetype_0',['DataMatrixBarcodeType',['../_label_maker_s_d_k_8cpp.html#a7829cf77cc4a7980f43306f0e06c28da',1,'LabelMakerSDK.cpp']]]
];
