var indexSectionsWithContent =
{
  0: "123_abcdfgijklmnopqrstuvw加命寫我支數管範與讀資軟載鍵",
  1: "cdgjlr",
  2: "bcfglmoprstuw",
  3: "ago",
  4: "abdlmpqrt",
  5: "ci",
  6: "_bcoprtu",
  7: "mnptu",
  8: "ijklsuv數與軟載"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "檔案",
  2: "函式",
  3: "變數",
  4: "型態定義",
  5: "列舉型態",
  6: "列舉值",
  7: "定義",
  8: "頁面"
};

