var searchData=
[
  ['pdf417barcodetype_0',['Pdf417BarcodeType',['../_label_maker_s_d_k_8cpp.html#a7881b9157f6a715225e578781f72d3c2',1,'LabelMakerSDK.cpp']]],
  ['pgl_1',['PGL',['../_label_maker_s_d_k_8cpp.html#a7be63ac308a7f57bcd213eb3050d1a0e',1,'LabelMakerSDK.cpp']]],
  ['picture_2',['Picture',['../_label_maker_s_d_k_8cpp.html#a3e45c3d30390602e747ad63a0e86d3cb',1,'LabelMakerSDK.cpp']]],
  ['printer_5ftyp_3',['PRINTER_TYP',['../_json_s_d_k_8cpp.html#aba97ac7f06af4aaccf79c3e9f589bda2a54cefc563c8464d28f0bde26e61dcc90',1,'JsonSDK.cpp']]],
  ['printermonitorconnection_4',['PrinterMonitorConnection',['../_json_s_d_k_8cpp.html#a6fd60e21002ff419e0395563862ecb37',1,'JsonSDK.cpp']]],
  ['printermonitordispose_5',['PrinterMonitorDispose',['../_json_s_d_k_8cpp.html#a0b3cf62d0c814822f05c159a5662eaaf',1,'JsonSDK.cpp']]],
  ['project_6',['加入軟體開發套件至 Linux C++ project',['../md_md__files_2get_started_import_sdk_to_vs.html#autotoc_md3',1,'']]]
];
