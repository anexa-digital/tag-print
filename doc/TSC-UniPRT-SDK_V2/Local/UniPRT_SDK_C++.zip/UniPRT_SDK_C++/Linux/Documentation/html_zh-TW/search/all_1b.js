var searchData=
[
  ['寫入_20image_20width_20in_20鍵_0',['範例 2 - 寫入 &quot;Image.Width-in&quot; 鍵',['../_json_data_interchange_with_printer.html#autotoc_md10',1,'']]]
];
