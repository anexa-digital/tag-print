var searchData=
[
  ['json_20數據交換_0',['與印表機的 JSON 數據交換',['../_json_data_interchange_with_printer.html',1,'']]]
];
