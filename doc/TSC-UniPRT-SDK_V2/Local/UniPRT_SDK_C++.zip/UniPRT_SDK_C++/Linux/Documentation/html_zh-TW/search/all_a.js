var searchData=
[
  ['image_20width_20in_20鍵_0',['Image Width in 鍵',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'範例 1 - 讀取 &quot;Image.Width-in&quot; 鍵'],['../_json_data_interchange_with_printer.html#autotoc_md10',1,'範例 2 - 寫入 &quot;Image.Width-in&quot; 鍵']]],
  ['in_20鍵_1',['In 鍵',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'範例 1 - 讀取 &quot;Image.Width-in&quot; 鍵'],['../_json_data_interchange_with_printer.html#autotoc_md10',1,'範例 2 - 寫入 &quot;Image.Width-in&quot; 鍵']]],
  ['info_5ftyp_2',['INFO_TYP',['../_json_s_d_k_8cpp.html#aba97ac7f06af4aaccf79c3e9f589bda2',1,'JsonSDK.cpp']]],
  ['items_3',['Settings Key/Value Items',['../ref_json_key_values.html',1,'']]]
];
