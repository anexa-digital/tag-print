var searchData=
[
  ['width_20in_20鍵_0',['Width in 鍵',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'範例 1 - 讀取 &quot;Image.Width-in&quot; 鍵'],['../_json_data_interchange_with_printer.html#autotoc_md10',1,'範例 2 - 寫入 &quot;Image.Width-in&quot; 鍵']]],
  ['windowsfont_1',['WindowsFont',['../_label_maker_s_d_k_8cpp.html#a4208b0d56990524f1c64756856115e4d',1,'LabelMakerSDK.cpp']]],
  ['write_2',['Write',['../_comm_s_d_k_8cpp.html#a994c3f8c38ce7eee1438f6d7e7afed2d',1,'CommSDK.cpp']]],
  ['writeandwaitforresponse_3',['WriteAndWaitForResponse',['../_comm_s_d_k_8cpp.html#a2b4f58945f7e94b4d4619d5632c1da32',1,'CommSDK.cpp']]]
];
