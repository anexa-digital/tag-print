var searchData=
[
  ['讀取多個鍵的屬性_0',['範例 3 - 讀取多個鍵的屬性',['../_json_data_interchange_with_printer.html#autotoc_md11',1,'']]],
  ['讀取_20image_20width_20in_20鍵_1',['範例 1 - 讀取 &quot;Image.Width-in&quot; 鍵',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'']]]
];
