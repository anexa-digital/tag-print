var searchData=
[
  ['範例_0',['範例',['../_json_data_interchange_with_printer.html#autotoc_md8',1,'']]],
  ['範例_201_20讀取_20image_20width_20in_20鍵_1',['範例 1 - 讀取 &quot;Image.Width-in&quot; 鍵',['../_json_data_interchange_with_printer.html#autotoc_md9',1,'']]],
  ['範例_202_20寫入_20image_20width_20in_20鍵_2',['範例 2 - 寫入 &quot;Image.Width-in&quot; 鍵',['../_json_data_interchange_with_printer.html#autotoc_md10',1,'']]],
  ['範例_203_20讀取多個鍵的屬性_3',['範例 3 - 讀取多個鍵的屬性',['../_json_data_interchange_with_printer.html#autotoc_md11',1,'']]]
];
