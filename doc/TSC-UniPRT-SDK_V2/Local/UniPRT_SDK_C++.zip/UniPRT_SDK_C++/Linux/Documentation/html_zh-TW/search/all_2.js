var searchData=
[
  ['3_20讀取多個鍵的屬性_0',['範例 3 - 讀取多個鍵的屬性',['../_json_data_interchange_with_printer.html#autotoc_md11',1,'']]]
];
