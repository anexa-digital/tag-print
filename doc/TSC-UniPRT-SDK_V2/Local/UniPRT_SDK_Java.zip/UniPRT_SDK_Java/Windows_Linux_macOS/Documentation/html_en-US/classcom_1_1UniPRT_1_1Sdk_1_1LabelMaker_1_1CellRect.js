var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1CellRect =
[
    [ "CellRect", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1CellRect.html#afb8a1fce0dde71d5789762d6494f0478", null ],
    [ "GetRuler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1CellRect.html#a13af26440ce24a5039c0e1dd78ed4ad7", null ],
    [ "GetXdim", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1CellRect.html#a3897a5a3ae4870f38988c750f89d327a", null ],
    [ "GetYdim", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1CellRect.html#a58dd2412d384d5a300a30bb42733a705", null ],
    [ "SetRuler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1CellRect.html#addc95aa7bff5c37454f59920a05b01ee", null ],
    [ "SetXdim", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1CellRect.html#a1f8c8e53fca61bf5fb09396e8d3fdd00", null ],
    [ "SetYdim", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1CellRect.html#a4b288520ccfec0dd2808f98df75e6364", null ]
];