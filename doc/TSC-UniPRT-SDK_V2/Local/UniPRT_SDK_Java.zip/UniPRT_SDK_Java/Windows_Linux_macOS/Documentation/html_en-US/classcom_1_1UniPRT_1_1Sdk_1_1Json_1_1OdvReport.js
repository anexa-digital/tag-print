var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport =
[
    [ "Data", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#ad59cb45b7a83d768aa71fc55fe250906", null ],
    [ "Failed", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#afc4dcbfe53c36b3ee8c29c28edba3e45", null ],
    [ "OverallGrade", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#a63d34647804a6bb1eb1e98c996fbdee1", null ],
    [ "OverallGradeAsFloat", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#abf304274652bc6bf13f09fc2df41496a", null ],
    [ "OverallGradeLetter", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#a4de74f762c454be11aa511365fc17c3a", null ],
    [ "Symbology", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#aa5d9b5875b8f0bb3eb60f0840db16650", null ],
    [ "RawReport", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#a28b03133e2f7bfc1023ed2d82382629d", null ]
];