var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1Translate_1_1ToTspl =
[
    [ "Alignment", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1Translate_1_1ToTspl.html#acdefb3d3a2f394f91558329c227bf9ae", null ],
    [ "BarcodeType1D", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1Translate_1_1ToTspl.html#a23a872f1c7132a6055082150b106782c", null ],
    [ "QRCodeEncoding", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1Translate_1_1ToTspl.html#af456d926470c0b00872726e788e5ebfc", null ],
    [ "QRCodeErrorCorrection", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1Translate_1_1ToTspl.html#a34d699e9c793e08b0fffc9c9b7a7f691", null ],
    [ "QRCodeModel", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1Translate_1_1ToTspl.html#a34027ba485e276dfba5b582b6ad27f28", null ],
    [ "RfidLockType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1Translate_1_1ToTspl.html#ad0f3f13fca2bc04c631606169b9e7d81", null ],
    [ "RfidMemBlock", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1Translate_1_1ToTspl.html#a7f0fd926f13692ee4c19fc61574605f0", null ],
    [ "Rotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1Translate_1_1ToTspl.html#a5dd7629ba7261e9a9374b63c99d614e6", null ]
];