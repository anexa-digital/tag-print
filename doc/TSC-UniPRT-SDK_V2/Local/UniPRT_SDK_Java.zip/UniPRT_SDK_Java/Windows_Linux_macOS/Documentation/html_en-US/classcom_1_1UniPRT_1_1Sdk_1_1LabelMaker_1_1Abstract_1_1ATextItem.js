var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem =
[
    [ "ATextItem", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a94141fd6805560331e490a35f88cdcb0", null ],
    [ "GetData", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#ac23a0ac179a6922db4958f68a5736df0", null ],
    [ "GetFontSize", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#aa2f589014eb340442a759d762ab6a0d7", null ],
    [ "GetStart", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a9a40094c98cfae79510fedd81fb0f898", null ],
    [ "SetData", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#ab4ddc32bd4fb6dd24d1731aab014f192", null ],
    [ "SetFontSize", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a04163416cfcab8ceb20bf47850641351", null ],
    [ "SetStart", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a46555344d7de67008b491120b0cc4157", null ]
];