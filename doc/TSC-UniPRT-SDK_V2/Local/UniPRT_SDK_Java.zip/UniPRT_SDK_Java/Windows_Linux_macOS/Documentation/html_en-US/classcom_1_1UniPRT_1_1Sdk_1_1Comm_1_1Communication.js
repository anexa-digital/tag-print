var classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1Communication =
[
    [ "CreateComm", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1Communication.html#ab914b217a12d5a3e6ff09475eecd911c", null ]
];