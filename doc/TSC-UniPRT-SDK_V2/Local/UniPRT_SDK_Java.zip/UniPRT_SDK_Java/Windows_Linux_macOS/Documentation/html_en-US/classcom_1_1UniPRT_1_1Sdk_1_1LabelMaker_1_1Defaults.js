var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults =
[
    [ "GetAlignment", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#aa0b777c683858f766e4f24b975fcece7", null ],
    [ "GetCellSize", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#a655cb68457c3c2468b93098c0e80be90", null ],
    [ "GetCellSizeRect", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#ab936110d947ce94af4ac50f6c10cf175", null ],
    [ "GetPrinterResolution", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#a75a3db9b7fdf47925128ad44a6d2f0fa", null ],
    [ "GetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#a9d2c6615d7886aab95cac823d1fc8ed9", null ],
    [ "GetRuler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#a9d6da5b20971f1a720a4180a0804f2ef", null ],
    [ "SetAlignment", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#ae75489b32382c64028d748c8803baa5f", null ],
    [ "SetCellSize", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#a5de665a4c17d41bdf91ea90cf88b4a65", null ],
    [ "SetCellSizeRect", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#a6ddff33f5646f393ef44377d47a7ec20", null ],
    [ "SetPrinterResolution", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#adb20a0b55315305f8d6da4050ab4d26d", null ],
    [ "SetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#abbdd6de001913eda6f13a1db65d10982", null ],
    [ "SetRuler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Defaults.html#aad8239d982a1e6fa55ea0f03eb0716e8", null ]
];