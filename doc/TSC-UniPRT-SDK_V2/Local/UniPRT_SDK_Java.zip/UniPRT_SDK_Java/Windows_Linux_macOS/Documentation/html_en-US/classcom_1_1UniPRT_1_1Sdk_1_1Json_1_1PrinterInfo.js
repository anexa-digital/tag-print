var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo =
[
    [ "PrinterInfo", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a14d092421264a31b3fbad73e7fb191c7", null ],
    [ "FirmwarePartNumber", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a3ff3b4f1c2aed096acd0af8b63c2b143", null ],
    [ "FirmwareVersion", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a935d6f16fe302d50a90063855de90b8f", null ],
    [ "GetRawInfo", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a7d4b039559bf5353efb0b8204562b066", null ],
    [ "HasClockOption", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a44b863448378bcce060128b270c2323c", null ],
    [ "HasOdvOption", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a41013a5a4ec8f818ee1de005d67d30a0", null ],
    [ "HasRfidOption", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#afec8abf89288b89b0c8de8f42e4d7bde", null ],
    [ "Model", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a50567c88750944cff656dd9b9305adb6", null ],
    [ "PrintheadResolution", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#aff3415055e86d089d1d05103db355ba2", null ],
    [ "SerialNumber", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a44814a4e1cbaa9e2aa386e20f2817d69", null ],
    [ "SetRawInfo", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a6abd4fc2d8bf6d95700cb195ce1a0862", null ]
];