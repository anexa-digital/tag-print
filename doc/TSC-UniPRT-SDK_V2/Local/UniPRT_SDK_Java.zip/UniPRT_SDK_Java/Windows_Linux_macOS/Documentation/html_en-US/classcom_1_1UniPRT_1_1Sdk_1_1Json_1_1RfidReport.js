var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport =
[
    [ "RfidDataType", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType" ],
    [ "Data", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport.html#ad59cb45b7a83d768aa71fc55fe250906", null ],
    [ "DataType", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport.html#afa95212d28bb9790399c32b2010a8626", null ],
    [ "Failed", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport.html#afc4dcbfe53c36b3ee8c29c28edba3e45", null ],
    [ "IsWriteOperation", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport.html#a9544f368fa7f17cddb0b9a3570df5812", null ],
    [ "RawReport", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport.html#a28b03133e2f7bfc1023ed2d82382629d", null ]
];