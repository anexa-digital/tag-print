var classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple =
[
    [ "Tuple", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#a0bf5f16fc7934db1b761b612d4b4c93d", null ],
    [ "GetX", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#aca889c47495a87e120650781a60868c1", null ],
    [ "GetY", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#ac4143d80624f8f9cff11eb4fe36c39dc", null ],
    [ "SetX", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#a31029bf8c52192cb5de66f3d378bb770", null ],
    [ "SetY", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#ad1fcc299dc1a9531e26b42fe6e9451e2", null ]
];