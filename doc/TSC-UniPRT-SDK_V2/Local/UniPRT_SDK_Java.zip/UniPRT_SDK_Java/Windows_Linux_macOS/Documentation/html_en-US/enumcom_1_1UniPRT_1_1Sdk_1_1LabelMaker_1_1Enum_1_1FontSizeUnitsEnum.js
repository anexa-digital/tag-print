var enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1FontSizeUnitsEnum =
[
    [ "Percent", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1FontSizeUnitsEnum.html#acd8bf55fd5289be0658acf1a74f4e14d", null ],
    [ "Points", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1FontSizeUnitsEnum.html#a50ba2acfd483f395e71abb80f687463e", null ],
    [ "Ruler", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1FontSizeUnitsEnum.html#aefc62ecb26ff865bf822925c9d1104b5", null ]
];