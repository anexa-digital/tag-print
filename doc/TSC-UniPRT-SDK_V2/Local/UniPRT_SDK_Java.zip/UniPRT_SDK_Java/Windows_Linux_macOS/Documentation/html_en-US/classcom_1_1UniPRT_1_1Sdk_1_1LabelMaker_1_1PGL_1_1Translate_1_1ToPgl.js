var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Translate_1_1ToPgl =
[
    [ "Alignment", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Translate_1_1ToPgl.html#a6cbfaf79c4a41aaa350d3d8c8d36a2c2", null ],
    [ "BarcodeType1D", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Translate_1_1ToPgl.html#af3f876eb90759fbbdb3ae4c598a37c55", null ],
    [ "QRCodeEncoding", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Translate_1_1ToPgl.html#af456d926470c0b00872726e788e5ebfc", null ],
    [ "QRCodeErrorCorrection", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Translate_1_1ToPgl.html#a34d699e9c793e08b0fffc9c9b7a7f691", null ],
    [ "QRCodeModel", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Translate_1_1ToPgl.html#a34027ba485e276dfba5b582b6ad27f28", null ],
    [ "RfidLockType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Translate_1_1ToPgl.html#ad0f3f13fca2bc04c631606169b9e7d81", null ],
    [ "RfidMemBlock", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Translate_1_1ToPgl.html#a7f0fd926f13692ee4c19fc61574605f0", null ],
    [ "Rotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Translate_1_1ToPgl.html#ae5c8f50afa070b3155ab89a9aab7df52", null ]
];