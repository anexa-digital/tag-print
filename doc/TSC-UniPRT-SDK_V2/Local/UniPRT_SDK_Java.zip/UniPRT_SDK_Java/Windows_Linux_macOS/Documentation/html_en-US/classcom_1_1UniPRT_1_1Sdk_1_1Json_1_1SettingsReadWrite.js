var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite =
[
    [ "SettingsReadWrite", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#a10bd816e22b23ccb1a3c8ce547e57043", null ],
    [ "SettingsReadWrite", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#a70a89594a672c668ed9cee511a947dfd", null ],
    [ "SettingsReadWrite", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#a1a2e091a0d3ae393f1ef614abf089a52", null ],
    [ "close", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#a5ae591df94fc66ccb85cbb6565368bca", null ],
    [ "Dispose", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#a6e2d745cdb7a7b983f861ed6a9a541a7", null ],
    [ "Dispose", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#a0ce09d478b0dfa794bc77c6a2efdbce9", null ],
    [ "finalize", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#a32d626626eee0bc4ade146973f6abb1c", null ],
    [ "GetAllProperties", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#a924dba20be63e33cb77a5a5700376a4d", null ],
    [ "GetAllValues", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#aef38e3de5b3e3557641a59d71e71ff41", null ],
    [ "GetProperties", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#aa630ad362fa9002dcc2f99465a61ff6e", null ],
    [ "GetProperties", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#aec118c630fc0e09c5b5a0cbec35e4032", null ],
    [ "GetValue", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#aaf0e82ef5a76afbaeb11e5d8c46ed2fd", null ],
    [ "GetValues", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#acaf007443290893c8ccf4018ef094003", null ],
    [ "SetValue", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#aaaef573fa1c58c4761248cad5c126a95", null ],
    [ "SetValues", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1SettingsReadWrite.html#a2715053d1b885239f1bf07e5a8dc2a96", null ]
];