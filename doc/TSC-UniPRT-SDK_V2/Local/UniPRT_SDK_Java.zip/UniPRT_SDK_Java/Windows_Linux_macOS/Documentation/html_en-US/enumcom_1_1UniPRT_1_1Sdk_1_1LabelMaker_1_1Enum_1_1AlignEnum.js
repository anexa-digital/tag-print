var enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AlignEnum =
[
    [ "Center", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AlignEnum.html#a42b56788639363ade366287d21b793bc", null ],
    [ "Default", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AlignEnum.html#a926ecaa791ce6344e2d77a9add176b67", null ],
    [ "Left", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AlignEnum.html#aa149c1d1da2ae1c94f1ae91f4919625a", null ],
    [ "Right", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AlignEnum.html#a338f1941aaeb45ceefaa84416d2aaddb", null ]
];