var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Utilities =
[
    [ "WindowsFont", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Utilities.html#ab30f0a80ff119fcf5b7bb4d9dd8a2e14", null ]
];