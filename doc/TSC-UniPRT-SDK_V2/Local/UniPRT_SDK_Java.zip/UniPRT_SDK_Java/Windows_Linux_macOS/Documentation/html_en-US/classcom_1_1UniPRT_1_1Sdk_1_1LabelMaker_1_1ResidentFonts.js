var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1ResidentFonts =
[
    [ "getNames", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1ResidentFonts.html#a47daf93d6c6ee3b680ef21423b4dd63c", null ]
];