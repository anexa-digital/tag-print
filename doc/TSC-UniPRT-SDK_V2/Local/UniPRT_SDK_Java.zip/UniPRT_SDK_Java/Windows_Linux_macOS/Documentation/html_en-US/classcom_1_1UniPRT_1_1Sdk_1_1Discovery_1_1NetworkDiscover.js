var classcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1NetworkDiscover =
[
    [ "getPrinterList", "classcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1NetworkDiscover.html#a5a40cb7b4772b5771fc1146e44fdcae1", null ]
];