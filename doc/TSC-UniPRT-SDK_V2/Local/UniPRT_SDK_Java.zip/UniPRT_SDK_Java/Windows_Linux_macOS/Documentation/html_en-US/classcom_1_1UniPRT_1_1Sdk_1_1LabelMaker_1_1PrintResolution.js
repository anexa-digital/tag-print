var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution =
[
    [ "PrintResolution", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#aff3ec77d0ed2bb84b5adb27ca72125fa", null ],
    [ "GetDotsPerInch", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#a1ace0d30e4aa78ac414052eac941c978", null ],
    [ "GetDotsPerMM", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#a9411f88e76707988676f6982e2f3be3c", null ],
    [ "SetDotsPerInch", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#a4fdd450086ada812d21e61c83e5ea710", null ],
    [ "SetDotsPerMM", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#aea1d6c27281f96cafdd37078effb6676", null ]
];