var enumcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryPacket_1_1Brand =
[
    [ "ALL", "enumcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryPacket_1_1Brand.html#aaff03f45544854747fa5e7821e84252e", null ],
    [ "PTX", "enumcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryPacket_1_1Brand.html#add07b6fc403702e492ea7f6f72c4c92e", null ],
    [ "TSC", "enumcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryPacket_1_1Brand.html#a07005dcee4d54436fa4dba88de0bc09e", null ]
];