var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties =
[
    [ "Barcode_2D_Properties", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#af8ef12f48cf9a5450df3d2a6864ae1ba", null ],
    [ "GetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#af64ba9f1c70a74071fc7fea7ef09b532", null ],
    [ "getType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#ac33ea758a3c11de6deca8c12774cab07", null ],
    [ "SetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#adb5ee8cdc454ee1f6e8bf88adb0bc544", null ],
    [ "SetType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#a1efb3ece2ee3921adb6ffafcdab6929d", null ]
];