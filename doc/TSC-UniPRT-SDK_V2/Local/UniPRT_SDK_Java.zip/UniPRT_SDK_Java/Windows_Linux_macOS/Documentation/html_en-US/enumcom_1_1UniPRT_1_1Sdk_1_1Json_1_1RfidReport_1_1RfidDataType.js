var enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType =
[
    [ "ACS", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html#a7fad6f505fbf43589e01c1ebb176b5f1", null ],
    [ "EPC", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html#aaacc66fb76e49602d39a360ed87a0d22", null ],
    [ "TID", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html#a0403b681016bb5362f29ae30e0d588b7", null ],
    [ "UNKNOWN", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html#ab6aedfcb4a10d1a01e272f492e2c2765", null ],
    [ "USR", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html#a9d8b9eb071422093cefe10c949119b75", null ]
];