var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController =
[
    [ "ConnectionCount", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#ae28becbfbd057a652d4c40d1529388c6", null ],
    [ "CreateMgmtComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#a9a73f3410877a415a01538d32c1afb42", null ],
    [ "CreateMgmtComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#afe51416ecc7385d8fe261120597ac061", null ],
    [ "Descriptors", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#aeae50764be068b50b95a74fcb98078fa", null ],
    [ "Instance", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#a28bded26c56136d3f5cb218ba1e316d2", null ],
    [ "ReleaseMgmtComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#aa3c300ef522a7455be8f18d6d76f4e11", null ],
    [ "UserCount", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#a2cf22f44128372a4e62b096ae56570a9", null ]
];