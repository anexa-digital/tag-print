var classcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryNetwork =
[
    [ "DiscoveryNetwork", "classcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryNetwork.html#a9e6f826bd5ee1d7581110c80b9f938d5", null ],
    [ "findPrinters", "classcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryNetwork.html#ac47f19d225d0e7272d8b24aaa1502c0f", null ],
    [ "getIpList", "classcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryNetwork.html#a31d36c33eb4745a080d43b45a3dbd6ce", null ],
    [ "isComplete", "classcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryNetwork.html#a32dfbb978ecf364d3cf95f1ce30d74bd", null ],
    [ "setTimeoutMs", "classcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryNetwork.html#aa3ecfbb58d24f8141c4be1dbe2d45911", null ]
];