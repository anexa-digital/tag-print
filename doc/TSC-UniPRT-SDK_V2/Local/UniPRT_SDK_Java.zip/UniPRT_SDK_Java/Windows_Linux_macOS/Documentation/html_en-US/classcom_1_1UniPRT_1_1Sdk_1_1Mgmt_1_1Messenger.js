var classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger =
[
    [ "Messenger", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#ad3203488f34d50522a896f2ddac503ab", null ],
    [ "close", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a5ae591df94fc66ccb85cbb6565368bca", null ],
    [ "GetID", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a04cbe3f0b5057d0eb582200dea602297", null ],
    [ "ReadNextMsg", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#ad7ecacb2250c399636f4573194a930d4", null ],
    [ "SendMsg", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a5a330da2db6f11241b89fbbe1e7f72ca", null ],
    [ "SendMsg", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a8e2bb4490243781ff5190ce59ba8f272", null ],
    [ "SendMsgAndWaitForResponse", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a350c505b5486545a18b9427b75751b59", null ],
    [ "SendMsgAndWaitForResponse", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#aec66d2c6a44766e7f551f9708b4bc3d6", null ],
    [ "SendMsgRaw", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#aad4d17fb0aac0607723845c6de60624b", null ],
    [ "UnreadMsgCount", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#ad5de79bcd407d715bad48d14954f3b5c", null ]
];