var classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Utilities =
[
    [ "SendPrintFile", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Utilities.html#aeb6d703f70e88a46565a8ff8be17acbb", null ],
    [ "SendPrintString", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Utilities.html#ac3ba2ca7573ca7c1c5c6a77ad9d75924", null ]
];