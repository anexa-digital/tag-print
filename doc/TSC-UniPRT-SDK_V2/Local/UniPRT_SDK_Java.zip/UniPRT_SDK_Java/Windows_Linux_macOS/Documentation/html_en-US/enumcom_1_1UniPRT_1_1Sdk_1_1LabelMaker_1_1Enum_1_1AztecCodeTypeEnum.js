var enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum =
[
    [ "Compact", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum.html#a05fcd2b155fc59ccff525767d2beb53f", null ],
    [ "Default", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum.html#a926ecaa791ce6344e2d77a9add176b67", null ],
    [ "FixedErrCorrection", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum.html#a08ffc9a1e2e157f2fee30289237b1cd2", null ],
    [ "Full", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum.html#a8358969dab0ab050f0cde1bd2391f4f0", null ],
    [ "Rune", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum.html#abfb529fbc84e14001fdb939255ccebd0", null ]
];