var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties =
[
    [ "Barcode_2D_Properties", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#af8ef12f48cf9a5450df3d2a6864ae1ba", null ],
    [ "GetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#ab675e91c7785e7694b2f7b5d22729b77", null ],
    [ "getType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#a04b39db039fba6242e7a22aafad80dfb", null ],
    [ "SetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#ab22a071d38442f0d7c523d0755dc715b", null ],
    [ "SetType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#a866e6e89392a38ad85624984831c4f54", null ]
];