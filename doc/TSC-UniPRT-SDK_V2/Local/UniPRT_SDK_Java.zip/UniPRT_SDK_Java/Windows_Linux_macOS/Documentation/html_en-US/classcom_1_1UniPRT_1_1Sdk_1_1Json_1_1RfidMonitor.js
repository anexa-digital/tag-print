var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor =
[
    [ "RfidMonitor", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#a3ef279aa17ba7537ab2b47ea27a4e711", null ],
    [ "RfidMonitor", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#a9519682b89459e7cac5df33d3e479f95", null ],
    [ "RfidMonitor", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#a39e3afa1d6ecf1fb4774d09c2adb3ed8", null ],
    [ "close", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#a5ae591df94fc66ccb85cbb6565368bca", null ],
    [ "Dispose", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#a6e2d745cdb7a7b983f861ed6a9a541a7", null ],
    [ "Dispose", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#a0ce09d478b0dfa794bc77c6a2efdbce9", null ],
    [ "finalize", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#a32d626626eee0bc4ade146973f6abb1c", null ],
    [ "GetRfidReportCallback", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#aa1c6e72c91f8ad7ae9d3bb844cba2c86", null ],
    [ "GetRfidReportListening", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#abfe9ad20b672227eb3d491ba2057515b", null ],
    [ "SetRfidReportCallback", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#abfbfd4b53dad50244fc95a50886d88a2", null ],
    [ "SetRfidReportListening", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidMonitor.html#a11a9947e9589a7e2cfe2a852225a2b82", null ]
];