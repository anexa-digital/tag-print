var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem =
[
    [ "TextItem", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem.html#a3f65f243565289e9f5dd3d0910336782", null ],
    [ "TextItem", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem.html#ac6b534b63f7399bb6a65a2118149a919", null ],
    [ "GetData", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem.html#ac23a0ac179a6922db4958f68a5736df0", null ],
    [ "GetFontSize", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem.html#aa2f589014eb340442a759d762ab6a0d7", null ],
    [ "GetStart", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem.html#a9a40094c98cfae79510fedd81fb0f898", null ],
    [ "SetData", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem.html#ab4ddc32bd4fb6dd24d1731aab014f192", null ],
    [ "SetFontSize", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem.html#a04163416cfcab8ceb20bf47850641351", null ],
    [ "SetStart", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem.html#a46555344d7de67008b491120b0cc4157", null ]
];