var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Font =
[
    [ "Font", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Font.html#a7fb4ba0abb874db57efa797b9b977968", null ],
    [ "Font", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Font.html#a8b109d0dfcaf6d37e5082e8551ade576", null ],
    [ "GetName", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Font.html#ac299469a5542b6a91f0e70b28e0d1345", null ],
    [ "IsBold", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Font.html#aa4ac149dc7b53d92255118117e7b6e83", null ],
    [ "IsItalic", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Font.html#a1550d7ff2d44a337d113f600f09d1c99", null ],
    [ "SetBold", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Font.html#a21458b34ff9ed3aaab3cf5bf7006eb1d", null ],
    [ "SetItalic", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Font.html#a5821fbe76115536937a57f42c16e4587", null ],
    [ "SetName", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Font.html#a21b76e72cceabe28ad677d0ea9107e93", null ],
    [ "toString", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Font.html#ad146fa8579a5f8a876c4688cc5a68520", null ]
];