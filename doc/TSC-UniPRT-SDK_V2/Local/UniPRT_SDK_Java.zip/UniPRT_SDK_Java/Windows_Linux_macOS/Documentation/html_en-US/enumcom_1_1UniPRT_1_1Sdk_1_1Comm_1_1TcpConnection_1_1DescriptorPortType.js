var enumcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection_1_1DescriptorPortType =
[
    [ "DATA", "enumcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection_1_1DescriptorPortType.html#a4a0722b7d54cd140c9546aa2626a7a3a", null ],
    [ "MGMT", "enumcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection_1_1DescriptorPortType.html#ac12b4d3b3ee29a00a8a1ce731f8f0ee1", null ],
    [ "STATUS", "enumcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection_1_1DescriptorPortType.html#a32c27cc471df37f4fc818d65de0a56c4", null ]
];