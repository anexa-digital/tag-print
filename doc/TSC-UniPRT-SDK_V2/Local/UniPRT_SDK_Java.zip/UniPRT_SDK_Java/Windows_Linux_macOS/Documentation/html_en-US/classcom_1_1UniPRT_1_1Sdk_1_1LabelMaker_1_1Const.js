var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Const =
[
    [ "DEFAULT_DPI", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Const.html#abc1a717c47762bd3333072d05556897c", null ],
    [ "MM_PER_INCH", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Const.html#a129f1a22fdbb83d750c5c0a2ddbf1817", null ],
    [ "POINTS_PER_INCH", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Const.html#aad64fb897e120864fc160a8c0af25743", null ]
];