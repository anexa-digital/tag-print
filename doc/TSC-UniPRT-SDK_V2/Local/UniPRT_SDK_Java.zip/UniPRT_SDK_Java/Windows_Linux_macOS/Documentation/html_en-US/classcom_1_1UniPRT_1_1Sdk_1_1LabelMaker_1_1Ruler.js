var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Ruler =
[
    [ "Ruler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Ruler.html#a39fde940448e3f20086b5728ca1b4d0c", null ],
    [ "GetScale", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Ruler.html#af04d40c70d345570da0ebe9f0ebc7eef", null ],
    [ "SetScale", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Ruler.html#a1fdc7f889a5de293eb30685158eb8d69", null ]
];