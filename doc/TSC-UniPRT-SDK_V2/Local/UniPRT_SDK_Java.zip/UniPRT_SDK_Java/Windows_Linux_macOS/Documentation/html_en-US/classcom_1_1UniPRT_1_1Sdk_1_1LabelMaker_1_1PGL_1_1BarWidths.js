var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths =
[
    [ "BarWidths", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#ab6fb7f861428d2ec65aedd3fc58cf76d", null ],
    [ "BarWidths", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#aa9c18ca17b2a28bdc7119391a82b3308", null ],
    [ "BcdMagnification1D", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#a65674ad673996f94cafc36645f40e3b8", null ],
    [ "GetNarrowBar", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#a8f3068a8d00bd5672096372e6c3cdc76", null ],
    [ "GetRuler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#a13af26440ce24a5039c0e1dd78ed4ad7", null ],
    [ "GetWideBar", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#a8313d023f31880e73c3f0b206858c959", null ],
    [ "SetNarrowBar", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#a328b4687788b7d092f9b241e28d53cde", null ],
    [ "SetRuler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#addc95aa7bff5c37454f59920a05b01ee", null ],
    [ "SetWideBar", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#a7d7ea79f7c38e2360fef4e47dfd54906", null ]
];