var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ACellSquare =
[
    [ "ACellSquare", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ACellSquare.html#af7c250cc4744bef55d2dcb3b7415c5b7", null ],
    [ "GetRuler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ACellSquare.html#afa04ca8cac2e5fcd74fe082b2153bb72", null ],
    [ "GetXdim", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ACellSquare.html#a799a0098ae40763826c45b0ace66854e", null ],
    [ "SetRuler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ACellSquare.html#ab7e4e035aad54b26350c33ae225b9767", null ],
    [ "SetXdim", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ACellSquare.html#a0257bfa15203c9f62e1e4468b895e5f1", null ],
    [ "ruler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ACellSquare.html#a1b4debdd88722dc18b9a869a525136f4", null ],
    [ "xdim", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ACellSquare.html#a916aa81ebdaa2f550aaf11793c56f8a5", null ]
];