var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths =
[
    [ "BarWidths", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#a2068d97fa9520efb9d0109a82775023e", null ],
    [ "BarWidths", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#a85e90452f804c4466d8554f447c51aad", null ],
    [ "BcdMagnification1D", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1BarWidths.html#a1f0a1d90e90eedaa28fbc2bbbd9c8a76", null ]
];