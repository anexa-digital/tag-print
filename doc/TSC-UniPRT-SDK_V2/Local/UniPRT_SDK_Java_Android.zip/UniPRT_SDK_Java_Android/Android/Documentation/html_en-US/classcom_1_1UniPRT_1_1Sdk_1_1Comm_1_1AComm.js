var classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1AComm =
[
    [ "Read", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1AComm.html#a1faad2fe6fba6fc25c716c0c0047bf3a", null ],
    [ "WaitForData", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1AComm.html#a91b43ca08cf89c525b0b8d4ee9f2ca53", null ],
    [ "Write", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1AComm.html#a36db855b35d6dd29d44a2b1273d6996e", null ],
    [ "WriteAndWaitForResponse", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1AComm.html#a59f55f556251fe071b84fa8962a97291", null ],
    [ "WriteAndWaitForResponse", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1AComm.html#ac76f50b3cfe86452463f8401fcad253b", null ],
    [ "MAX_PACKET_SIZE", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1AComm.html#a6ed45e0083d72d85bf2347520d4d9529", null ]
];