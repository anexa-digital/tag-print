var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font =
[
    [ "Font", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#accb4d440c51c88eaa0c95379d68945dd", null ],
    [ "Font", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#af5b88108f743707224d13bbfe558a565", null ],
    [ "GetName", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#a9b7bc4441032618efc7419c104f3d3d7", null ],
    [ "IsBold", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#ab2e76c223665f5536aba437c6607f47e", null ],
    [ "IsItalic", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#aa99a85e7e4c3f990200b0cc6a1805bb8", null ],
    [ "SetBold", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#aeb5d7e90ac42406008b053a241aeaa50", null ],
    [ "SetItalic", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#ac6b8bc67cd382c831b656a098e561308", null ],
    [ "SetName", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#a9f07ddbd7cdd8b8ac11b5be20e6b02e6", null ],
    [ "toString", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#aee0f129c67e049c0a71532d650d8d654", null ],
    [ "bold", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#aaef9ccde5a11e61fee981948be036820", null ],
    [ "cmd", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#a2358e4ebeea67cdaf963cf597322e30a", null ],
    [ "italic", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#a1b1399e955592d9bff7c831092457d5d", null ],
    [ "name", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Font.html#a5bbba11f25c12624b8e590e61000ac7b", null ]
];