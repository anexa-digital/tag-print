var classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection =
[
    [ "DescriptorPortType", "enumcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection_1_1DescriptorPortType.html", "enumcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection_1_1DescriptorPortType" ],
    [ "TcpConnection", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#af9f9f5536a90fee047146c7c8d1b85b7", null ],
    [ "TcpConnection", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a6b117b594b28952d12ecc10c9431e384", null ],
    [ "BytesAvailable", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#ad85e9085fc850519b0c3153aeabd338a", null ],
    [ "Close", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a27efd409340c7713713ece4ea7b5c17f", null ],
    [ "Connected", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a224cb02f94e3eef6807c541dc3bea1c9", null ],
    [ "ConnectionSettings", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a88008802ac3632fbd38755349f4868d7", null ],
    [ "Descriptor", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#abf84d5d33236843b2e47b0144b3843fe", null ],
    [ "GetPort", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#aa84449286557c87d6cf3132d5fa901b1", null ],
    [ "IpAddress", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a15a83750ae3f6868f20e38a05759ec27", null ],
    [ "Open", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a92ee24366f973e86c4c4af6196b277eb", null ],
    [ "Port", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a30b34b10644d93799d74f92ea735b5e4", null ],
    [ "Read", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a31224f55bac11270cf50a50a465402e5", null ],
    [ "Write", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a4d209643ff54e17b7e8d7dfbf97738a2", null ],
    [ "_client", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a7fa4a7b47d406d9844649b0932767508", null ],
    [ "_inStream", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#aebcbc3de43c19beb4c44635053a8f139", null ],
    [ "_ipAddress", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#a346d68202217315df542db92612e1d97", null ],
    [ "_outStream", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#aa298489d588a31497866cdd972207e15", null ],
    [ "_port", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection.html#aa9ea49305203dbc11261f355f7374d42", null ]
];