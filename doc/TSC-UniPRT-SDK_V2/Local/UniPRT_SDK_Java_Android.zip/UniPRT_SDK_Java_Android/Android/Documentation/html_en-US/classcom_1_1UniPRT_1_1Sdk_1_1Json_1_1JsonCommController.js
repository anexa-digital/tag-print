var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController =
[
    [ "JsonConnection", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection" ],
    [ "JsonCommController", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#a7626991975402e711e3f568be047fbd4", null ],
    [ "ConnectionCount", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#a4d566d707fe4b7f151170445649e7704", null ],
    [ "CreateMgmtComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#a41e55bd5a2f67315bdedc94259577988", null ],
    [ "CreateMgmtComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#a2f533a164cbd7efe704bb7a21154dcbe", null ],
    [ "Descriptors", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#a8a588e227b0124c5cf56feb2bfd02c7b", null ],
    [ "ReleaseMgmtComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#a5dbc8d928ebc5d510b607a612fcce29e", null ],
    [ "UserCount", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController.html#ad9f70af422933c977a751c0dd24600fd", null ]
];