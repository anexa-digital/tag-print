var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm =
[
    [ "JsonComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a778d3a8dc1f64c1953e54e7dd49573a9", null ],
    [ "ChannelListenerJson", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#aa88acec161749f83a912a87cac07681c", null ],
    [ "ChannelListenerMgmtMsg", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#aeb6100c87dea7b504e79d4f63797dc2b", null ],
    [ "close", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a572aead3351c79f9f1c5032e8fb93721", null ],
    [ "Dispose", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#ab02fcefe910f867efd960f539e50ed22", null ],
    [ "Dispose", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a6da78a3152b0f1b9422053756c3f0b79", null ],
    [ "finalize", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a95e92181ace02f7dcd30c502151ccf5c", null ],
    [ "GetMsgFrame", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#aed5cc901d8911dd247dc5dce0c1a2bc1", null ],
    [ "MsgFrameSplitterAsync", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a19dc4c46585d1c557eb0bfdadf895ee6", null ],
    [ "Send", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a5c86fa3896452f1f4dd14f30abdb012c", null ],
    [ "SendAndWaitForMsgFrame", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#acc41aaba4c44df35d3b91a760d698e8a", null ],
    [ "SendAndWaitForResponse", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a4d6fb6949ee7fbc6c175abaf9d1ede36", null ],
    [ "Start", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a9306e18ccbf85011ccee378bde7838f3", null ],
    [ "_disposed", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a21f8254d57004eb132c02f1c25f9ba04", null ],
    [ "_executor", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a7ab955ead4e2772a12e51ee0394d23c1", null ],
    [ "_jsonComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a356fe1e363b78a21432977445132ca47", null ],
    [ "_jsonReceived", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a179411195fbc3bf51fe2c08752fd83d0", null ],
    [ "_listenersJsonChnls", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a4f1d9567e006d474db106a057974be8f", null ],
    [ "_listenersMgmtMsgChnls", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a607d5443b50c04ccd6c2b78d7cfc0d1f", null ],
    [ "_msgOut", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a1ea677255e3d9ad6052ad514a5b28677", null ],
    [ "_usingDataPort", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonComm.html#a6229bf33bda8facc0687da1d380edfcc", null ]
];