var classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection =
[
    [ "BTClassicConnection", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#a07f2ae8941ae6fb92a6daaefd5ec1c57", null ],
    [ "BTClassicConnection", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#a24ec243f3feb244eb842fd5ccda1128e", null ],
    [ "BytesAvailable", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#a20c811fe5355d3ccc928cf56fae119ef", null ],
    [ "Close", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#af32965e06009ecf907367a99aa0a33dd", null ],
    [ "Connected", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#aa990ee185351c21386343384a1a8a0b8", null ],
    [ "Descriptor", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#ad001fda5a78888b6012692a9fa860bca", null ],
    [ "Open", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#aeb5620e47ea42ed5a131ff083c781178", null ],
    [ "Read", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#ac22b43955993e73644c2041b913b577b", null ],
    [ "Write", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#a55910c37e03c054fedf4f04293f4cd32", null ],
    [ "_bt_address", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#abefab88a80cfc4963bfebcb988784b6f", null ],
    [ "btSocket", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#a38312f14ac0fe2b5b4ce1846b69fb467", null ],
    [ "InStream", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#a184cda2e8b6496ba1e1b84017793be88", null ],
    [ "mBluetoothAdapter", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#aa68fde15f0907d4669dd6bdad629a0de", null ],
    [ "OutStream", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1BTClassicConnection.html#a17daa3b0ccb1c43ba6a10217a025c866", null ]
];