var enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum =
[
    [ "Pdf417ErrCorrectionEnum", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#a1de5d64ee6fd544353e5e604f9df0911", null ],
    [ "GetValue", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#adc00bb749331093bae570ca0502dcd59", null ],
    [ "LEVEL_0", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#aecc9a6990883a2fdc32b7099d1b005c8", null ],
    [ "LEVEL_1", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#afc157a97e59cdcd758ee4bb89a1ddb1f", null ],
    [ "LEVEL_2", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#a4cf03e9af8ffc5d9e1a2a596c03d0fec", null ],
    [ "LEVEL_3", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#af4a69075c064a7813b52ff46648f297e", null ],
    [ "LEVEL_4", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#a24f13bb29cef702038b3f113f4912183", null ],
    [ "LEVEL_5", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#a7324fc6e33db4af47b481d4aac6f4eb7", null ],
    [ "LEVEL_6", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#a92d0d16bac204e166f108d61329df131", null ],
    [ "LEVEL_7", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#a51bd47fe0f9713f67d2efcef36a6681c", null ],
    [ "LEVEL_8", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#a7a66b92154901cdb3f16899e5e809a18", null ],
    [ "value", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1Pdf417ErrCorrectionEnum.html#a4808982805b9591fbd10e2f58ba4a3f5", null ]
];