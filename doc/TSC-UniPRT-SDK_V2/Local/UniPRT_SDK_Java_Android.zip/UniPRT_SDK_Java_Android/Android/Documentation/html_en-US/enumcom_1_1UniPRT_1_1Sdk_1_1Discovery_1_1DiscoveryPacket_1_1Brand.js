var enumcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryPacket_1_1Brand =
[
    [ "ALL", "enumcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryPacket_1_1Brand.html#a729122a640ccc85808a79b86839bfca6", null ],
    [ "PTX", "enumcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryPacket_1_1Brand.html#a1ee05ed37384c1823750a79906425c75", null ],
    [ "TSC", "enumcom_1_1UniPRT_1_1Sdk_1_1Discovery_1_1DiscoveryPacket_1_1Brand.html#a004f48c66e3214bcccb0ce990c00b360", null ]
];