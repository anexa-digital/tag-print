var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem =
[
    [ "TextItem", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem.html#ad9ac32826551cb95712a264781763399", null ],
    [ "TextItem", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TextItem.html#a1bac3e9c99bd7e8a5e32ceea9f79f7fd", null ]
];