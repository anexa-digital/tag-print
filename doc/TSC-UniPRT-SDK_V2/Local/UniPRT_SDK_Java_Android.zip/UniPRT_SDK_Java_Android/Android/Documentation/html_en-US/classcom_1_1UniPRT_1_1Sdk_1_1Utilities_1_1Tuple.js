var classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple =
[
    [ "Tuple", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#a242bbcf89f85e3bbadb3e27d3952a6bc", null ],
    [ "GetX", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#ac48b5df2dbe76ded3fa400546d33fb8f", null ],
    [ "GetY", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#a414423032a28962c9c2d247b00e09565", null ],
    [ "SetX", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#add1e4ee872e5fa55027f7d075450768e", null ],
    [ "SetY", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#a3862b2a7f9f13abdb9953a38b3e19239", null ],
    [ "x", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#a35d0d013546e2df54eabba4f53a055db", null ],
    [ "y", "classcom_1_1UniPRT_1_1Sdk_1_1Utilities_1_1Tuple.html#ac4527eb5d4afe7c9f292ccd7e2d2bfd7", null ]
];