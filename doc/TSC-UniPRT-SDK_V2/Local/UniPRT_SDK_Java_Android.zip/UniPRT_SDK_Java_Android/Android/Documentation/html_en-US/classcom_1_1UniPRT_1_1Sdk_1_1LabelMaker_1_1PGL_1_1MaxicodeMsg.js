var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1MaxicodeMsg =
[
    [ "MaxicodeMsg", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1MaxicodeMsg.html#a9fe7961ed37143d2bdda729df0cd4b99", null ],
    [ "MaxicodeMsg", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1MaxicodeMsg.html#ab6f2ffb680a10926c95eb02a2a06c07d", null ]
];