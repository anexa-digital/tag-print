var enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AlignEnum =
[
    [ "Center", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AlignEnum.html#a7e77309ff09c5cd8dd1433557c0dc12e", null ],
    [ "Default", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AlignEnum.html#a030dc29598a02a5e0097f3eea42a8253", null ],
    [ "Left", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AlignEnum.html#a35bc12908f948497dd4b28bf730688e4", null ],
    [ "Right", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AlignEnum.html#a5747b5efb45456056d7f536143b7adfe", null ]
];