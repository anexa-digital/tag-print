var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties =
[
    [ "Barcode_2D_Properties", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#a285b298ff15abbab67334816be6829d7", null ],
    [ "GetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#acd135f72e728a997a4fbb286b39d6649", null ],
    [ "getType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#abf637ca5f4cb65f515e28e3ca7f3d6a1", null ],
    [ "SetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#ad83000679e73434988aff310150b29c3", null ],
    [ "SetType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#a06aca70ac6a3c2ba13f9a2dc059f9619", null ],
    [ "rotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#a9d68df1d5726043b8103626151d9e982", null ],
    [ "type", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PglLib_1_1Barcode__2D__Properties.html#a7f0159bc2970084427389b268d64b15d", null ]
];