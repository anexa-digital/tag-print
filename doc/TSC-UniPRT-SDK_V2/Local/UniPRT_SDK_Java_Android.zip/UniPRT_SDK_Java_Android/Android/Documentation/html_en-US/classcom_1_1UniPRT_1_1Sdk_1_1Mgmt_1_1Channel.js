var classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel =
[
    [ "Channel", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#a341cd48e096ee9052abd75d48c7e8c9a", null ],
    [ "Channel", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#a3472672ab8124525df6578a26d7343ea", null ],
    [ "Disconnect", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#a21175227651b8addd64393d64e242dc4", null ],
    [ "Offer", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#a3e1d2a87bf9ff8b620d7fff70d2ef1f1", null ],
    [ "Poll", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#a9f65d71756b1886d6c992fe1a1c70099", null ],
    [ "Read", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#af016275dd42f4a8f4aaa6d8fbd47e6bf", null ],
    [ "Size", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#ae9c197f679740be8309e37e31408cfe3", null ],
    [ "Take", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#a27c2acbf25dd41ca6f4423df82998446", null ],
    [ "TryRead", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#a68ca7aee1587be8455669c398d25c40c", null ],
    [ "TryWrite", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#a291311216cf4b7f7faacaee4635e095e", null ],
    [ "Write", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#ad3be533120c39e9cdbbd818614851b50", null ],
    [ "queue", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Channel.html#aab7aec58b5007b976a659b96647e045b", null ]
];