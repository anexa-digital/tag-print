var enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1QRCodeErrorCorrectionEnum =
[
    [ "EC_15", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1QRCodeErrorCorrectionEnum.html#a33fee9c8eda51459e82fd9bf2745af7e", null ],
    [ "EC_25", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1QRCodeErrorCorrectionEnum.html#ad366010ff98fe0a3dda94a3c0a0fa2eb", null ],
    [ "EC_30", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1QRCodeErrorCorrectionEnum.html#ad049856ac74d4cf7d945c561dd446607", null ],
    [ "EC_7", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1QRCodeErrorCorrectionEnum.html#aedf89f803195439cd0b526ad98a350b0", null ]
];