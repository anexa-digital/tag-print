var enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1FontSizeUnitsEnum =
[
    [ "Percent", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1FontSizeUnitsEnum.html#a05e1d45a283037f4e28f862b3c416739", null ],
    [ "Points", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1FontSizeUnitsEnum.html#afdf7768769df37b174541baf948d6196", null ],
    [ "Ruler", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1FontSizeUnitsEnum.html#a655c443fab2182f3a21324a239f64d6f", null ]
];