var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1MaxicodeMsgStructured =
[
    [ "MaxicodeMsgStructured", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1MaxicodeMsgStructured.html#a9cdd78cdaa45e7cf29c65939e4086837", null ],
    [ "MaxicodeMsgStructured", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1MaxicodeMsgStructured.html#a83243b47d6ee70237c6235bb068d7435", null ],
    [ "GetData", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1MaxicodeMsgStructured.html#acfa8087b16e7febc9f75fee699fa2eaa", null ]
];