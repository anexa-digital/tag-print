var enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType =
[
    [ "ACS", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html#a216a9e134bcc4ebffa0d39bc43a7b8aa", null ],
    [ "EPC", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html#af7d18ec88a85291ea1aefd3f35e64cff", null ],
    [ "TID", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html#aae5f7e44f018b8eeb35dda3155569e6e", null ],
    [ "UNKNOWN", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html#a73998568585f847a9c4bd4b75df32261", null ],
    [ "USR", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html#ab7b790ac39431779b10ab859d0b95645", null ]
];