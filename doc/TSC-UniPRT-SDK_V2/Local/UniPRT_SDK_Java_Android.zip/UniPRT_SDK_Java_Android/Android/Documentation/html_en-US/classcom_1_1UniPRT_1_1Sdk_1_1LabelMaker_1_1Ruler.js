var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Ruler =
[
    [ "Ruler", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Ruler.html#a74e5157601f286ef85dc141684250a7e", null ],
    [ "GetScale", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Ruler.html#acc0d6e1eee7f04ea63b9cb081788afe3", null ],
    [ "SetScale", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Ruler.html#a726406830b0ef0357d6569457e830408", null ],
    [ "scale", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Ruler.html#a3994147970ff9c48974b9e4cd7f841eb", null ]
];