var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties =
[
    [ "Barcode_1D_Properties", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#a2db536297d6919aa6e293c9cf6479630", null ],
    [ "GetHeight", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#a3aab0e8e2475ce7eac2c4b627af45cb7", null ],
    [ "GetMagnification", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#aedeb0185c926e982a74710f1cf85c353", null ],
    [ "GetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#a024e2042f0e64a7a0f376840c269cfa7", null ],
    [ "getType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#abf9ef82f1ebc7d672c3f941109688bd4", null ],
    [ "IsPrintHumanReadable", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#aa5254666d382f6e988f396f6a02f8151", null ],
    [ "IsPrintHumanReadableOnTop", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#adb8ebfa67d37f01e8942cecdfa1c8c70", null ],
    [ "SetHeight", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#aebe86576c039bdbf3cf032fcbe9b46ab", null ],
    [ "SetMagnification", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#a7594132d13fb18a4dd74699ca29f5b10", null ],
    [ "SetPrintHumanReadable", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#ae87ba381969df2fff2f1101deb3b4e41", null ],
    [ "SetPrintHumanReadableOnTop", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#ab9a7ec08979d575a9e5f6fae3e860462", null ],
    [ "SetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#a4f5195ed80ce1cc411486f2a7350aeb7", null ],
    [ "SetType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#a2d37c93072df427765c039800271aa38", null ],
    [ "height", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#a1884dad17232d3923f9fd4dc1cb02ae5", null ],
    [ "magnification", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#a7a0d243ac73906230c2c268d6a60b249", null ],
    [ "printHumanReadable", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#aba6999da35fb63427c3c5fc55dedf3c8", null ],
    [ "printHumanReadableOnTop", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#ab4a56e6491bc192dd69a1412d088b45a", null ],
    [ "rotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#ab20ba5806e5b12a2542354721c2692bc", null ],
    [ "type", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__1D__Properties.html#af90e859e0d5a8c9c981a39b477fd6c2a", null ]
];