var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1BarWidths =
[
    [ "BarWidths", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1BarWidths.html#a53539659d3f72c74604e99adff8dcb04", null ],
    [ "BarWidths", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1BarWidths.html#abe24175ae5c3b665a2a74ceb24338516", null ],
    [ "BcdMagnification1D", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TSPL_1_1BarWidths.html#a8cc8ac0a2abbc68eaedb24ee7b780e30", null ]
];