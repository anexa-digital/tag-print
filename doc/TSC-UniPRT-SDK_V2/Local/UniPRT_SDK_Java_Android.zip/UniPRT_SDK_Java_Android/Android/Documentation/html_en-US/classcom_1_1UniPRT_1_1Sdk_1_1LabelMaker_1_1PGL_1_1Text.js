var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Text =
[
    [ "Text", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Text.html#a8eca383ce975866e277b48e3367e7aa1", null ],
    [ "Text", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Text.html#a02df979d9be52cc2f8419879ff0ce079", null ],
    [ "GetFontSizePgl", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Text.html#a387883840bbd96d70c7aee44332d1999", null ],
    [ "ToString", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Text.html#ae910eed16b598079dfb83e120b85b427", null ],
    [ "toString", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PGL_1_1Text.html#a39f130c86121899364860166ca3d41cc", null ]
];