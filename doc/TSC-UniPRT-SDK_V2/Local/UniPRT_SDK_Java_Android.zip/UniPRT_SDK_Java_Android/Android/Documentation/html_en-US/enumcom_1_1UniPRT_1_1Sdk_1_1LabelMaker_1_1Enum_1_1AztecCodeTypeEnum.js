var enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum =
[
    [ "Compact", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum.html#a779f9467b307283aef42673b9a2731d0", null ],
    [ "Default", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum.html#ae5db2cff7b29a906478a30024bf60aa2", null ],
    [ "FixedErrCorrection", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum.html#ac5de6a94120851ea114db18e658bf9f3", null ],
    [ "Full", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum.html#a8d2065d619878f4a532495336fa2ce74", null ],
    [ "Rune", "enumcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Enum_1_1AztecCodeTypeEnum.html#a11f783bf849fad1d68c48d270601333e", null ]
];