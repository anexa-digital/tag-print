var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport =
[
    [ "Data", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#a9f659a791bf47b7aec0f528e44e29628", null ],
    [ "Failed", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#acd11366b81baf83d5461afa821aae6ea", null ],
    [ "OverallGrade", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#acfed59512e9ba46954fe750c1f75ec4c", null ],
    [ "OverallGradeAsFloat", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#a1f9e660b97cef7b466fafa801fe0ffef", null ],
    [ "OverallGradeLetter", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#a0e8a668fd35004570e5f5f843588d2d1", null ],
    [ "Symbology", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#a53a5cbffe3f3aac79dc9e0351346cef8", null ],
    [ "RawReport", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1OdvReport.html#ad8cb635c014b6b58e92805021dea097f", null ]
];