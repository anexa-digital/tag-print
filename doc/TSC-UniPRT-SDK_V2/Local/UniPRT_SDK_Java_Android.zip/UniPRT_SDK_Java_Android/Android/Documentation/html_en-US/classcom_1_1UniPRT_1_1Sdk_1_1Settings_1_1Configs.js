var classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs =
[
    [ "Configs", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#ae01b1f12a3da0f641bf3ee50242c71fe", null ],
    [ "Configs", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#a72f4d1eb64dd45fd7cd61a0ae4765532", null ],
    [ "Configs", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#a9e66af32ac9f3c7aec5bc1e80f2dda60", null ],
    [ "close", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#a9c1c1b5b8c47eb4568350e3b001cd1dd", null ],
    [ "Dispose", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#a6d60c63b5a979060e8306203115ebf8e", null ],
    [ "Dispose", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#a4e8794faf58a9961335c0b180b808c78", null ],
    [ "finalize", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#a79d92f2ea1f4dde14e9a93b3a60ec562", null ],
    [ "GetAllConfig", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#a2489cc65e8614c1d2eaa2c2a0331a33c", null ],
    [ "GetConfig", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#aa0caa6a5a839da46cabd8a2e1dc07b4c", null ],
    [ "SetConfig", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#abc285e6d69800c5b6e426b7a984941ca", null ],
    [ "_disposed", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#a01dacebb319b3e99b17e1f2b64878d10", null ],
    [ "_managedDescriptor", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#abc30302a13cbef87e54e2c3568208cd3", null ],
    [ "_MgmtComm", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#a93d51931552d32d96da01470ce9b0a4e", null ],
    [ "_PtrComm", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#ab6ef4873e00f8be412c9b184451b19d7", null ],
    [ "_sdkManagedComm", "classcom_1_1UniPRT_1_1Sdk_1_1Settings_1_1Configs.html#ad98449d3123ace7fb09ce774c729e6ee", null ]
];