var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection =
[
    [ "JsonConnection", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#a05c6c91692a2cb3cc84aa82eaf3838ad", null ],
    [ "JsonConnection", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#a0e88aea15ea8c00b6bf612d601b4dc13", null ],
    [ "AddUser", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#ad6513510de3ee617e5ff6279c59d5039", null ],
    [ "close", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#ad0ad0da4fbd10f4221eac82f4c46e924", null ],
    [ "Descriptor", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#aa38d1820ad0c79a9866d9b1e3bb06abf", null ],
    [ "Dispose", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#aff4693d59502d820081e81faaf572930", null ],
    [ "Dispose", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#aa59d34ff91b3b528b1096bdf676df4e7", null ],
    [ "finalize", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#a650db87e2df1a99a5759d3cd3031570b", null ],
    [ "JsonComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#aa071eebab78d22229146a9e55164b428", null ],
    [ "PtrComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#a0ed0efd46f77aedbe6b984ea3dcd4fbd", null ],
    [ "RemoveUser", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#aef657d174dcf80b2b156582d29fb4a7f", null ],
    [ "UserCount", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#a18637503f69b5970c7136ce8d3d61237", null ],
    [ "descriptor", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#a32af8adfc4ab28631a5333b3780554d9", null ],
    [ "disposed", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#aa94f4c12cbf2788f3680845ea924bdfe", null ],
    [ "jsonComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#a91250de63d4d3f758980d9737a6f992c", null ],
    [ "jsonCommCreatedHere", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#a7eba6544b2b690d75fa41546cd7619e4", null ],
    [ "ptrComm", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#aa358887230e772ce42b751acca42649d", null ],
    [ "ptrCommCreatedHere", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#a5c6e8143651c8b0fe5e2e6f98c88dcdd", null ],
    [ "userCount", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1JsonCommController_1_1JsonConnection.html#a7d9b1800e353474a7180133fdccdc4f4", null ]
];