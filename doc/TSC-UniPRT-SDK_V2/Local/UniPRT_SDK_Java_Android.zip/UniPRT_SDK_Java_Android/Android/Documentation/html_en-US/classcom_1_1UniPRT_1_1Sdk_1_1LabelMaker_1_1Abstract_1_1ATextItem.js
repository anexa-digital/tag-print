var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem =
[
    [ "ATextItem", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a68f7d010cbaece2f500ed1a30c33183f", null ],
    [ "GetData", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a17013674d0b55031a405b497d41c3bc7", null ],
    [ "GetFontSize", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a77e54725cdc8a506d8c2ddc52c2558a4", null ],
    [ "GetStart", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#aa1c84bf28beeada5594926487b8b2a62", null ],
    [ "SetData", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a53070a258f42d91363b9bd57297a1203", null ],
    [ "SetFontSize", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a9cdc2ae6a737631b58c6ffd58c48d453", null ],
    [ "SetStart", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a9add35cd896586cb50d913973cb53854", null ],
    [ "data", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#abe271c550f5868a6147fcb5abdea1a5e", null ],
    [ "fontSize", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a4071427213a8753cd6cb2de2018a0584", null ],
    [ "start", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1ATextItem.html#a208a41d09c968dc9d703c3b38913506d", null ]
];