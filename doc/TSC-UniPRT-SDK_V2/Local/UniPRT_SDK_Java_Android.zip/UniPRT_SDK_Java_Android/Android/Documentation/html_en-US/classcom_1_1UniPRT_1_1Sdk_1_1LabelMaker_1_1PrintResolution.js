var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution =
[
    [ "PrintResolution", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#a7c90bbb2a7fb011191da75a4d6e025ad", null ],
    [ "GetDotsPerInch", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#a6061108ba6572167ac1f75d77c2ad7b8", null ],
    [ "GetDotsPerMM", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#aa76fa3e14f1045d3bf08ff7a1c511502", null ],
    [ "SetDotsPerInch", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#ad1f8ce623abb84e3eaafc05a13a3a71f", null ],
    [ "SetDotsPerMM", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#a551b4be978def7ae244a62711c9132c4", null ],
    [ "dotsPerInch", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#ae57d1aea8c1149c9169542af06d2e56a", null ],
    [ "dotsPerMM", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1PrintResolution.html#aa357bfc820b8b7a92c7b96ccbc425484", null ]
];