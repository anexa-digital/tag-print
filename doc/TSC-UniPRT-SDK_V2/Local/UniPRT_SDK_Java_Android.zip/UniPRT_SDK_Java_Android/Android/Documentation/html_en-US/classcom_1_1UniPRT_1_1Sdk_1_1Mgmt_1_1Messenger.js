var classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger =
[
    [ "Messenger", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a82cac99818c02e9c44525a1ecd43ad1e", null ],
    [ "close", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#abade2c88a302724c8c5d9eba34284d25", null ],
    [ "GetID", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a74ed9a507ffa85cc6e22bc40c523c8f2", null ],
    [ "NextMsgId", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a1718590a6cfb2ec4634d1905f6662cb8", null ],
    [ "ReadNextMsg", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#af3024defe8adc7a6454c2934e5d222a2", null ],
    [ "SendMsg", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#af190ffefb6f512174b33e152cd960f19", null ],
    [ "SendMsg", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a335d2c06db2871b9a486c223dba53d0d", null ],
    [ "SendMsgAndWaitForResponse", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a487da14cbf8ad987765ac79a7a8f062d", null ],
    [ "SendMsgAndWaitForResponse", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#acd85a29dbfdfa67370a3c1b9613953e6", null ],
    [ "SendMsgRaw", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#adc18f97bac8095598f34cab7c0810fa7", null ],
    [ "UnreadMsgCount", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a0b8664024ff61959e7961b3607f38cf7", null ],
    [ "_mgmtComm", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#ae7efef6998c781d2ae0041a9cf1d406f", null ],
    [ "_msgsFromPtr", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a0f540704a04a67840eabdbdcc2a44c9e", null ],
    [ "_myMgmtId", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a4d14c5c10c5c26e2ebc8f25c7174f4b4", null ],
    [ "_trackCount", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#af8cc6c88cbe416ada653a0c7581bc093", null ],
    [ "usingDataPort", "classcom_1_1UniPRT_1_1Sdk_1_1Mgmt_1_1Messenger.html#a9302e9ff441b6ec3ef990f50b152888b", null ]
];