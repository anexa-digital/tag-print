var enumcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection_1_1DescriptorPortType =
[
    [ "DATA", "enumcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection_1_1DescriptorPortType.html#a6152449d04d3a354ca50eee617ad232a", null ],
    [ "MGMT", "enumcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection_1_1DescriptorPortType.html#a25d38af75439a329cffd0c63c6cc18c2", null ],
    [ "STATUS", "enumcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1TcpConnection_1_1DescriptorPortType.html#a128bf21f1998730fd88a2ef1c6ef628c", null ]
];