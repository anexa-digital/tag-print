var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo =
[
    [ "PrinterInfo", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#afdf7c7c5d848a941139ca7d9bd85bca6", null ],
    [ "FirmwarePartNumber", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#ab92e81654115c18bcb83c36c074e613b", null ],
    [ "FirmwareVersion", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a32ad5a7dc8099b3c25e5ba4e61cae70f", null ],
    [ "GetRawInfo", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a12a8f078984149335f37103f17a0fe64", null ],
    [ "HasClockOption", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a249e5def2c8eede1c80a12516aa0f555", null ],
    [ "HasOdvOption", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a2bc1952183f3d4288e4f0ed8e00b2d2a", null ],
    [ "HasRfidOption", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a31e47a396107acaae7d4fd29924a15d8", null ],
    [ "Model", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#aa17a0f7b4658773efd80583da6674e25", null ],
    [ "PrintheadResolution", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a9eaa73b7d48b9021be01f430da036aa9", null ],
    [ "SerialNumber", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#abf3d0446df7db552811653f14139db63", null ],
    [ "SetRawInfo", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a0c16e6270757043a0f8a7f05542851e5", null ],
    [ "_rawInfo", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1PrinterInfo.html#a7c47ee956f09fb33ca1f25c5ba1b53a0", null ]
];