var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Tuple =
[
    [ "Tuple", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Tuple.html#a71f03c5bf747c48aef07343c3178abbe", null ],
    [ "GetX", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Tuple.html#a1311c59ce3873b38385f0f934e6cc560", null ],
    [ "GetY", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Tuple.html#a6d557e08cfb40970b68c9d8349151c22", null ],
    [ "SetX", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Tuple.html#a35b7beeeeb163f4983171a906c47b06e", null ],
    [ "SetY", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Tuple.html#aa768676ac903f8bfe1308f3c3d2a2dcf", null ],
    [ "x", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Tuple.html#ac5f0d563b744c811c5a6297ae9dbb127", null ],
    [ "y", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Tuple.html#a9178b33fd7862cec2fdbbf041bdeda7c", null ]
];