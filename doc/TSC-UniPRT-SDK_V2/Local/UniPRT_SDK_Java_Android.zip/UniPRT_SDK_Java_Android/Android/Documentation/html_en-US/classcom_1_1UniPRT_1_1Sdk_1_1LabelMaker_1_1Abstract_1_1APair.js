var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1APair =
[
    [ "APair", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1APair.html#a18d854d820190cfb838da6f1cd736376", null ],
    [ "GetX", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1APair.html#a5350038591b9adcebbf3c94e337df2bc", null ],
    [ "GetY", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1APair.html#ab62d31f831bacc999de3ff98a4cbff05", null ],
    [ "SetX", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1APair.html#ad0f074525d1338a0899f1d1228dfac54", null ],
    [ "SetY", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1APair.html#adb8ce770d0d2ee2888c31d4ac5bd4ef0", null ],
    [ "x", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1APair.html#afce9581a133985999a1afad02dd5bdcf", null ],
    [ "y", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1Abstract_1_1APair.html#a57fcb0340ae9807eda8882e93bd45322", null ]
];