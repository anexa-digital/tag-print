var classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler =
[
    [ "UsbHandler", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#ae9995b4cd16e8bd91d3b32ffa6356b00", null ],
    [ "close", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#a5dbf7ea81c60525feca098052b48055d", null ],
    [ "getUsbConnection", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#aa06d87e5e00d9cfb78e1829b609cb2a7", null ],
    [ "getUsbEndpointIn", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#aafff26c3d58792a90930ec159ee93ed2", null ],
    [ "getUsbEndpointOut", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#ab24b40a30fe1beba1a9bcd719c5fb1ed", null ],
    [ "setupDevice", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#af5491eb4dc9dcdfc0c6f27f259e6e171", null ],
    [ "usbConnection", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#a6a122d6c7a4eb0f66bcdf9bddd535687", null ],
    [ "usbDevice", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#aaf7720304c4e75ceddfbf55f2379e53f", null ],
    [ "usbEndpointIn", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#a47e0d657df8b996f9017289115c04b84", null ],
    [ "usbEndpointOut", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#ad697a7f496a0c17e61c24c619d9cea77", null ],
    [ "usbInterface", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#a90e4fc2c68108f43e68ac7555c020a29", null ],
    [ "usbManager", "classcom_1_1UniPRT_1_1Sdk_1_1Comm_1_1UsbHandler.html#ad27437178913544efe9f12cc5d5908d2", null ]
];