var classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport =
[
    [ "RfidDataType", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType.html", "enumcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport_1_1RfidDataType" ],
    [ "Data", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport.html#a900f06306d934d92ed48c2373c207b42", null ],
    [ "DataType", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport.html#a3a8499f88f82f3a11d708754fd179d01", null ],
    [ "Failed", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport.html#a59c7fd36c91e27f2d072459e82339fd7", null ],
    [ "IsWriteOperation", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport.html#a2d337b0ceb440bf2e6584c9e4ea82e03", null ],
    [ "RawReport", "classcom_1_1UniPRT_1_1Sdk_1_1Json_1_1RfidReport.html#a2a4a795b5a43befc0d5e3595de3c3d42", null ]
];