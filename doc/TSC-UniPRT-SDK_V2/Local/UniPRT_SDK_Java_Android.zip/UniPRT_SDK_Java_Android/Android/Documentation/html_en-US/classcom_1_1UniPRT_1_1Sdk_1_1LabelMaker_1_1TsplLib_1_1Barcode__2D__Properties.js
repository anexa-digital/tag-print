var classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties =
[
    [ "Barcode_2D_Properties", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#ad7b850cbb021e1bd325815f65b2a75e2", null ],
    [ "GetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#afa4e1ed1dd2ec24c05f78629d55f5efc", null ],
    [ "getType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#a9d3cc6bf4927c4e55df0f34f8189d90a", null ],
    [ "SetRotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#abe82b7d343445a6821fae4e569eeb07e", null ],
    [ "SetType", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#a9ef9b148594f718c17b379cb0b3ea3ef", null ],
    [ "rotation", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#a7de784872b598fc3bdb77fff7bfeb119", null ],
    [ "type", "classcom_1_1UniPRT_1_1Sdk_1_1LabelMaker_1_1TsplLib_1_1Barcode__2D__Properties.html#afc92db3425edc49d2df3a338b9ab61d4", null ]
];