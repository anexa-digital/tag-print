var indexSectionsWithContent =
{
  0: "_cdmorstuvw中在字快技文概歡範結",
  1: "dm",
  2: "_cmorw",
  3: "su"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "類別",
  2: "函式",
  3: "頁面"
};

