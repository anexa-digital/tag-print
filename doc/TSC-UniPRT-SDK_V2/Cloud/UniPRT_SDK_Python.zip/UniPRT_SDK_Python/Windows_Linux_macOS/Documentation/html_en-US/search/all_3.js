var searchData=
[
  ['example_0',['Example',['../index.html#autotoc_md6',1,'']]]
];
