var searchData=
[
  ['getting_20started_0',['Getting Started',['../index.html#autotoc_md1',1,'']]]
];
