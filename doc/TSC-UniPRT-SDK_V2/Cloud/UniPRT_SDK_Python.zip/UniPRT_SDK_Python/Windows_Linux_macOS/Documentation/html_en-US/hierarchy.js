var hierarchy =
[
    [ "Enum", null, [
      [ "UniPRT_Cloud.Comm.MqttComm.DataTransferType", "class_uni_p_r_t___cloud_1_1_comm_1_1_mqtt_comm_1_1_data_transfer_type.html", null ],
      [ "UniPRT_Cloud.Comm.MqttComm.DescriptorPortType", "class_uni_p_r_t___cloud_1_1_comm_1_1_mqtt_comm_1_1_descriptor_port_type.html", null ]
    ] ],
    [ "UniPRT_Cloud.Comm.MqttComm.MqttComm", "class_uni_p_r_t___cloud_1_1_comm_1_1_mqtt_comm_1_1_mqtt_comm.html", null ],
    [ "str", null, [
      [ "UniPRT_Cloud.Comm.MqttComm.DataTransferType", "class_uni_p_r_t___cloud_1_1_comm_1_1_mqtt_comm_1_1_data_transfer_type.html", null ]
    ] ]
];