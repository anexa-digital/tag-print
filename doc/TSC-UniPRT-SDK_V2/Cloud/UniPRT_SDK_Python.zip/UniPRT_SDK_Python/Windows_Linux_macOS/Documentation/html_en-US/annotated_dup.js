var annotated_dup =
[
    [ "UniPRT_Cloud", null, [
      [ "Comm", null, [
        [ "MqttComm", null, [
          [ "DataTransferType", "class_uni_p_r_t___cloud_1_1_comm_1_1_mqtt_comm_1_1_data_transfer_type.html", null ],
          [ "DescriptorPortType", "class_uni_p_r_t___cloud_1_1_comm_1_1_mqtt_comm_1_1_descriptor_port_type.html", null ],
          [ "MqttComm", "class_uni_p_r_t___cloud_1_1_comm_1_1_mqtt_comm_1_1_mqtt_comm.html", "class_uni_p_r_t___cloud_1_1_comm_1_1_mqtt_comm_1_1_mqtt_comm" ]
        ] ]
      ] ]
    ] ]
];