import aiomqtt
import json
import asyncio
import ssl
from typing import Optional, Callable, Awaitable, Union
from enum import Enum
import math
import random
import base64


MAX_CHUNK_SIZE = 16 * 1024  # 16K bytes

PCL_LANGUAGES = {
    "DPL", "EPL", "IER", "IPL", "MGL", "PGL", "SBPL", "TEC", "TSPL", "ZPL"
}
class DescriptorPortType(Enum):
    ENCRYPTED = 1
    UNENCRYPTED = 2

class DataTransferType(str, Enum):
    TEXT = "Text"
    BASE64 = "Base64"
    HEX = "Hex"


"""!
@cond
"""
class MqttCommInternal:
    def __init__(
        self,
        broker: str,
        port: int = 8883,
        username: Optional[str] = None,
        password: Optional[str] = None,
        ca_cert: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
        keyfile_password: Optional[str] = None,
    ) -> None:
        self._broker = broker
        self._port = port
        self._username = username
        self._password = password
        self._ca_cert = ca_cert
        self._certfile = certfile
        self._keyfile = keyfile
        self._keyfile_password = keyfile_password

        self._client: Optional[aiomqtt.Client] = None
        self._context = None  
        self._connected = False
        self._event = asyncio.Event()

    async def connect(self) -> None:
        """Async connect to MQTT broker."""
        if self._client is None:  
            self._client = aiomqtt.Client(
                hostname=self._broker,
                port=self._port,
                username=self._username,
                password=self._password,
                tls_params=aiomqtt.TLSParameters(
                    ca_certs=self._ca_cert,
                    certfile=self._certfile,
                    keyfile=self._keyfile,
                    keyfile_password=self._keyfile_password,
                    tls_version=ssl.PROTOCOL_TLSv1_2,
                    cert_reqs=ssl.CERT_OPTIONAL,
                ) if self._ca_cert else None,
            )

        self._context = self._client.__aenter__()  
        await self._context  
        self._connected = True
        print("Connected to MQTT broker.")

    async def disconnect(self) -> None:
        """Async disconnect from MQTT broker."""
        if self._client and self._context:
            await self._client.__aexit__(None, None, None)  
            self._client = None
            self._context = None
            self._connected = False
            print("Disconnected from MQTT broker.")

    async def publish(self, topic: str, payload: str) -> None:
        """Async publish message."""
        if self._client is None:
            raise RuntimeError("MQTT client 未初始化，請先執行 connect()")

        await self._client.publish(topic, payload.encode("utf-8"), qos=2)

    async def subscribe(self, topic: str, callback: Callable[[str, str], Awaitable[None]]) -> None:
        """Async subscribe to a topic, only allowing async callbacks."""
        if self._client is None:
            raise RuntimeError("MQTT client 未初始化，請先執行 connect()")
        
        await self._client.subscribe(topic, qos=2)

        async for message in self._client.messages:  
            if message.topic == topic or topic == "#":  
                payload = message.payload
                if isinstance(payload, bytes):
                    payload = payload.decode("utf-8")
                elif not isinstance(payload, str):
                    payload = str(payload)

                await callback(str(message.topic), payload)  

    async def wait_for_data(self, topic: str, timeout: int) -> Optional[str]:
        """Async wait for a response on a topic."""
        if self._client is None:
            raise RuntimeError("MQTT client is not initialize, please run the connect() function first.")

        try:
            async for message in self._client.messages:
                if message.topic == topic:
                    payload = message.payload
                    if isinstance(payload, bytes):
                        payload = payload.decode("utf-8")
                    elif not isinstance(payload, str):
                        payload = str(payload)
                    return payload
        except asyncio.TimeoutError:
            print("Timed out waiting for data.")
            return None
"""!
@endcond
"""

class MqttComm:
    """!
    @~English
    @brief Async MQTT Communication Wrapper.
    Provides open/close, publish/subscribe, and helper builders for TSC commands.

    @~Chinese
    @brief 非同步 MQTT 通訊包裝器。
    提供開啟/關閉、發佈/訂閱，以及建立 TSC 指令的輔助方法。

    @~Chinese-Traditional
    @brief 非同步 MQTT 通訊包裝器。
    提供開啟/關閉、發佈/訂閱，以及建立 TSC 指令的輔助方法。
    """

    def __init__(
        self,
        broker: str,
        port: int = 8883,
        username: Optional[str] = None,
        password: Optional[str] = None,
        ca_cert: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
        keyfile_password: Optional[str] = None,
    ) -> None:
        """!
        @~English
        @brief Initialize the MQTT communication client wrapper.
        @param broker The MQTT broker address.
        @param port Broker port (default 8883).
        @param username Optional username.
        @param password Optional password.
        @param ca_cert Optional CA certificate path.
        @param certfile Optional client cert path.
        @param keyfile Optional client key path.
        @param keyfile_password Optional client key password.
        @return None.

        @~Chinese
        @brief 初始化 MQTT 通訊用封裝。
        @param broker MQTT broker 位址。
        @param port Broker 連接埠（預設 8883）。
        @param username 選用：使用者名稱。
        @param password 選用：密碼。
        @param ca_cert 選用：CA 憑證路徑。
        @param certfile 選用：用戶端憑證路徑。
        @param keyfile 選用：用戶端私鑰路徑。
        @param keyfile_password 選用：用戶端私鑰密碼。
        @return None。

        @~Chinese-Traditional
        @brief 初始化 MQTT 通訊用封裝。
        @param broker MQTT broker 位址。
        @param port Broker 連接埠（預設 8883）。
        @param username 選用：使用者名稱。
        @param password 選用：密碼。
        @param ca_cert 選用：CA 憑證路徑。
        @param certfile 選用：用戶端憑證路徑。
        @param keyfile 選用：用戶端私鑰路徑。
        @param keyfile_password 選用：用戶端私鑰密碼。
        @return None。
        """
        self._mqtt_comm = MqttCommInternal(
            broker,
            port,
            username,
            password,
            ca_cert,
            certfile,
            keyfile,
            keyfile_password,
        )

    async def open(self) -> None:
        """!
        @~English
        @brief Open the connection to the MQTT broker.
        @return None.

        @~Chinese
        @brief 開啟與 MQTT broker 的連線。
        @return None。

        @~Chinese-Traditional
        @brief 開啟與 MQTT broker 的連線。
        @return None。
        """
        await self._mqtt_comm.connect()

    async def close(self) -> None:
        """!
        @~English
        @brief Close the connection to the MQTT broker.
        @return None.

        @~Chinese
        @brief 關閉與 MQTT broker 的連線。
        @return None。

        @~Chinese-Traditional
        @brief 關閉與 MQTT broker 的連線。
        @return None。
        """
        await self._mqtt_comm.disconnect()

    async def write(self, topic: str, payload: str) -> None:
        """!
        @~English
        @brief Publish a message to a topic.
        @param topic The MQTT topic to publish to.
        @param payload The message payload to send (UTF-8).
        @return None.

        @~Chinese
        @brief 發佈訊息至主題。
        @param topic 要發佈的 MQTT 主題。
        @param payload 要傳送的訊息內容（UTF-8）。
        @return None。

        @~Chinese-Traditional
        @brief 發佈訊息至主題。
        @param topic 要發佈的 MQTT 主題。
        @param payload 要傳送的訊息內容（UTF-8）。
        @return None。
        """
        await self._mqtt_comm.publish(topic, payload)

    async def read(self, topic: str, callback: Callable[[str, str], Awaitable[None]]) -> None:
        """!
        @~English
        @brief Subscribe to a topic and start an async listener task.
        @param topic The topic to subscribe to.
        @param callback Async callback handling (topic, payload).
        @return None.

        @~Chinese
        @brief 訂閱主題並啟動非同步監聽工作。
        @param topic 要訂閱的主題。
        @param callback 非同步 callback，參數為 (topic, payload)。
        @return None。

        @~Chinese-Traditional
        @brief 訂閱主題並啟動非同步監聽工作。
        @param topic 要訂閱的主題。
        @param callback 非同步 callback，參數為 (topic, payload)。
        @return None。
        """
        async def listener():
            await self._mqtt_comm.subscribe(topic, callback)
        asyncio.create_task(listener())

    """!
    @cond
    """
    async def wait_for_data(self, topic: str, timeout: int) -> Optional[str]:
        return await self._mqtt_comm.wait_for_data(topic, timeout)

    @staticmethod
    def split_text_lines(lines: list[str]) -> list[list[str]]:
        chunks = []
        current = []
        current_len = 0
        for line in lines:
            line_len = len(line.encode("utf-8")) + 2  # CRLF
            if current_len + line_len > MAX_CHUNK_SIZE:
                chunks.append(current)
                current = []
                current_len = 0
            current.append(line)
            current_len += line_len
        if current:
            chunks.append(current)
        return chunks
    """!
    @endcond
    """

    @staticmethod
    def make_tsc_data_transfer_bulk(
        data,
        data_type: Union[DataTransferType, str],
        from_id="SDK",
        to_id="printer",
        transaction_id_start=None
    ) -> list[str]:
        """!
        @~English
        @brief Build a list of TSCDataTransfer JSON commands for bulk data.
        @param data The input data: list[str] for Text; Base64/Hex string for others.
        @param data_type Data type: Text, Base64, or Hex.
        @param from_id Sender identifier (default "SDK").
        @param to_id Target identifier (default "printer").
        @param transaction_id_start Starting TransactionId; random if None.
        @return List of JSON strings (each a TSCDataTransfer command).
        @throws ValueError On invalid input types/encodings.

        @~Chinese
        @brief 建立用於大量資料的 TSCDataTransfer JSON 指令清單。
        @param data 輸入資料：Text 時為 list[str]；其餘為 Base64/Hex 字串。
        @param data_type 資料型別：Text、Base64 或 Hex。
        @param from_id 送出端識別（預設 "SDK"）。
        @param to_id 目標端識別（預設 "printer"）。
        @param transaction_id_start 起始 TransactionId；None 時隨機。
        @return JSON 字串清單（每筆為一個 TSCDataTransfer 指令）。
        @throws ValueError 當輸入型別或編碼無效時。

        @~Chinese-Traditional
        @brief 建立用於大量資料的 TSCDataTransfer JSON 指令清單。
        @param data 輸入資料：Text 時為 list[str]；其餘為 Base64/Hex 字串。
        @param data_type 資料型別：Text、Base64 或 Hex。
        @param from_id 送出端識別（預設 "SDK"）。
        @param to_id 目標端識別（預設 "printer"）。
        @param transaction_id_start 起始 TransactionId；None 時隨機。
        @return JSON 字串清單（每筆為一個 TSCDataTransfer 指令）。
        @throws ValueError 當輸入型別或編碼無效時。
        """
        if transaction_id_start is None:
            transaction_id_start = random.randint(1000, 9999)

        messages = []

        if data_type == DataTransferType.TEXT:
            if not isinstance(data, list):
                raise ValueError("Text data format must be list[str]")
            chunks = MqttComm.split_text_lines(data)
            for i, chunk in enumerate(chunks):
                action = "Process" if i == len(chunks) - 1 else "Buffer"
                messages.append(json.dumps({
                    "Id": "TSCDataTransfer",
                    "From": from_id,
                    "To": to_id,
                    "TransactionId": transaction_id_start + i,
                    "Resource": {
                        "Action": action,
                        data_type.value: chunk
                    }
                }))

        elif data_type == DataTransferType.BASE64:
            if not isinstance(data, str):
                raise ValueError("Base64 must be string.")
            try:
                raw_bytes = base64.b64decode(data, validate=True)
            except Exception as e:
                raise ValueError(f"Invalid base64 string: {e}")
            chunks = [
                base64.b64encode(raw_bytes[i:i + MAX_CHUNK_SIZE]).decode("ascii")
                for i in range(0, len(raw_bytes), MAX_CHUNK_SIZE)
            ]
            for i, chunk in enumerate(chunks):
                action = "Process" if i == len(chunks) - 1 else "Buffer"
                messages.append(json.dumps({
                    "Id": "TSCDataTransfer",
                    "From": from_id,
                    "To": to_id,
                    "TransactionId": transaction_id_start + i,
                    "Resource": {
                        "Action": action,
                        data_type.value: chunk
                    }
                }))

        elif data_type == DataTransferType.HEX:
            if not isinstance(data, str):
                raise ValueError("Hex must be string.")
            try:
                raw_bytes = bytes.fromhex(data)
            except Exception as e:
                raise ValueError(f"Invalid hex string: {e}")
            chunks = [
                raw_bytes[i:i + MAX_CHUNK_SIZE].hex().upper()
                for i in range(0, len(raw_bytes), MAX_CHUNK_SIZE)
            ]
            for i, chunk in enumerate(chunks):
                action = "Process" if i == len(chunks) - 1 else "Buffer"
                messages.append(json.dumps({
                    "Id": "TSCDataTransfer",
                    "From": from_id,
                    "To": to_id,
                    "TransactionId": transaction_id_start + i,
                    "Resource": {
                        "Action": action,
                        data_type.value: chunk
                    }
                }))

        else:
            raise ValueError("data_type parameter must be Text, Base64 or Hex")

        return messages
    
    @staticmethod
    def make_tsc_abort_command(
        from_id: str = "SDK",
        to_id: str = "printer",
        transaction_id: int = None
    ) -> str:
        """!
        @~English
        @brief Build a TSCDataTransfer command with Action="Abort" to clear printer buffer.
        @param from_id Sender identifier (default "SDK").
        @param to_id Target identifier (default "printer").
        @param transaction_id Optional TransactionId; random if None.
        @return JSON string representing the Abort command.

        @~Chinese
        @brief 產生 Action="Abort" 的 TSCDataTransfer 指令以清除印表機緩衝。
        @param from_id 送出端識別（預設 "SDK"）。
        @param to_id 目標端識別（預設 "printer"）。
        @param transaction_id 選用 TransactionId；None 時隨機。
        @return 代表 Abort 指令的 JSON 字串。

        @~Chinese-Traditional
        @brief 產生 Action="Abort" 的 TSCDataTransfer 指令以清除印表機緩衝。
        @param from_id 送出端識別（預設 "SDK"）。
        @param to_id 目標端識別（預設 "printer"）。
        @param transaction_id 選用 TransactionId；None 時隨機。
        @return 代表 Abort 指令的 JSON 字串。
        """
        if transaction_id is None:
            transaction_id = random.randint(1000, 9999)

        return json.dump({
            "Id": "TSCDataTransfer",
            "From": from_id,
            "To": to_id,
            "TransactionId": transaction_id,
            "Resource": {
                "Action": "Abort"
            }
        })
    
    @staticmethod
    def make_tsc_data_pcl_command(
        pcl_language: str,
        from_id: str = "SDK",
        to_id: str = "SetPCL",
        transaction_id: Optional[int] = random.randint(1000, 9999)
    ) -> str:
        """!
        @~English
        @brief Build a TSCDataPCL command to set printer language (e.g., ZPL, TSPL).
        @param pcl_language Language code to set; must be in supported set.
        @param from_id Sender identifier (default "SDK").
        @param to_id Target identifier (default "SetPCL").
        @param transaction_id Optional TransactionId; random default provided.
        @return JSON string representing the TSCDataPCL command.
        @throws TypeError If pcl_language is not a string.
        @throws ValueError If language is not supported.

        @~Chinese
        @brief 建立 TSCDataPCL 指令以設定印表機語言（如 ZPL、TSPL）。
        @param pcl_language 要設定的語言代碼；必須於支援清單中。
        @param from_id 送出端識別（預設 "SDK"）。
        @param to_id 目標端識別（預設 "SetPCL"）。
        @param transaction_id 選用 TransactionId；預設為隨機。
        @return 代表 TSCDataPCL 指令的 JSON 字串。
        @throws TypeError 若 pcl_language 非字串。
        @throws ValueError 若語言不受支援。

        @~Chinese-Traditional
        @brief 建立 TSCDataPCL 指令以設定印表機語言（如 ZPL、TSPL）。
        @param pcl_language 要設定的語言代碼；必須於支援清單中。
        @param from_id 送出端識別（預設 "SDK"）。
        @param to_id 目標端識別（預設 "SetPCL"）。
        @param transaction_id 選用 TransactionId；預設為隨機。
        @return 代表 TSCDataPCL 指令的 JSON 字串。
        @throws TypeError 若 pcl_language 非字串。
        @throws ValueError 若語言不受支援。
        """

        if not isinstance(pcl_language, str):
            raise TypeError("PCL must be string")
        
        pcl_language = pcl_language.upper()
        if pcl_language not in PCL_LANGUAGES:
            raise ValueError(f"Unvalid PCL language: {pcl_language}")

        return json.dumps({
            "Id": "TSCDataPCL",
            "From": from_id,
            "To": to_id,
            "TransactionId": transaction_id,
            "Resource": {
                "PCL": pcl_language
            }
        })
    

    @staticmethod
    def make_tsc_download_file_command(
        download_uri: str,
        from_id: str = "SDK",
        to_id: str = "printer",
        transaction_id: int = None,
        save_filename: str = None,
        peer_cert_check: bool = None
    ) -> str:
        """!
        @~English
        @brief Build a TSCDownloadFile command instructing the printer to download a file.
        @param download_uri Source URL for the file (required).
        @param from_id Sender identifier (default "SDK").
        @param to_id Target identifier (default "printer").
        @param transaction_id Optional TransactionId; random if None.
        @param save_filename Optional filename to save as.
        @param peer_cert_check Optional TLS peer certificate validation (True/False).
        @return JSON string representing the TSCDownloadFile command.

        @~Chinese
        @brief 建立 TSCDownloadFile 指令，要求印表機下載指定檔案。
        @param download_uri 檔案來源 URL（必填）。
        @param from_id 送出端識別（預設 "SDK"）。
        @param to_id 目標端識別（預設 "printer"）。
        @param transaction_id 選用 TransactionId；None 時隨機。
        @param save_filename 選用：存檔檔名。
        @param peer_cert_check 選用：是否驗證 TLS 對端憑證（True/False）。
        @return 代表 TSCDownloadFile 指令的 JSON 字串。

        @~Chinese-Traditional
        @brief 建立 TSCDownloadFile 指令，要求印表機下載指定檔案。
        @param download_uri 檔案來源 URL（必填）。
        @param from_id 送出端識別（預設 "SDK"）。
        @param to_id 目標端識別（預設 "printer"）。
        @param transaction_id 選用 TransactionId；None 時隨機。
        @param save_filename 選用：存檔檔名。
        @param peer_cert_check 選用：是否驗證 TLS 對端憑證（True/False）。
        @return 代表 TSCDownloadFile 指令的 JSON 字串。
        """

        if transaction_id is None:
            transaction_id = random.randint(1000, 9999)

        resource = {
            "downloadUri": download_uri,
            "contentType": "File"
        }

        if save_filename:
            resource["saveFilename"] = save_filename

        if peer_cert_check is not None:
            resource["peerCertCheck"] = peer_cert_check  

        return json.dumps({
            "Id": "TSCDownloadFile",
            "From": from_id,
            "To": to_id,
            "TransactionId": transaction_id,
            "Resource": resource
        })
